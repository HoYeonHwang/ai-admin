const BASE_URL = import.meta.env.VITE_API_BASE_URL;

const MOCK = true;

export interface AbnormalChatLog {
  log_id: string;
  trx_no: string;
  origin_content: string;
  outlier_content: string;
  detect_system: string;
  admin_note: string;
  status: "Active" | "Pending" | "Delete";
  detect_at: string;
}

export type AbnormalChatLogUpdateRequest = Pick<AbnormalChatLog, "status" | "admin_note">;

let mockLogs: AbnormalChatLog[] = [
  {
    log_id: "1",
    trx_no: "2026041600000001",
    origin_content: "야 이 바보야, 대출 한도가 왜 이렇게 낮아?",
    outlier_content: "바보",
    detect_system: "Bedrock",
    admin_note: "",
    status: "Active",
    detect_at: "2026-04-13 15:32:18",
  },
  {
    log_id: "2",
    trx_no: "2026041600000002",
    origin_content: "멍청이 같은 AI야, 제대로 된 답변을 해줘.",
    outlier_content: "멍청이",
    detect_system: "Bedrock",
    admin_note: "",
    status: "Active",
    detect_at: "2026-04-13 16:05:44",
  },
  {
    log_id: "3",
    trx_no: "2026041600000003",
    origin_content: "내 주민번호는 900101-1234567인데, 이걸로 조회 좀 해줘.",
    outlier_content: "주민번호",
    detect_system: "PII",
    admin_note: "PII 탐지 확인 완료.",
    status: "Delete",
    detect_at: "2026-04-14 09:15:00",
  },
  {
    log_id: "4",
    trx_no: "2026041600000004",
    origin_content: "카드번호 1234-5678-9012-3456 알려줄게.",
    outlier_content: "카드번호",
    detect_system: "PII",
    admin_note: "",
    status: "Pending",
    detect_at: "2026-04-15 11:30:00",
  },
  {
    log_id: "5",
    trx_no: "2026041600000005",
    origin_content: "이 시스템 진짜 쓸모없네.",
    outlier_content: "쓸모없네",
    detect_system: "Bedrock",
    admin_note: "재검토 필요.",
    status: "Active",
    detect_at: "2026-04-15 14:22:11",
  },
];

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export async function getAbnormalChatLogs(status?: string): Promise<AbnormalChatLog[]> {
  if (MOCK) {
    if (!status || status === "전체") return [...mockLogs];
    return mockLogs.filter((l) => l.status === status);
  }

  const params = status && status !== "전체" ? `?status=${status}` : "";
  const res = await apiFetch(`/api/v1/abnormal-chat-logs${params}`);
  if (!res.ok) throw new Error("이상 채팅 로그 조회에 실패했습니다.");
  return res.json();
}

export async function updateAbnormalChatLog(log_id: string, body: AbnormalChatLogUpdateRequest): Promise<AbnormalChatLog> {
  if (MOCK) {
    mockLogs = mockLogs.map((l) =>
      l.log_id === log_id ? { ...l, ...body } : l
    );
    return mockLogs.find((l) => l.log_id === log_id)!;
  }

  const res = await apiFetch(`/api/v1/abnormal-chat-logs/${log_id}`, { method: "PUT", body: JSON.stringify(body) });
  if (!res.ok) throw new Error("이상 채팅 로그 수정에 실패했습니다.");
  return res.json();
}
