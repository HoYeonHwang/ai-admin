import { getSystemPrompts, updateSystemPrompt, type SystemPrompt } from "./systemPrompt";
import { getRagDocuments, updateRagDocument, type RagDocument } from "./ragData";

export type PendingItem =
  | (SystemPrompt & { itemType: "prompt" })
  | (RagDocument & { itemType: "rag" });

export function getItemId(item: PendingItem): string {
  return item.itemType === "prompt" ? item.prompt_id : item.rag_id;
}

export function getItemName(item: PendingItem): string {
  return item.itemType === "prompt" ? item.prompt_name : item.document_name;
}

export function getItemVersion(item: PendingItem): string {
  return item.itemType === "prompt" ? item.prompt_version : item.document_version;
}

export function getItemSize(item: PendingItem): string {
  return item.itemType === "prompt" ? item.prompt_size : item.document_size;
}

export async function getPendingItems(): Promise<PendingItem[]> {
  const [prompts, docs] = await Promise.all([
    getSystemPrompts("Pending"),
    getRagDocuments("Pending"),
  ]);
  return [
    ...prompts.map((p) => ({ ...p, itemType: "prompt" as const })),
    ...docs.map((d) => ({ ...d, itemType: "rag" as const })),
  ].sort((a, b) => b.create_at.localeCompare(a.create_at));
}

export async function approveItem(item: PendingItem): Promise<void> {
  if (item.itemType === "prompt") {
    await updateSystemPrompt(item.prompt_id, {
      prompt_name: item.prompt_name,
      prompt_type: item.prompt_type,
      prompt_content: item.prompt_content,
      status: "Active",
    });
  } else {
    await updateRagDocument(item.rag_id, {
      document_name: item.document_name,
      status: "Active",
    });
  }
}

export async function rejectItem(item: PendingItem): Promise<void> {
  if (item.itemType === "prompt") {
    await updateSystemPrompt(item.prompt_id, {
      prompt_name: item.prompt_name,
      prompt_type: item.prompt_type,
      prompt_content: item.prompt_content,
      status: "Delete",
    });
  } else {
    await updateRagDocument(item.rag_id, {
      document_name: item.document_name,
      status: "Delete",
    });
  }
}
