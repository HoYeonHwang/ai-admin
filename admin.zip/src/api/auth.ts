const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// 백엔드 준비 완료 후 false로 변경
const MOCK_AUTH = true;

const MOCK_USER = { user_id: "admin", user_name: "관리자", user_role: "Admin" as const };
const MOCK_SESSION_KEY = "mock_session";

const authFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export interface LoginRequest {
  user_id: string;
  password: string;
}

export interface SessionUser {
  user_id: string;
  user_name: string;
  user_role: "Admin" | "User";
}

export async function login(body: LoginRequest): Promise<void> {
  if (MOCK_AUTH) {
    if (body.user_id === "admin" && body.password === "admin") {
      sessionStorage.setItem(MOCK_SESSION_KEY, "true");
      return;
    }
    throw new Error("아이디 또는 비밀번호를 확인해주세요.");
  }

  const response = await authFetch("/api/v1/auth/login", {
    method: "POST",
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message ?? "아이디 또는 비밀번호를 확인해주세요.");
  }
}

export async function logout(): Promise<void> {
  if (MOCK_AUTH) {
    sessionStorage.removeItem(MOCK_SESSION_KEY);
    return;
  }

  await authFetch("/api/v1/auth/logout", { method: "POST" });
}

export async function checkSession(): Promise<SessionUser> {
  if (MOCK_AUTH) {
    if (sessionStorage.getItem(MOCK_SESSION_KEY)) {
      return MOCK_USER;
    }
    throw new Error("세션이 만료되었습니다.");
  }

  const response = await authFetch("/api/v1/auth/me");

  if (!response.ok) {
    throw new Error("세션이 만료되었습니다.");
  }

  return response.json();
}
