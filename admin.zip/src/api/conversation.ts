const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// 백엔드 준비 완료 후 false로 변경
const MOCK = true;

export interface ChatHistory {
  user_id: string;
  archive: string;
  key: string;
  sequence: string;
  HumanMessage: string;
  AIMessage: string;
  cls_dcd: string;
  opi_dcd: string;
  opi_cont: string;
  timestamp: string;
}

export interface ConversationFilter {
  user_id?: string;
  key?: string;
  cls_dcd?: string;
  opi_dcd?: string;
  archive?: string;
  startDate?: string;
  endDate?: string;
}

export interface ConversationResponse {
  items: ChatHistory[];
  total: number;
}

const MOCK_DATA: ChatHistory[] = [
  { user_id: "087191", archive: "정보규정", key: "개인정보", sequence: "1", HumanMessage: "개인정보보호 원칙에 대해 알려줘", AIMessage: "개인정보 보호 원칙은 수집 최소화, 목적 명확화, 안전 관리 등을 포함합니다.", cls_dcd: "00", opi_dcd: "01", opi_cont: "좋아요", timestamp: "2026-04-19 09:00:00" },
  { user_id: "087191", archive: "정보규정", key: "개인정보", sequence: "2", HumanMessage: "개인정보 수집 동의 방법은?", AIMessage: "서면, 전자적 방법으로 명시적 동의를 받아야 합니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-19 09:05:00" },
  { user_id: "087191", archive: "여신(규정)", key: "대출심사", sequence: "1", HumanMessage: "대출 심사 기준이 뭐야?", AIMessage: "신용등급, 소득, 담보 여부 등을 종합적으로 평가합니다.", cls_dcd: "01", opi_dcd: "02", opi_cont: "도움이 됐어요", timestamp: "2026-04-18 14:30:00" },
  { user_id: "091234", archive: "수신(교본)", key: "예금상품", sequence: "1", HumanMessage: "정기예금 이율은 어떻게 돼?", AIMessage: "현재 정기예금 기본금리는 연 3.5%입니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-18 10:00:00" },
  { user_id: "091234", archive: "수신(교본)", key: "예금상품", sequence: "2", HumanMessage: "1년 만기 정기예금 최고금리는?", AIMessage: "우대조건 충족 시 최고 연 4.2%까지 가능합니다.", cls_dcd: "00", opi_dcd: "03", opi_cont: "유용해요", timestamp: "2026-04-18 10:10:00" },
  { user_id: "082345", archive: "여신/총무", key: "경비처리", sequence: "1", HumanMessage: "업무용 경비 처리 절차 알려줘", AIMessage: "영수증 첨부 후 전자결재 시스템을 통해 신청하세요.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-17 11:00:00" },
  { user_id: "087191", archive: "정보규정", key: "보안정책", sequence: "1", HumanMessage: "비밀번호 정책은 어떻게 돼?", AIMessage: "8자 이상, 영문/숫자/특수문자 조합이 필요합니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-17 09:00:00" },
  { user_id: "091234", archive: "여신(규정)", key: "담보대출", sequence: "1", HumanMessage: "담보대출 한도는 얼마야?", AIMessage: "담보 평가액의 최대 70%까지 대출 가능합니다.", cls_dcd: "01", opi_dcd: "04", opi_cont: "더 알고 싶어요", timestamp: "2026-04-16 15:00:00" },
  { user_id: "082345", archive: "정보규정", key: "내부감사", sequence: "1", HumanMessage: "내부감사 대상이 뭐야?", AIMessage: "업무 프로세스, 재무 기록, 정보보호 현황 등이 대상입니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-16 10:00:00" },
  { user_id: "087191", archive: "수신(교본)", key: "CMA", sequence: "1", HumanMessage: "CMA 계좌 개설 방법은?", AIMessage: "비대면으로 앱을 통해 5분 내 개설 가능합니다.", cls_dcd: "00", opi_dcd: "01", opi_cont: "빠르네요", timestamp: "2026-04-15 16:00:00" },
  { user_id: "091234", archive: "여신/총무", key: "복리후생", sequence: "1", HumanMessage: "임직원 복리후생 항목 알려줘", AIMessage: "건강검진, 학자금 지원, 동호회 지원 등이 있습니다.", cls_dcd: "00", opi_dcd: "02", opi_cont: "좋아요", timestamp: "2026-04-15 11:00:00" },
  { user_id: "082345", archive: "수신(교본)", key: "적금", sequence: "1", HumanMessage: "자유적금 납입 방법은?", AIMessage: "월 최소 1만원부터 자유롭게 납입 가능합니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-14 14:00:00" },
  { user_id: "087191", archive: "여신(규정)", key: "신용대출", sequence: "1", HumanMessage: "신용대출 최대 한도가 어떻게 돼?", AIMessage: "개인 신용등급에 따라 최대 1억원까지 가능합니다.", cls_dcd: "01", opi_dcd: "05", opi_cont: "한도가 낮네요", timestamp: "2026-04-14 09:30:00" },
  { user_id: "091234", archive: "정보규정", key: "망분리", sequence: "1", HumanMessage: "망분리 정책 설명해줘", AIMessage: "업무망과 인터넷망을 물리적으로 분리하여 운영합니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-13 15:00:00" },
  { user_id: "082345", archive: "여신(규정)", key: "중도상환", sequence: "1", HumanMessage: "중도상환 수수료는 얼마야?", AIMessage: "잔여 대출금의 1.5%이며 3년 경과 시 면제됩니다.", cls_dcd: "02", opi_dcd: "06", opi_cont: "수수료가 높네요", timestamp: "2026-04-13 11:00:00" },
  { user_id: "087191", archive: "여신/총무", key: "출장비", sequence: "1", HumanMessage: "출장비 지급 기준 알려줘", AIMessage: "직급별로 교통비, 숙박비, 일비가 차등 지급됩니다.", cls_dcd: "00", opi_dcd: "01", opi_cont: "기준이 명확해요", timestamp: "2026-04-12 10:00:00" },
  { user_id: "091234", archive: "수신(교본)", key: "ISA", sequence: "1", HumanMessage: "ISA 계좌 혜택이 뭐야?", AIMessage: "비과세 한도 내 이자소득세 면제, 분리과세 적용됩니다.", cls_dcd: "00", opi_dcd: "02", opi_cont: "유익해요", timestamp: "2026-04-12 09:00:00" },
  { user_id: "082345", archive: "정보규정", key: "접근통제", sequence: "1", HumanMessage: "시스템 접근 권한 신청 방법은?", AIMessage: "부서장 승인 후 IT팀에 요청서를 제출하세요.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-11 14:00:00" },
  { user_id: "087191", archive: "수신(교본)", key: "외화예금", sequence: "1", HumanMessage: "외화예금 환율 우대는?", AIMessage: "최대 90% 환율 우대 적용 가능합니다.", cls_dcd: "00", opi_dcd: "03", opi_cont: "좋은 조건이네요", timestamp: "2026-04-11 11:00:00" },
  { user_id: "091234", archive: "여신(규정)", key: "전세대출", sequence: "1", HumanMessage: "전세대출 가능 조건이 뭐야?", AIMessage: "무주택자, 전세계약 체결, 소득 기준 충족 시 가능합니다.", cls_dcd: "01", opi_dcd: "04", opi_cont: "조건이 까다롭네요", timestamp: "2026-04-10 16:00:00" },
  { user_id: "082345", archive: "여신/총무", key: "비품구매", sequence: "1", HumanMessage: "업무 비품 구매 절차는?", AIMessage: "구매 요청서 작성 후 총무팀에 제출하세요.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-10 10:00:00" },
  { user_id: "087191", archive: "정보규정", key: "재해복구", sequence: "1", HumanMessage: "재해복구 절차 알려줘", AIMessage: "BCP에 따라 백업 시스템으로 자동 전환됩니다.", cls_dcd: "00", opi_dcd: "01", opi_cont: "안심이 돼요", timestamp: "2026-04-09 09:00:00" },
  { user_id: "091234", archive: "수신(교본)", key: "퇴직연금", sequence: "1", HumanMessage: "DC형 퇴직연금 운용 방법은?", AIMessage: "가입자가 직접 운용지시를 통해 투자 상품을 선택합니다.", cls_dcd: "00", opi_dcd: "02", opi_cont: "이해가 됩니다", timestamp: "2026-04-09 14:00:00" },
  { user_id: "082345", archive: "여신(규정)", key: "기업대출", sequence: "1", HumanMessage: "기업 운전자금 대출 조건은?", AIMessage: "사업자등록 1년 이상, 매출 증빙 서류 제출이 필요합니다.", cls_dcd: "01", opi_dcd: "05", opi_cont: "서류가 많네요", timestamp: "2026-04-08 11:00:00" },
  { user_id: "087191", archive: "여신(규정)", key: "주택담보", sequence: "1", HumanMessage: "주택담보대출 LTV는?", AIMessage: "지역 및 주택 유형에 따라 40~70%가 적용됩니다.", cls_dcd: "00", opi_dcd: "00", opi_cont: "", timestamp: "2026-04-07 10:00:00" },
];

const PAGE_SIZE = 10;

function applyFilter(data: ChatHistory[], filter: ConversationFilter): ChatHistory[] {
  return data.filter((item) => {
    if (filter.user_id && !item.user_id.includes(filter.user_id)) return false;
    if (filter.key && !item.key.includes(filter.key)) return false;
    if (filter.cls_dcd && filter.cls_dcd !== "전체" && item.cls_dcd !== filter.cls_dcd) return false;
    if (filter.opi_dcd && filter.opi_dcd !== "전체" && item.opi_dcd !== filter.opi_dcd) return false;
    if (filter.archive && filter.archive !== "전체" && item.archive !== filter.archive) return false;
    if (filter.startDate && item.timestamp.slice(0, 10) < filter.startDate) return false;
    if (filter.endDate && item.timestamp.slice(0, 10) > filter.endDate) return false;
    return true;
  });
}

const apiFetch = (path: string) =>
  fetch(`${BASE_URL}${path}`, { credentials: "include" });

export async function getConversations(
  filter: ConversationFilter,
  offset: number,
  limit: number = PAGE_SIZE
): Promise<ConversationResponse> {
  if (MOCK) {
    const filtered = applyFilter(MOCK_DATA, filter);
    return {
      items: filtered.slice(offset, offset + limit),
      total: filtered.length,
    };
  }

  const params = new URLSearchParams({
    ...Object.fromEntries(Object.entries(filter).filter(([, v]) => v)),
    offset: String(offset),
    limit: String(limit),
  });

  const res = await apiFetch(`/api/v1/conversations?${params}`);
  if (!res.ok) throw new Error("대화 내역 조회에 실패했습니다.");
  return res.json();
}

export { PAGE_SIZE };
