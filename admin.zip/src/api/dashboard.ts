const BASE_URL = import.meta.env.VITE_API_BASE_URL;

const MOCK = true;

export interface TodayStats {
  today_users: number;
  today_questions: number;
  user_change_pct: number;
  question_change_pct: number;
}

export interface MonthlyUsage {
  months: string[];
  question_counts: number[];
  user_counts: number[];
}

export interface TokenUsage {
  used_pct: number;
  remaining_tokens: number;
  avg_daily_tokens: number;
  today_tokens: number;
  limit_tokens: number;
}

export interface ServiceUsage {
  service_name: string;
  request_count: number;
  token_count: number;
  avg_response_ms: number;
}

export interface ServiceErrorRate {
  service_name: string;
  request_count: number;
  error_count: number;
  error_rate: number;
}

export interface ResponseTimePoint {
  time: string;
  p50: number;
  p95: number;
}

export interface SessionHeatmapData {
  days: string[];
  hours: string[];
  counts: number[][];
}

const apiFetch = (path: string) =>
  fetch(`${BASE_URL}${path}`, { credentials: "include" });

export async function getTodayStats(): Promise<TodayStats> {
  if (MOCK) {
    return {
      today_users: 3782,
      today_questions: 5359,
      user_change_pct: 11.01,
      question_change_pct: -9.05,
    };
  }
  const res = await apiFetch("/api/v1/dashboard/today");
  if (!res.ok) throw new Error("금일 통계 조회에 실패했습니다.");
  return res.json();
}

export async function getMonthlyUsage(): Promise<MonthlyUsage> {
  if (MOCK) {
    return {
      months: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
      question_counts: [168, 385, 201, 298, 187, 195, 291, 110, 215, 390, 280, 112],
      user_counts: [80, 210, 130, 190, 110, 140, 180, 90, 160, 240, 200, 75],
    };
  }
  const res = await apiFetch("/api/v1/dashboard/monthly-usage");
  if (!res.ok) throw new Error("월간 사용량 조회에 실패했습니다.");
  return res.json();
}

export async function getTokenUsage(): Promise<TokenUsage> {
  if (MOCK) {
    return {
      used_pct: 75.55,
      remaining_tokens: 24450,
      avg_daily_tokens: 3200,
      today_tokens: 3520,
      limit_tokens: 100000,
    };
  }
  const res = await apiFetch("/api/v1/dashboard/token-usage");
  if (!res.ok) throw new Error("토큰 사용량 조회에 실패했습니다.");
  return res.json();
}

export async function getServiceUsage(): Promise<ServiceUsage[]> {
  if (MOCK) {
    return [
      { service_name: "WELSON 챗봇", request_count: 4210, token_count: 52300, avg_response_ms: 320 },
      { service_name: "인사규정 안내", request_count: 890, token_count: 11200, avg_response_ms: 410 },
      { service_name: "여신규정 안내", request_count: 259, token_count: 3800, avg_response_ms: 380 },
    ];
  }
  const res = await apiFetch("/api/v1/dashboard/service-usage");
  if (!res.ok) throw new Error("서비스 사용량 조회에 실패했습니다.");
  return res.json();
}

export async function getErrorRates(): Promise<ServiceErrorRate[]> {
  if (MOCK) {
    return [
      { service_name: "WELSON 챗봇", request_count: 4210, error_count: 63, error_rate: 1.5 },
      { service_name: "인사규정 안내", request_count: 890, error_count: 44, error_rate: 4.9 },
      { service_name: "여신규정 안내", request_count: 259, error_count: 31, error_rate: 12.0 },
    ];
  }
  const res = await apiFetch("/api/v1/dashboard/error-rates");
  if (!res.ok) throw new Error("에러율 조회에 실패했습니다.");
  return res.json();
}

export async function getResponseTimeTrend(): Promise<ResponseTimePoint[]> {
  if (MOCK) {
    const base = [210,195,180,170,165,175,200,280,340,390,370,360,380,400,410,390,370,350,340,320,300,270,250,225];
    const p95  = [420,390,360,340,330,350,400,560,680,780,740,720,760,800,820,780,740,700,680,640,600,540,500,450];
    return base.map((p50, i) => ({
      time: `${String(i).padStart(2, "0")}:00`,
      p50,
      p95: p95[i],
    }));
  }
  const res = await apiFetch("/api/v1/dashboard/response-time-trend");
  if (!res.ok) throw new Error("응답시간 추이 조회에 실패했습니다.");
  return res.json();
}

export async function getSessionHeatmap(): Promise<SessionHeatmapData> {
  if (MOCK) {
    const days = ["일", "월", "화", "수", "목", "금", "토"];
    const hours = Array.from({ length: 24 }, (_, i) => `${i}시`);
    const pattern = [2,1,1,1,1,2,5,20,60,85,90,88,70,75,88,92,85,70,55,40,25,15,8,4];
    const counts = days.map((_, d) => {
      const isWeekend = d === 0 || d === 6;
      return pattern.map((v) => Math.round(v * (isWeekend ? 0.25 : 1) * (0.85 + (d * 7) % 30 / 100)));
    });
    return { days, hours, counts };
  }
  const res = await apiFetch("/api/v1/dashboard/session-heatmap");
  if (!res.ok) throw new Error("세션 분포 조회에 실패했습니다.");
  return res.json();
}
