const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// 백엔드 준비 완료 후 false로 변경
const MOCK = true;

export interface ServiceHealth {
  name: string;
  status: "healthy" | "unhealthy" | "unknown";
  latency_ms: number;
}

export interface KillSwitchStatus {
  active: boolean;
  activated_at?: string;
  activated_by?: string;
}

let mockKillSwitchActive = false;

const MOCK_SERVICES: ServiceHealth[] = [
  { name: "welson-ai-backend-1", status: "healthy", latency_ms: 12 },
  { name: "welson-ai-backend-2", status: "healthy", latency_ms: 15 },
  { name: "welson-ai-frontend-1", status: "healthy", latency_ms: 8 },
  { name: "welson-ai-frontend-2", status: "healthy", latency_ms: 9 },
];

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export async function getHealthCheck(): Promise<ServiceHealth[]> {
  if (MOCK) {
    return MOCK_SERVICES.map((s) => ({
      ...s,
      status: mockKillSwitchActive ? "unhealthy" : "healthy",
      latency_ms: mockKillSwitchActive ? 0 : s.latency_ms,
    }));
  }

  const res = await apiFetch("/api/v1/health");
  if (!res.ok) throw new Error("헬스체크 조회에 실패했습니다.");
  return res.json();
}

export async function getKillSwitchStatus(): Promise<KillSwitchStatus> {
  if (MOCK) {
    return {
      active: mockKillSwitchActive,
      activated_at: mockKillSwitchActive ? new Date().toISOString() : undefined,
      activated_by: mockKillSwitchActive ? "admin" : undefined,
    };
  }

  const res = await apiFetch("/api/v1/killswitch");
  if (!res.ok) throw new Error("Kill Switch 상태 조회에 실패했습니다.");
  return res.json();
}

export async function activateKillSwitch(): Promise<void> {
  if (MOCK) {
    mockKillSwitchActive = true;
    return;
  }

  const res = await apiFetch("/api/v1/killswitch/activate", { method: "POST" });
  if (!res.ok) throw new Error("Kill Switch 활성화에 실패했습니다.");
}

export async function deactivateKillSwitch(): Promise<void> {
  if (MOCK) {
    mockKillSwitchActive = false;
    return;
  }

  const res = await apiFetch("/api/v1/killswitch/deactivate", { method: "POST" });
  if (!res.ok) throw new Error("Kill Switch 비활성화에 실패했습니다.");
}
