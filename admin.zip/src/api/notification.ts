const BASE_URL = import.meta.env.VITE_API_BASE_URL;

const MOCK = true;

export type NotificationType = "info" | "warning" | "error" | "success";

export interface Notification {
  notification_id: string;
  title: string;
  message: string;
  type: NotificationType;
  is_read: boolean;
  created_at: string;
}

let mockNotifications: Notification[] = [
  {
    notification_id: "1",
    title: "이상 채팅 탐지",
    message: "PII 탐지 시스템에서 개인정보 포함 대화가 감지되었습니다.",
    type: "error",
    is_read: false,
    created_at: "2026-04-19 14:32:00",
  },
  {
    notification_id: "2",
    title: "RAG 위변조 감지",
    message: "인사 규정 문서의 Hash 값 불일치가 탐지되었습니다.",
    type: "warning",
    is_read: false,
    created_at: "2026-04-19 13:15:00",
  },
  {
    notification_id: "3",
    title: "시스템 프롬프트 등록",
    message: "새로운 시스템 프롬프트가 Pending 상태로 등록되었습니다.",
    type: "info",
    is_read: false,
    created_at: "2026-04-19 11:00:00",
  },
  {
    notification_id: "4",
    title: "Kill Switch 비활성화",
    message: "서비스가 정상 재개되었습니다.",
    type: "success",
    is_read: true,
    created_at: "2026-04-18 09:30:00",
  },
  {
    notification_id: "5",
    title: "토큰 한도 경고",
    message: "월간 토큰 사용량이 75%를 초과했습니다.",
    type: "warning",
    is_read: true,
    created_at: "2026-04-17 16:45:00",
  },
];

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export async function getNotifications(): Promise<Notification[]> {
  if (MOCK) return [...mockNotifications];
  const res = await apiFetch("/api/v1/notifications");
  if (!res.ok) throw new Error("알림 조회에 실패했습니다.");
  return res.json();
}

export async function markAsRead(notification_id: string): Promise<void> {
  if (MOCK) {
    mockNotifications = mockNotifications.map((n) =>
      n.notification_id === notification_id ? { ...n, is_read: true } : n
    );
    return;
  }
  await apiFetch(`/api/v1/notifications/${notification_id}/read`, { method: "PATCH" });
}

export async function markAllAsRead(): Promise<void> {
  if (MOCK) {
    mockNotifications = mockNotifications.map((n) => ({ ...n, is_read: true }));
    return;
  }
  await apiFetch("/api/v1/notifications/read-all", { method: "PATCH" });
}
