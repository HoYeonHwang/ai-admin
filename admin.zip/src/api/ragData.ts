const BASE_URL = import.meta.env.VITE_API_BASE_URL;

const MOCK = true;

export interface RagDocument {
  rag_id: string;
  document_name: string;
  document_version: string;
  document_size: string;
  document_type: string;
  created_by: string;
  create_at: string;
  update_at: string;
  status: "Active" | "Pending" | "Delete";
}

export interface RagChunk {
  chunk_id: string;
  rag_id: string;
  chunk_num: number;
  document_chunk: string;
  document_vector: string;
  chunk_size: string;
  hash_data: string;
  create_at: string;
}

export type RagDocumentUpdateRequest = Pick<RagDocument, "document_name" | "status">;

let mockDocuments: RagDocument[] = [
  {
    rag_id: "1",
    document_name: "인사 규정",
    document_version: "1.0",
    document_size: "1024bytes",
    document_type: ".pdf",
    created_by: "087191",
    create_at: "2026-04-13 15:32:18",
    update_at: "2026-04-13 15:32:18",
    status: "Active",
  },
  {
    rag_id: "2",
    document_name: "총무 규정",
    document_version: "1.0",
    document_size: "2048bytes",
    document_type: ".pdf",
    created_by: "087191",
    create_at: "2026-04-14 10:00:00",
    update_at: "2026-04-14 10:00:00",
    status: "Active",
  },
  {
    rag_id: "3",
    document_name: "여신 규정 v2",
    document_version: "2.0",
    document_size: "3072bytes",
    document_type: ".docx",
    created_by: "091234",
    create_at: "2026-04-15 09:00:00",
    update_at: "2026-04-15 09:00:00",
    status: "Pending",
  },
  {
    rag_id: "4",
    document_name: "구버전 인사규정",
    document_version: "0.9",
    document_size: "512bytes",
    document_type: ".pdf",
    created_by: "087191",
    create_at: "2026-01-01 09:00:00",
    update_at: "2026-03-01 09:00:00",
    status: "Delete",
  },
];

const mockChunks: RagChunk[] = [
  {
    chunk_id: "c1",
    rag_id: "1",
    chunk_num: 1,
    document_chunk: "인사 규정 제1조 목적: 이 규정은 임직원의 인사에 관한 사항을 정함을 목적으로 한다.",
    document_vector: "0.1234",
    chunk_size: "87bytes",
    hash_data: "a3f2c9d1e8b4507f6a2c91d3e8b45076",
    create_at: "2026-04-13 15:32:20",
  },
  {
    chunk_id: "c2",
    rag_id: "1",
    chunk_num: 2,
    document_chunk: "인사 규정 제2조 적용범위: 이 규정은 본 회사에 재직하는 모든 임직원에게 적용한다.",
    document_vector: "0.5678",
    chunk_size: "91bytes",
    hash_data: "b7e3d2a0f1c6489e5b7d3a0f1c648953",
    create_at: "2026-04-13 15:32:21",
  },
  {
    chunk_id: "c3",
    rag_id: "2",
    chunk_num: 1,
    document_chunk: "총무 규정 제1조 목적: 이 규정은 회사의 총무 업무 처리에 관한 사항을 정함을 목적으로 한다.",
    document_vector: "0.9012",
    chunk_size: "95bytes",
    hash_data: "c9f4e1b2d7a3506f4c9e1b2d7a350694",
    create_at: "2026-04-14 10:00:05",
  },
];

let nextId = 5;
let nextChunkId = 4;

const now = () => new Date().toISOString().replace("T", " ").slice(0, 19);

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { ...options.headers },
  });

export async function getRagDocuments(status?: string): Promise<RagDocument[]> {
  if (MOCK) {
    if (!status || status === "전체") return [...mockDocuments];
    return mockDocuments.filter((d) => d.status === status);
  }

  const params = status && status !== "전체" ? `?status=${status}` : "";
  const res = await apiFetch(`/api/v1/rag-documents${params}`);
  if (!res.ok) throw new Error("RAG 문서 조회에 실패했습니다.");
  return res.json();
}

export async function createRagDocument(file: File): Promise<RagDocument> {
  if (MOCK) {
    const ext = file.name.includes(".") ? `.${file.name.split(".").pop()}` : "";
    const newDoc: RagDocument = {
      rag_id: String(nextId++),
      document_name: file.name.replace(/\.[^/.]+$/, ""),
      document_version: "1.0",
      document_size: `${file.size}bytes`,
      document_type: ext,
      created_by: "admin",
      create_at: now(),
      update_at: now(),
      status: "Pending",
    };
    mockDocuments = [newDoc, ...mockDocuments];

    const chunkText = `${newDoc.document_name} 청크 데이터 샘플`;
    mockChunks.push({
      chunk_id: `c${nextChunkId++}`,
      rag_id: newDoc.rag_id,
      chunk_num: 1,
      document_chunk: chunkText,
      document_vector: "0.0001",
      chunk_size: `${new Blob([chunkText]).size}bytes`,
      hash_data: Math.random().toString(36).slice(2).padEnd(32, "0"),
      create_at: now(),
    });

    return newDoc;
  }

  const formData = new FormData();
  formData.append("file", file);
  const res = await apiFetch("/api/v1/rag-documents", { method: "POST", body: formData });
  if (!res.ok) throw new Error("RAG 문서 등록에 실패했습니다.");
  return res.json();
}

export async function updateRagDocument(rag_id: string, body: RagDocumentUpdateRequest): Promise<RagDocument> {
  if (MOCK) {
    mockDocuments = mockDocuments.map((d) =>
      d.rag_id === rag_id ? { ...d, ...body, update_at: now() } : d
    );
    return mockDocuments.find((d) => d.rag_id === rag_id)!;
  }

  const res = await apiFetch(`/api/v1/rag-documents/${rag_id}`, {
    method: "PUT",
    body: JSON.stringify(body),
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error("RAG 문서 수정에 실패했습니다.");
  return res.json();
}

export async function getRagChunks(rag_id: string): Promise<RagChunk[]> {
  if (MOCK) {
    return mockChunks.filter((c) => c.rag_id === rag_id);
  }

  const res = await apiFetch(`/api/v1/rag-documents/${rag_id}/chunks`);
  if (!res.ok) throw new Error("청크 조회에 실패했습니다.");
  return res.json();
}
