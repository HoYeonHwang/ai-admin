const BASE_URL = import.meta.env.VITE_API_BASE_URL;

const MOCK = true;

export interface RagOutlier {
  outlier_id: string;
  outlier_dcd: string;
  outlier_hash: string;
  outlier_note: string;
  origin_document_id: string;
  origin_document_hash: string;
  status: "Active" | "Pending" | "Delete";
  detect_at: string;
}

export type RagOutlierUpdateRequest = Pick<RagOutlier, "status" | "outlier_note">;

let mockOutliers: RagOutlier[] = [
  {
    outlier_id: "1",
    outlier_dcd: "RAG",
    outlier_hash: "213o4iher8ghadguba8se7rh2374",
    outlier_note: "임베딩 벡터 값이 정상 범위를 벗어났습니다.",
    origin_document_id: "DOC_1",
    origin_document_hash: "0s9dufa98sdyun2p983has9p8syhfd",
    status: "Active",
    detect_at: "2026-04-13 15:32:18",
  },
  {
    outlier_id: "2",
    outlier_dcd: "RAG",
    outlier_hash: "9as0d87f0a9s8d98as7df098asdf",
    outlier_note: "문서 Hash 불일치 감지.",
    origin_document_id: "DOC_2",
    origin_document_hash: "23h314uh234iu5h2i3l1u45hl234",
    status: "Active",
    detect_at: "2026-04-14 09:15:00",
  },
  {
    outlier_id: "3",
    outlier_dcd: "RAG",
    outlier_hash: "34lk7345l6kj34l5k6j3l4k5j6l3k45",
    outlier_note: "처리 완료된 이상치입니다.",
    origin_document_id: "DOC_3",
    origin_document_hash: "123i4jop1i234h12b34ku1h2b34kjh",
    status: "Delete",
    detect_at: "2026-04-10 11:00:00",
  },
  {
    outlier_id: "4",
    outlier_dcd: "RAG",
    outlier_hash: "4567jh5l6k7jh456lkj7h54k6l7j",
    outlier_note: "",
    origin_document_id: "DOC_4",
    origin_document_hash: "234k5j23h4lk5jh23lk45jh2l3k4j5",
    status: "Delete",
    detect_at: "2026-04-09 08:00:00",
  },
  {
    outlier_id: "5",
    outlier_dcd: "RAG",
    outlier_hash: "234jh5lk2j34h5lk2j3h45lkj2h34l5kj",
    outlier_note: "검토 중입니다.",
    origin_document_id: "DOC_5",
    origin_document_hash: "5k67j8n56lk78jh56k7j8hl5k67j85lk",
    status: "Pending",
    detect_at: "2026-04-15 13:45:00",
  },
];

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export async function getRagOutliers(status?: string): Promise<RagOutlier[]> {
  if (MOCK) {
    if (!status || status === "전체") return [...mockOutliers];
    return mockOutliers.filter((o) => o.status === status);
  }

  const params = status && status !== "전체" ? `?status=${status}` : "";
  const res = await apiFetch(`/api/v1/rag-outliers${params}`);
  if (!res.ok) throw new Error("위변조 내역 조회에 실패했습니다.");
  return res.json();
}

export async function updateRagOutlier(outlier_id: string, body: RagOutlierUpdateRequest): Promise<RagOutlier> {
  if (MOCK) {
    mockOutliers = mockOutliers.map((o) =>
      o.outlier_id === outlier_id ? { ...o, ...body } : o
    );
    return mockOutliers.find((o) => o.outlier_id === outlier_id)!;
  }

  const res = await apiFetch(`/api/v1/rag-outliers/${outlier_id}`, { method: "PUT", body: JSON.stringify(body) });
  if (!res.ok) throw new Error("위변조 내역 수정에 실패했습니다.");
  return res.json();
}
