const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// 백엔드 준비 완료 후 false로 변경
const MOCK = true;

export interface SystemLimit {
  token_limit: number;
  request_limit: number;
  updated_at?: string;
  updated_by?: string;
}

let mockLimit: SystemLimit = {
  token_limit: 5000,
  request_limit: 100,
  updated_at: "2026-04-19 09:00:00",
  updated_by: "admin",
};

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export async function getSystemLimit(): Promise<SystemLimit> {
  if (MOCK) return { ...mockLimit };

  const res = await apiFetch("/api/v1/system/limit");
  if (!res.ok) throw new Error("제한 설정 조회에 실패했습니다.");
  return res.json();
}

export async function updateSystemLimit(body: Pick<SystemLimit, "token_limit" | "request_limit">): Promise<SystemLimit> {
  if (MOCK) {
    mockLimit = {
      ...body,
      updated_at: new Date().toISOString().replace("T", " ").slice(0, 19),
      updated_by: "admin",
    };
    return { ...mockLimit };
  }

  const res = await apiFetch("/api/v1/system/limit", {
    method: "PUT",
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("제한 설정 저장에 실패했습니다.");
  return res.json();
}
