const BASE_URL = import.meta.env.VITE_API_BASE_URL;

const MOCK = true;

export interface SystemPrompt {
  prompt_id: string;
  prompt_name: string;
  prompt_version: string;
  prompt_size: string;
  prompt_type: string;
  prompt_content: string;
  created_by: string;
  create_at: string;
  update_at: string;
  status: "Active" | "Pending" | "Delete";
}

export type SystemPromptCreateRequest = Pick<SystemPrompt, "prompt_name" | "prompt_type" | "prompt_content">;
export type SystemPromptUpdateRequest = Pick<SystemPrompt, "prompt_name" | "prompt_type" | "prompt_content" | "status">;

let mockPrompts: SystemPrompt[] = [
  {
    prompt_id: "1",
    prompt_name: "Welson 기본 프롬프트",
    prompt_version: "1.2",
    prompt_size: "2048bytes",
    prompt_type: "WELSON 챗봇용",
    prompt_content: "당신은 welson AI 어시스턴트입니다. 사용자의 질문에 친절하고 정확하게 답변해주세요.",
    created_by: "087191",
    create_at: "2026-03-01 09:00:00",
    update_at: "2026-04-10 14:30:00",
    status: "Active",
  },
  {
    prompt_id: "2",
    prompt_name: "인사규정 전문 프롬프트",
    prompt_version: "1.0",
    prompt_size: "1536bytes",
    prompt_type: "규정 안내용",
    prompt_content: "당신은 인사규정 전문 안내 AI입니다. 인사규정 관련 질문에 정확하게 답변해주세요.",
    created_by: "087191",
    create_at: "2026-03-15 10:00:00",
    update_at: "2026-03-15 10:00:00",
    status: "Active",
  },
  {
    prompt_id: "3",
    prompt_name: "여신규정 프롬프트 v2",
    prompt_version: "2.0",
    prompt_size: "3072bytes",
    prompt_type: "여신 안내용",
    prompt_content: "당신은 여신규정 전문 AI입니다.",
    created_by: "091234",
    create_at: "2026-04-01 11:00:00",
    update_at: "2026-04-01 11:00:00",
    status: "Pending",
  },
  {
    prompt_id: "4",
    prompt_name: "구버전 기본 프롬프트",
    prompt_version: "1.0",
    prompt_size: "1024bytes",
    prompt_type: "WELSON 챗봇용",
    prompt_content: "기존 프롬프트 내용.",
    created_by: "087191",
    create_at: "2026-01-01 09:00:00",
    update_at: "2026-03-01 09:00:00",
    status: "Delete",
  },
];

let nextId = 5;

const now = () => new Date().toISOString().replace("T", " ").slice(0, 19);

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

export async function getSystemPrompts(status?: string): Promise<SystemPrompt[]> {
  if (MOCK) {
    if (!status || status === "전체") return [...mockPrompts];
    return mockPrompts.filter((p) => p.status === status);
  }

  const params = status && status !== "전체" ? `?status=${status}` : "";
  const res = await apiFetch(`/api/v1/system-prompts${params}`);
  if (!res.ok) throw new Error("시스템 프롬프트 조회에 실패했습니다.");
  return res.json();
}

export async function createSystemPrompt(body: SystemPromptCreateRequest): Promise<SystemPrompt> {
  if (MOCK) {
    const newPrompt: SystemPrompt = {
      prompt_id: String(nextId++),
      prompt_version: "1.0",
      prompt_size: `${new Blob([body.prompt_content]).size}bytes`,
      created_by: "admin",
      create_at: now(),
      update_at: now(),
      status: "Pending",
      ...body,
    };
    mockPrompts = [newPrompt, ...mockPrompts];
    return newPrompt;
  }

  const res = await apiFetch("/api/v1/system-prompts", { method: "POST", body: JSON.stringify(body) });
  if (!res.ok) throw new Error("시스템 프롬프트 등록에 실패했습니다.");
  return res.json();
}

export async function updateSystemPrompt(prompt_id: string, body: SystemPromptUpdateRequest): Promise<SystemPrompt> {
  if (MOCK) {
    mockPrompts = mockPrompts.map((p) =>
      p.prompt_id === prompt_id
        ? { ...p, ...body, prompt_size: `${new Blob([body.prompt_content]).size}bytes`, update_at: now() }
        : p
    );
    return mockPrompts.find((p) => p.prompt_id === prompt_id)!;
  }

  const res = await apiFetch(`/api/v1/system-prompts/${prompt_id}`, { method: "PUT", body: JSON.stringify(body) });
  if (!res.ok) throw new Error("시스템 프롬프트 수정에 실패했습니다.");
  return res.json();
}
