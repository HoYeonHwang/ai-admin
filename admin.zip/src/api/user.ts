const BASE_URL = import.meta.env.VITE_API_BASE_URL;

// 백엔드 준비 완료 후 false로 변경
const MOCK = true;

export interface User {
  user_id: string;
  user_name: string;
  user_department: string;
  user_email: string;
  user_create_at: string;
  user_update_at: string;
  user_last_login_at: string;
  status: "Active" | "Pending" | "Delete";
  user_role: "Admin" | "User";
}

export type UserCreateRequest = Omit<User, "user_create_at" | "user_update_at" | "user_last_login_at">;
export type UserUpdateRequest = Partial<Omit<User, "user_id" | "user_create_at" | "user_update_at" | "user_last_login_at">>;

let mockUsers: User[] = [
  {
    user_id: "087191",
    user_name: "황호연",
    user_department: "AICT이노베이션테크팀",
    user_email: "hoyun7443@gmail.com",
    user_create_at: "2026-01-01 09:00:00",
    user_update_at: "2026-04-01 10:00:00",
    user_last_login_at: "2026-04-19 09:30:00",
    status: "Active",
    user_role: "Admin",
  },
  {
    user_id: "091234",
    user_name: "김철수",
    user_department: "AICT서비스본부",
    user_email: "chulsoo@example.com",
    user_create_at: "2026-02-01 09:00:00",
    user_update_at: "2026-03-15 14:00:00",
    user_last_login_at: "2026-04-18 11:00:00",
    status: "Active",
    user_role: "User",
  },
  {
    user_id: "082345",
    user_name: "이영희",
    user_department: "디지털혁신팀",
    user_email: "younghee@example.com",
    user_create_at: "2026-03-10 09:00:00",
    user_update_at: "2026-03-10 09:00:00",
    user_last_login_at: "2026-04-10 08:45:00",
    status: "Pending",
    user_role: "User",
  },
];

const apiFetch = (path: string, options: RequestInit = {}) =>
  fetch(`${BASE_URL}${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });

const now = () => new Date().toISOString().replace("T", " ").slice(0, 19);

export async function getUsers(): Promise<User[]> {
  if (MOCK) return [...mockUsers];

  const res = await apiFetch("/api/v1/users");
  if (!res.ok) throw new Error("사용자 목록 조회에 실패했습니다.");
  return res.json();
}

export async function createUser(body: UserCreateRequest): Promise<User> {
  if (MOCK) {
    const newUser: User = { ...body, user_create_at: now(), user_update_at: now(), user_last_login_at: "-" };
    mockUsers = [newUser, ...mockUsers];
    return newUser;
  }

  const res = await apiFetch("/api/v1/users", { method: "POST", body: JSON.stringify(body) });
  if (!res.ok) throw new Error("사용자 등록에 실패했습니다.");
  return res.json();
}

export async function updateUser(user_id: string, body: UserUpdateRequest): Promise<User> {
  if (MOCK) {
    mockUsers = mockUsers.map((u) =>
      u.user_id === user_id ? { ...u, ...body, user_update_at: now() } : u
    );
    return mockUsers.find((u) => u.user_id === user_id)!;
  }

  const res = await apiFetch(`/api/v1/users/${user_id}`, { method: "PUT", body: JSON.stringify(body) });
  if (!res.ok) throw new Error("사용자 정보 수정에 실패했습니다.");
  return res.json();
}
