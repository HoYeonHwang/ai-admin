import { useState, useEffect, useRef } from "react";
import { getNotifications, markAsRead, markAllAsRead, type Notification, type NotificationType } from "../../api/notification";

const typeStyle: Record<NotificationType, { bg: string; icon: string; dot: string }> = {
  error:   { bg: "bg-error-50 dark:bg-error-500/10",   icon: "text-error-500",   dot: "bg-error-500" },
  warning: { bg: "bg-warning-50 dark:bg-warning-500/10", icon: "text-warning-500", dot: "bg-warning-400" },
  info:    { bg: "bg-blue-light-50 dark:bg-blue-light-500/10", icon: "text-blue-light-500", dot: "bg-blue-light-500" },
  success: { bg: "bg-success-50 dark:bg-success-500/10", icon: "text-success-500", dot: "bg-success-500" },
};

const TypeIcon = ({ type }: { type: NotificationType }) => {
  const cls = `w-5 h-5 ${typeStyle[type].icon}`;
  if (type === "error") return (
    <svg className={cls} viewBox="0 0 24 24" fill="currentColor">
      <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1 5a1 1 0 112 0v5a1 1 0 11-2 0V7zm1 10a1.25 1.25 0 110-2.5A1.25 1.25 0 0112 17z" />
    </svg>
  );
  if (type === "warning") return (
    <svg className={cls} viewBox="0 0 24 24" fill="currentColor">
      <path fillRule="evenodd" clipRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 1.999-.29 4.499-2.599 4.499H4.645c-2.309 0-3.752-2.5-2.598-4.499L9.4 3.003zM12 8a1 1 0 011 1v4a1 1 0 11-2 0V9a1 1 0 011-1zm0 8a1.25 1.25 0 110-2.5A1.25 1.25 0 0112 16z" />
    </svg>
  );
  if (type === "success") return (
    <svg className={cls} viewBox="0 0 24 24" fill="currentColor">
      <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.707 7.293a1 1 0 00-1.414 0L10 14.586l-2.293-2.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l6-6a1 1 0 000-1.414z" />
    </svg>
  );
  return (
    <svg className={cls} viewBox="0 0 24 24" fill="currentColor">
      <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm1 5a1 1 0 10-2 0v5a1 1 0 102 0V7zm-1 8a1.25 1.25 0 110 2.5A1.25 1.25 0 0112 15z" />
    </svg>
  );
};

const timeAgo = (dateStr: string) => {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60) return "방금 전";
  if (diff < 3600) return `${Math.floor(diff / 60)}분 전`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}시간 전`;
  return `${Math.floor(diff / 86400)}일 전`;
};

export default function NotificationDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const data = await getNotifications();
      setNotifications(data);
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    if (!isOpen) fetchNotifications();
    setIsOpen((v) => !v);
  };

  const handleMarkAsRead = async (id: string) => {
    await markAsRead(id);
    setNotifications((prev) =>
      prev.map((n) => (n.notification_id === id ? { ...n, is_read: true } : n))
    );
  };

  const handleMarkAllAsRead = async () => {
    await markAllAsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
  };

  // 외부 클릭 시 닫기
  useEffect(() => {
    const onMouseDown = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", onMouseDown);
    return () => document.removeEventListener("mousedown", onMouseDown);
  }, []);

  return (
    <div className="relative" ref={containerRef}>
      {/* 벨 버튼 */}
      <button
        onClick={handleOpen}
        className="relative flex items-center justify-center text-gray-500 transition-colors bg-white border border-gray-200 rounded-full hover:text-gray-700 h-11 w-11 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
        aria-label="알림"
      >
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 z-10 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand-500 px-1 text-[10px] font-bold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
        <svg className="fill-current" width="20" height="20" viewBox="0 0 20 20">
          <path fillRule="evenodd" clipRule="evenodd" d="M10.75 2.29248C10.75 1.87827 10.4143 1.54248 10 1.54248C9.58583 1.54248 9.25004 1.87827 9.25004 2.29248V2.83613C6.08266 3.20733 3.62504 5.9004 3.62504 9.16748V14.4591H3.33337C2.91916 14.4591 2.58337 14.7949 2.58337 15.2091C2.58337 15.6234 2.91916 15.9591 3.33337 15.9591H4.37504H15.625H16.6667C17.0809 15.9591 17.4167 15.6234 17.4167 15.2091C17.4167 14.7949 17.0809 14.4591 16.6667 14.4591H16.375V9.16748C16.375 5.9004 13.9174 3.20733 10.75 2.83613V2.29248ZM14.875 14.4591V9.16748C14.875 6.47509 12.6924 4.29248 10 4.29248C7.30765 4.29248 5.12504 6.47509 5.12504 9.16748V14.4591H14.875ZM8.00004 17.7085C8.00004 18.1228 8.33583 18.4585 8.75004 18.4585H11.25C11.6643 18.4585 12 18.1228 12 17.7085C12 17.2943 11.6643 16.9585 11.25 16.9585H8.75004C8.33583 16.9585 8.00004 17.2943 8.00004 17.7085Z" />
        </svg>
      </button>

      {/* 드롭다운 */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-[360px] rounded-2xl border border-gray-200 bg-white shadow-theme-lg dark:border-gray-800 dark:bg-gray-900 z-50">
          {/* 헤더 */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-800">
            <div className="flex items-center gap-2">
              <h5 className="text-base font-semibold text-gray-800 dark:text-white/90">알림</h5>
              {unreadCount > 0 && (
                <span className="rounded-full bg-brand-500 px-2 py-0.5 text-xs font-medium text-white">
                  {unreadCount}
                </span>
              )}
            </div>
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllAsRead}
                className="text-xs text-brand-500 hover:text-brand-600 dark:text-brand-400 font-medium"
              >
                모두 읽음
              </button>
            )}
          </div>

          {/* 목록 */}
          <ul className="max-h-[380px] overflow-y-auto custom-scrollbar divide-y divide-gray-100 dark:divide-gray-800">
            {loading && (
              <li className="flex justify-center py-8">
                <svg className="w-5 h-5 animate-spin text-brand-500" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                </svg>
              </li>
            )}

            {!loading && notifications.length === 0 && (
              <li className="flex flex-col items-center justify-center py-10 gap-2 text-gray-400">
                <svg className="w-8 h-8 opacity-40" viewBox="0 0 24 24" fill="currentColor">
                  <path fillRule="evenodd" clipRule="evenodd" d="M10.75 2.29C10.75 1.88 10.41 1.54 10 1.54s-.75.34-.75.75v.54C6.08 3.21 3.63 5.9 3.63 9.17v5.29H3.33a.75.75 0 000 1.5h12.67a.75.75 0 000-1.5h-.29V9.17c0-3.27-2.46-5.96-5.62-6.34V2.29zM14.88 14.46V9.17a4.88 4.88 0 00-9.75 0v5.29h9.75zM8 17.71a.75.75 0 01.75-.75h2.5a.75.75 0 010 1.5h-2.5A.75.75 0 018 17.71z" />
                </svg>
                <p className="text-sm">새로운 알림이 없습니다.</p>
              </li>
            )}

            {!loading && notifications.map((n) => (
              <li key={n.notification_id}>
                <button
                  onClick={() => !n.is_read && handleMarkAsRead(n.notification_id)}
                  className={`flex w-full items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-gray-50 dark:hover:bg-white/[0.03] ${
                    !n.is_read ? "bg-brand-50/40 dark:bg-brand-500/5" : ""
                  }`}
                >
                  {/* 타입 아이콘 */}
                  <span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${typeStyle[n.type].bg}`}>
                    <TypeIcon type={n.type} />
                  </span>

                  {/* 내용 */}
                  <span className="flex-1 min-w-0">
                    <span className="flex items-center gap-1.5 mb-0.5">
                      <span className={`text-sm font-medium ${!n.is_read ? "text-gray-900 dark:text-white" : "text-gray-600 dark:text-gray-400"}`}>
                        {n.title}
                      </span>
                      {!n.is_read && (
                        <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${typeStyle[n.type].dot}`} />
                      )}
                    </span>
                    <span className="block text-xs text-gray-500 dark:text-gray-400 line-clamp-2">{n.message}</span>
                    <span className="mt-1 block text-xs text-gray-400 dark:text-gray-500">{timeAgo(n.created_at)}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
