import { useState, useEffect, useCallback } from "react";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import Badge from "../ui/badge/Badge";
import Spinner from "../ui/spinner/Spinner";
import AbnormalChatLogEditModal from "./modal/AbnormalChatLogEditModal";
import { getAbnormalChatLogs, type AbnormalChatLog } from "../../api/abnormalChatLog";
import { useToast } from "../../context/ToastContext";

const STATUS_FILTER_OPTIONS = [
  { value: "Active", label: "Active" },
  { value: "Pending", label: "Pending" },
  { value: "Delete", label: "Delete" },
  { value: "전체", label: "전체" },
];

const statusColor = (status: AbnormalChatLog["status"]) =>
  status === "Active" ? "success" : status === "Pending" ? "warning" : "error";

export default function AbnormalChatLogComponent() {
  const { showToast } = useToast();

  const [logs, setLogs] = useState<AbnormalChatLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("Active");

  const [selectedLog, setSelectedLog] = useState<AbnormalChatLog | null>(null);
  const [editOpen, setEditOpen] = useState(false);

  const fetchLogs = useCallback(async (status: string) => {
    setLoading(true);
    try {
      const data = await getAbnormalChatLogs(status);
      setLogs(data);
    } catch {
      showToast("error", "이상 채팅 로그 조회에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchLogs(statusFilter);
  }, [fetchLogs, statusFilter]);

  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    setSelectedLog(null);
  };

  const handleRowClick = (log: AbnormalChatLog) => {
    setSelectedLog((prev) => prev?.log_id === log.log_id ? null : log);
  };

  const handleSuccess = () => {
    setSelectedLog(null);
    fetchLogs(statusFilter);
  };

  return (
    <>
      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
        <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h4 className="text-xl font-semibold text-gray-800 dark:text-white/90">이상 채팅 관리</h4>
            <p className="mt-0.5 text-sm text-gray-500 dark:text-gray-400">이상 채팅을 탐지하고 관리합니다.</p>
          </div>

          <div className="flex items-center gap-1.5 ml-auto">
            <div className="relative">
              <select
                value={statusFilter}
                onChange={(e) => handleStatusChange(e.target.value)}
                className="h-8 w-24 appearance-none rounded-md border border-gray-200 bg-white pl-2.5 pr-6 text-xs font-medium text-gray-600 focus:border-brand-300 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 cursor-pointer transition-colors"
              >
                {STATUS_FILTER_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value} className="dark:bg-gray-900">{o.label}</option>
                ))}
              </select>
              <svg className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </div>

            <div className="h-4 w-px bg-gray-200 dark:bg-gray-700" />

            <button
              type="button"
              disabled={!selectedLog}
              onClick={() => setEditOpen(true)}
              className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border border-gray-200 bg-white text-xs font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors dark:border-gray-700 dark:bg-white/[0.03] dark:text-gray-400 dark:hover:bg-white/[0.06] dark:hover:text-gray-200"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 18 18" fill="none">
                <path fillRule="evenodd" clipRule="evenodd" d="M15.0911 2.78206C14.2125 1.90338 12.7878 1.90338 11.9092 2.78206L4.57524 10.116C4.26682 10.4244 4.0547 10.8158 3.96468 11.2426L3.31231 14.3352C3.25997 14.5833 3.33653 14.841 3.51583 15.0203C3.69512 15.1996 3.95286 15.2761 4.20096 15.2238L7.29355 14.5714C7.72031 14.4814 8.11172 14.2693 8.42013 13.9609L15.7541 6.62695C16.6327 5.74827 16.6327 4.32365 15.7541 3.44497L15.0911 2.78206ZM12.9698 3.84272C13.2627 3.54982 13.7376 3.54982 14.0305 3.84272L14.6934 4.50563C14.9863 4.79852 14.9863 5.2734 14.6934 5.56629L14.044 6.21573L12.3204 4.49215L12.9698 3.84272ZM11.2597 5.55281L5.6359 11.1766C5.53309 11.2794 5.46238 11.4099 5.43238 11.5522L5.01758 13.5185L6.98394 13.1037C7.1262 13.0737 7.25666 13.003 7.35947 12.9002L12.9833 7.27639L11.2597 5.55281Z" fill="currentColor" />
              </svg>
              Edit
            </button>
          </div>
        </div>

        {/* 선택된 항목 안내 */}
        {selectedLog && (
          <div className="mb-3 flex items-center gap-2 rounded-lg bg-brand-50 px-3 py-2 text-sm text-brand-600 dark:bg-brand-500/10 dark:text-brand-400">
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none">
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm1 5a1 1 0 10-2 0v5a1 1 0 102 0V7zm-1 10a1.25 1.25 0 110-2.5A1.25 1.25 0 0113 17z" fill="currentColor" />
            </svg>
            <span><strong>#{selectedLog.log_id}</strong> 항목이 선택되었습니다. Edit 버튼을 눌러 수정하세요.</span>
          </div>
        )}

        {/* 로딩 */}
        {loading && (
          <div className="flex justify-center items-center py-16">
            <Spinner size="lg" />
          </div>
        )}

        {/* 빈 결과 */}
        {!loading && logs.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 gap-2 text-gray-400">
            <p className="text-sm">조회된 이상 채팅 로그가 없습니다.</p>
          </div>
        )}

        {/* 테이블 */}
        {!loading && logs.length > 0 && (
          <div className="max-w-full overflow-x-auto">
            <Table>
              <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  {["고유 식별자", "거래번호", "이상 탐지 본문", "탐지 시스템", "상태", "탐지 일시"].map((h) => (
                    <TableCell key={h} isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400 whitespace-nowrap">
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                {logs.map((log) => {
                  const isSelected = selectedLog?.log_id === log.log_id;
                  return (
                    <TableRow
                      key={log.log_id}
                      onClick={() => handleRowClick(log)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? "bg-brand-50 dark:bg-brand-500/10"
                          : "hover:bg-gray-50 dark:hover:bg-white/[0.03]"
                      }`}
                    >
                      <TableCell className="px-5 py-4 text-start">
                        <div className="flex items-center gap-2">
                          {isSelected && (
                            <svg className="w-3.5 h-3.5 text-brand-500 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                              <path fillRule="evenodd" clipRule="evenodd" d="M20.707 5.293a1 1 0 010 1.414l-11 11a1 1 0 01-1.414 0l-5-5a1 1 0 011.414-1.414L9 15.586 19.293 5.293a1 1 0 011.414 0z" />
                            </svg>
                          )}
                          <span className="font-medium text-gray-800 text-theme-sm dark:text-white/90">#{log.log_id}</span>
                        </div>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{log.trx_no}</TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 max-w-xs">
                        <span className="block truncate" title={log.outlier_content}>{log.outlier_content}</span>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">{log.detect_system}</TableCell>
                      <TableCell className="px-4 py-3">
                        <Badge size="sm" color={statusColor(log.status)}>{log.status}</Badge>
                      </TableCell>
                      <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{log.detect_at}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <AbnormalChatLogEditModal
        isOpen={editOpen}
        log={selectedLog}
        onClose={() => setEditOpen(false)}
        onSuccess={handleSuccess}
      />
    </>
  );
}
