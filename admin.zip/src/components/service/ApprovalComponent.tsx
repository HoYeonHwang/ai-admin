import { useState, useEffect, useCallback, Fragment } from "react";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import Spinner from "../ui/spinner/Spinner";
import {
  getPendingItems,
  approveItem,
  rejectItem,
  getItemId,
  getItemName,
  getItemVersion,
  getItemSize,
  type PendingItem,
} from "../../api/approval";
import { useToast } from "../../context/ToastContext";
import { useLastUpdated } from "../../hooks/useLastUpdated";

type FilterType = "all" | "prompt" | "rag";

const TYPE_CONFIG = {
  prompt: {
    label: "시스템 프롬프트",
    badge: "bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400",
    dot: "bg-brand-500",
  },
  rag: {
    label: "RAG 데이터",
    badge: "bg-violet-50 text-violet-600 dark:bg-violet-500/15 dark:text-violet-400",
    dot: "bg-violet-500",
  },
};

function ItemPreview({ item }: { item: PendingItem }) {
  if (item.itemType === "prompt") {
    return (
      <div className="px-5 py-4 bg-gray-50 dark:bg-white/[0.02] border-t border-gray-100 dark:border-white/[0.05]">
        <p className="mb-1.5 text-xs font-medium text-gray-500 dark:text-gray-400">프롬프트 내용</p>
        <pre className="whitespace-pre-wrap text-xs text-gray-700 dark:text-gray-300 leading-relaxed font-sans bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2.5">
          {item.prompt_content}
        </pre>
        <div className="mt-2 flex gap-4 text-xs text-gray-400 dark:text-gray-500">
          <span>타입: {item.prompt_type}</span>
          <span>사이즈: {item.prompt_size}</span>
          <span>등록자: {item.created_by}</span>
        </div>
      </div>
    );
  }
  return (
    <div className="px-5 py-4 bg-gray-50 dark:bg-white/[0.02] border-t border-gray-100 dark:border-white/[0.05]">
      <div className="flex gap-6 text-xs text-gray-500 dark:text-gray-400">
        <span>파일 형식: <span className="font-medium text-gray-700 dark:text-gray-300">{item.document_type}</span></span>
        <span>버전: <span className="font-medium text-gray-700 dark:text-gray-300">{item.document_version}</span></span>
        <span>크기: <span className="font-medium text-gray-700 dark:text-gray-300">{item.document_size}</span></span>
        <span>등록자: <span className="font-medium text-gray-700 dark:text-gray-300">{item.created_by}</span></span>
        <span>등록일: <span className="font-medium text-gray-700 dark:text-gray-300">{item.create_at}</span></span>
      </div>
    </div>
  );
}

export default function ApprovalComponent() {
  const { showToast } = useToast();
  const [items, setItems] = useState<PendingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterType>("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [confirmRejectId, setConfirmRejectId] = useState<string | null>(null);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  const fetchItems = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getPendingItems();
      setItems(data);
      setUpdatedAt(new Date());
    } catch {
      showToast("error", "대기 항목 조회에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { fetchItems(); }, [fetchItems]);

  const cid = (item: PendingItem) => `${item.itemType}-${getItemId(item)}`;

  const handleApprove = async (item: PendingItem) => {
    const key = cid(item);
    setProcessingId(key);
    try {
      await approveItem(item);
      setItems((prev) => prev.filter((i) => cid(i) !== key));
      setExpandedId(null);
      showToast("success", `"${getItemName(item)}" 이(가) 승인되었습니다.`);
    } catch {
      showToast("error", "승인에 실패했습니다.");
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (item: PendingItem) => {
    const key = cid(item);
    setProcessingId(key);
    setConfirmRejectId(null);
    try {
      await rejectItem(item);
      setItems((prev) => prev.filter((i) => cid(i) !== key));
      setExpandedId(null);
      showToast("info", `"${getItemName(item)}" 이(가) 거절되었습니다.`);
    } catch {
      showToast("error", "거절에 실패했습니다.");
    } finally {
      setProcessingId(null);
    }
  };

  const filtered = items.filter((item) => {
    if (filter === "all") return true;
    return item.itemType === filter;
  });

  const promptCount = items.filter((i) => i.itemType === "prompt").length;
  const ragCount = items.filter((i) => i.itemType === "rag").length;

  return (
    <div className="space-y-5">
      {/* 요약 카드 */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {/* 전체 */}
        <div className="col-span-2 sm:col-span-2 rounded-2xl border border-gray-200 bg-white px-5 py-4 dark:border-gray-800 dark:bg-white/[0.03]">
          <p className="text-xs text-gray-500 dark:text-gray-400">전체 대기</p>
          <div className="mt-1.5 flex items-end justify-between">
            <span className="text-3xl font-bold text-gray-800 dark:text-white/90">{loading ? "-" : items.length}</span>
            {lastUpdated && <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>}
          </div>
        </div>

        {/* 프롬프트 */}
        <div className="rounded-2xl border border-gray-200 bg-white px-5 py-4 dark:border-gray-800 dark:bg-white/[0.03]">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-brand-500" />
            <p className="text-xs text-gray-500 dark:text-gray-400">시스템 프롬프트</p>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white/90">{loading ? "-" : promptCount}</span>
        </div>

        {/* RAG */}
        <div className="rounded-2xl border border-gray-200 bg-white px-5 py-4 dark:border-gray-800 dark:bg-white/[0.03]">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-violet-500" />
            <p className="text-xs text-gray-500 dark:text-gray-400">RAG 데이터</p>
          </div>
          <span className="text-2xl font-bold text-gray-800 dark:text-white/90">{loading ? "-" : ragCount}</span>
        </div>
      </div>

      {/* 목록 카드 */}
      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
        {/* 헤더 */}
        <div className="flex flex-col gap-3 px-5 pt-5 pb-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <h4 className="text-xl font-semibold text-gray-800 dark:text-white/90">승인 대기 목록</h4>
            <p className="mt-0.5 text-sm text-gray-500 dark:text-gray-400">항목을 클릭하면 상세 내용을 확인할 수 있습니다.</p>
          </div>

          {/* 필터 탭 */}
          <div className="flex items-center gap-1 rounded-lg border border-gray-200 bg-gray-50 p-1 dark:border-gray-700 dark:bg-gray-800/50">
            {(["all", "prompt", "rag"] as FilterType[]).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  filter === f
                    ? "bg-white text-gray-800 shadow-sm dark:bg-gray-700 dark:text-white"
                    : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                }`}
              >
                {f === "all" && `전체 ${items.length}`}
                {f === "prompt" && (
                  <><span className="w-1.5 h-1.5 rounded-full bg-brand-500" />{`프롬프트 ${promptCount}`}</>
                )}
                {f === "rag" && (
                  <><span className="w-1.5 h-1.5 rounded-full bg-violet-500" />{`RAG ${ragCount}`}</>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* 로딩 */}
        {loading && (
          <div className="flex justify-center items-center py-20">
            <Spinner size="lg" />
          </div>
        )}

        {/* 빈 결과 */}
        {!loading && filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-2 text-gray-400">
            <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
              <path fillRule="evenodd" clipRule="evenodd" d="M9 2a1 1 0 000 2h6a1 1 0 000-2H9zM4 5a2 2 0 012-2 3 3 0 003 3h6a3 3 0 003-3 2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h8a1 1 0 000-2H7zm0 4a1 1 0 000 2h8a1 1 0 000-2H7zm0 4a1 1 0 000 2h4a1 1 0 000-2H7z" fill="currentColor" />
            </svg>
            <p className="text-sm font-medium">대기 중인 항목이 없습니다.</p>
            <p className="text-xs">모든 항목이 처리되었습니다.</p>
          </div>
        )}

        {/* 테이블 */}
        {!loading && filtered.length > 0 && (
          <div className="max-w-full overflow-x-auto">
            <Table>
              <TableHeader className="border-y border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  {["구분", "이름", "버전", "크기", "등록자", "등록일시", "작업"].map((h) => (
                    <TableCell key={h} isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400 whitespace-nowrap">
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((item) => {
                  const key = cid(item);
                  const cfg = TYPE_CONFIG[item.itemType];
                  const isExpanded = expandedId === key;
                  const isProcessing = processingId === key;
                  const isConfirmingReject = confirmRejectId === key;

                  return (
                    <Fragment key={key}>
                      <TableRow
                        onClick={() => {
                          if (isConfirmingReject) setConfirmRejectId(null);
                          setExpandedId(isExpanded ? null : key);
                        }}
                        className="cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-white/[0.02]"
                      >
                        {/* 구분 */}
                        <TableCell className="px-5 py-3.5">
                          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${cfg.badge}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
                            {cfg.label}
                          </span>
                        </TableCell>

                        {/* 이름 */}
                        <TableCell className="px-5 py-3.5">
                          <div className="flex items-center gap-2">
                            <svg
                              className={`w-3.5 h-3.5 text-gray-400 transition-transform duration-200 ${isExpanded ? "rotate-90" : ""}`}
                              fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                            </svg>
                            <span className="font-medium text-gray-800 text-theme-sm dark:text-white/90">{getItemName(item)}</span>
                          </div>
                        </TableCell>

                        <TableCell className="px-5 py-3.5 text-gray-500 text-theme-sm dark:text-gray-400">{getItemVersion(item)}</TableCell>
                        <TableCell className="px-5 py-3.5 text-gray-500 text-theme-sm dark:text-gray-400">{getItemSize(item)}</TableCell>
                        <TableCell className="px-5 py-3.5 text-gray-500 text-theme-sm dark:text-gray-400">{item.created_by}</TableCell>
                        <TableCell className="px-5 py-3.5 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{item.create_at}</TableCell>

                        {/* 작업 */}
                        <TableCell className="px-5 py-3.5" onClick={(e) => e.stopPropagation()}>
                          {isProcessing ? (
                            <Spinner size="sm" />
                          ) : isConfirmingReject ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">거절할까요?</span>
                              <button
                                type="button"
                                onClick={() => handleReject(item)}
                                className="inline-flex items-center h-7 px-2.5 rounded-md bg-error-500 text-xs font-medium text-white hover:bg-error-600 transition-colors"
                              >
                                확인
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmRejectId(null)}
                                className="inline-flex items-center h-7 px-2.5 rounded-md border border-gray-200 bg-white text-xs font-medium text-gray-600 hover:bg-gray-50 transition-colors dark:border-gray-700 dark:bg-white/[0.03] dark:text-gray-400"
                              >
                                취소
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleApprove(item)}
                                className="inline-flex items-center gap-1 h-7 px-2.5 rounded-md bg-success-500 text-xs font-medium text-white hover:bg-success-600 transition-colors"
                              >
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                                승인
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmRejectId(key)}
                                className="inline-flex items-center gap-1 h-7 px-2.5 rounded-md border border-error-200 bg-white text-xs font-medium text-error-600 hover:bg-error-50 transition-colors dark:border-error-500/30 dark:bg-white/[0.03] dark:text-error-400 dark:hover:bg-error-500/10"
                              >
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                                거절
                              </button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>

                      {/* 확장 미리보기 */}
                      {isExpanded && (
                        <tr className="border-b border-gray-100 dark:border-white/[0.05]">
                          <td colSpan={7} className="p-0">
                            <ItemPreview item={item} />
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
}
