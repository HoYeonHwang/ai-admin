import { useState, useEffect, useCallback } from "react";
import ComponentCard from "../common/ComponentCard";
import ServerInfoComponent from "./ServerInfoComponent";
import Switch from "../form/switch/Switch";
import Alert from "../ui/alert/Alert";
import { Modal } from "../ui/modal";
import Button from "../ui/button/Button";
import Spinner from "../ui/spinner/Spinner";
import { useToast } from "../../context/ToastContext";
import {
  getHealthCheck,
  getKillSwitchStatus,
  activateKillSwitch,
  deactivateKillSwitch,
  type ServiceHealth,
} from "../../api/killswitch";

const HEALTH_POLL_INTERVAL = 30_000;

export default function KillSwitchComponent() {
  const { showToast } = useToast();

  const [services, setServices] = useState<ServiceHealth[]>([]);
  const [healthLoading, setHealthLoading] = useState(false);

  const [killSwitchActive, setKillSwitchActive] = useState(false);
  const [activatedAt, setActivatedAt] = useState<string | undefined>();
  const [activatedBy, setActivatedBy] = useState<string | undefined>();
  const [statusLoading, setStatusLoading] = useState(true);

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingState, setPendingState] = useState(false);
  const [processing, setProcessing] = useState(false);

  const fetchHealth = useCallback(async () => {
    setHealthLoading(true);
    try {
      const data = await getHealthCheck();
      setServices(data);
    } catch {
      showToast("error", "헬스체크 조회에 실패했습니다.");
    } finally {
      setHealthLoading(false);
    }
  }, [showToast]);

  const fetchStatus = useCallback(async () => {
    try {
      const status = await getKillSwitchStatus();
      setKillSwitchActive(status.active);
      setActivatedAt(status.activated_at);
      setActivatedBy(status.activated_by);
    } catch {
      showToast("error", "Kill Switch 상태 조회에 실패했습니다.");
    } finally {
      setStatusLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchHealth();
    fetchStatus();

    const interval = setInterval(fetchHealth, HEALTH_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [fetchHealth, fetchStatus]);

  const handleSwitchChange = (next: boolean) => {
    setPendingState(next);
    setConfirmOpen(true);
  };

  const handleConfirm = async () => {
    setProcessing(true);
    try {
      if (pendingState) {
        await activateKillSwitch();
        showToast("success", "Kill Switch가 활성화되었습니다. 서비스가 중단됩니다.");
      } else {
        await deactivateKillSwitch();
        showToast("success", "Kill Switch가 해제되었습니다. 서비스가 재개됩니다.");
      }
      setKillSwitchActive(pendingState);
      await fetchStatus();
      await fetchHealth();
      setConfirmOpen(false);
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "처리에 실패했습니다.");
    } finally {
      setProcessing(false);
    }
  };

  const handleCancel = () => {
    setConfirmOpen(false);
  };

  const allHealthy = services.every((s) => s.status === "healthy");

  return (
    <>
      <div className="mb-2">
        <Alert
          variant="warning"
          title="Kill Switch 동작 전 안내"
          message="Kill Switch 동작 시 LLM 서비스 이용이 불가합니다. 반드시 확인 후 실행해주세요."
          showLink={false}
        />
      </div>

      <ComponentCard title="서비스 상태" className="mb-2">
        <ServerInfoComponent
          services={services}
          loading={healthLoading}
          onRefresh={fetchHealth}
        />
      </ComponentCard>

      <ComponentCard
        title="Kill Switch"
        desc="개인정보 유출의 위험이나 서비스의 긴급 정지가 필요한 경우 시스템을 종료할 수 있습니다."
      >
        {statusLoading ? (
          <div className="flex items-center gap-2 py-2">
            <Spinner size="sm" />
            <span className="text-sm text-gray-500">상태 확인 중...</span>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Switch
                label=""
                checked={killSwitchActive}
                onChange={handleSwitchChange}
                color={killSwitchActive ? "gray" : "blue"}
              />
              <div>
                <span className={`text-sm font-semibold ${killSwitchActive ? "text-error-500" : "text-success-500"}`}>
                  {killSwitchActive ? "서비스 중단됨" : "서비스 운영 중"}
                </span>
                {killSwitchActive && activatedAt && (
                  <p className="text-xs text-gray-400 mt-0.5">
                    {activatedBy && `${activatedBy} · `}{new Date(activatedAt).toLocaleString("ko-KR")}
                  </p>
                )}
              </div>
            </div>
            {!allHealthy && !killSwitchActive && (
              <span className="text-xs text-warning-500 font-medium">⚠ 일부 서비스 이상 감지됨</span>
            )}
          </div>
        )}
      </ComponentCard>

      {/* 확인 모달 */}
      <Modal isOpen={confirmOpen} onClose={handleCancel} className="max-w-md m-4" showCloseButton={false}>
        <div className="p-6 sm:p-8">
          {/* 아이콘 */}
          <div className={`mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full ${pendingState ? "bg-error-100 dark:bg-error-500/20" : "bg-success-100 dark:bg-success-500/20"}`}>
            {pendingState ? (
              <svg className="w-7 h-7 text-error-500" viewBox="0 0 24 24" fill="none">
                <path fillRule="evenodd" clipRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z" fill="currentColor" />
              </svg>
            ) : (
              <svg className="w-7 h-7 text-success-500" viewBox="0 0 24 24" fill="none">
                <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.207 7.793a1 1 0 00-1.414-1.414L10.5 12.672l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l5-5z" fill="currentColor" />
              </svg>
            )}
          </div>

          {/* 텍스트 */}
          <h4 className="text-center text-lg font-semibold text-gray-800 dark:text-white/90 mb-2">
            {pendingState ? "Kill Switch를 활성화하시겠습니까?" : "Kill Switch를 해제하시겠습니까?"}
          </h4>
          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mb-6">
            {pendingState
              ? "활성화 시 모든 LLM 서비스가 즉시 중단됩니다.\n이 작업은 서비스 이용자에게 영향을 미칩니다."
              : "해제 시 LLM 서비스가 다시 시작됩니다.\n서비스 재개까지 잠시 시간이 소요될 수 있습니다."}
          </p>

          {/* 버튼 */}
          <div className="flex gap-3">
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={handleCancel}
              disabled={processing}
            >
              취소
            </Button>
            <Button
              size="sm"
              className={`flex-1 ${pendingState ? "bg-error-500 hover:bg-error-600 text-white" : ""}`}
              onClick={handleConfirm}
              disabled={processing}
              startIcon={processing ? <Spinner size="sm" /> : undefined}
            >
              {processing ? "처리 중..." : pendingState ? "활성화" : "해제"}
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
}
