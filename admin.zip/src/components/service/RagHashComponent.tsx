import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import Spinner from "../ui/spinner/Spinner";
import { getRagChunks, type RagChunk } from "../../api/ragData";
import { useToast } from "../../context/ToastContext";

interface Props {
  ragId: string | null;
  documentName?: string;
}

export default function RagHashComponent({ ragId, documentName }: Props) {
  const { showToast } = useToast();
  const [chunks, setChunks] = useState<RagChunk[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!ragId) {
      setChunks([]);
      return;
    }
    setLoading(true);
    getRagChunks(ragId)
      .then(setChunks)
      .catch(() => showToast("error", "청크 조회에 실패했습니다."))
      .finally(() => setLoading(false));
  }, [ragId, showToast]);

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
      <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h4 className="text-xl font-semibold text-gray-800 dark:text-white/90">Chunk 내역</h4>
          <p className="mt-0.5 text-sm text-gray-500 dark:text-gray-400">
            {ragId && documentName
              ? `"${documentName}" 의 청크 및 Hash 내역을 확인합니다.`
              : "RAG 문서를 선택하면 청크 내역을 확인합니다."}
          </p>
        </div>
      </div>

      {/* 미선택 상태 */}
      {!ragId && (
        <div className="flex flex-col items-center justify-center py-16 gap-2 text-gray-400">
          <svg className="w-10 h-10 opacity-40" viewBox="0 0 24 24" fill="none">
            <path fillRule="evenodd" clipRule="evenodd" d="M4 4a2 2 0 012-2h8l6 6v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 0v16h12V9h-5V4H6zm7 0v4h4l-4-4z" fill="currentColor" />
          </svg>
          <p className="text-sm">위 목록에서 RAG 문서를 선택하세요.</p>
        </div>
      )}

      {/* 로딩 */}
      {ragId && loading && (
        <div className="flex justify-center items-center py-16">
          <Spinner size="lg" />
        </div>
      )}

      {/* 빈 결과 */}
      {ragId && !loading && chunks.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 gap-2 text-gray-400">
          <p className="text-sm">조회된 청크가 없습니다.</p>
        </div>
      )}

      {/* 테이블 */}
      {ragId && !loading && chunks.length > 0 && (
        <div className="max-w-full overflow-x-auto">
          <Table>
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                {["청크 ID", "RAG ID", "청크 번호", "청킹 데이터", "임베딩 값", "청크 사이즈", "Hash 값", "등록일자"].map((h) => (
                  <TableCell key={h} isHeader className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400 whitespace-nowrap">
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {chunks.map((chunk) => (
                <TableRow key={chunk.chunk_id}>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{chunk.chunk_id}</TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{chunk.rag_id}</TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">{chunk.chunk_num}</TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 max-w-xs">
                    <span className="block truncate" title={chunk.document_chunk}>{chunk.document_chunk}</span>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">{chunk.document_vector}</TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{chunk.chunk_size}</TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 font-mono text-xs">{chunk.hash_data}</TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{chunk.create_at}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
