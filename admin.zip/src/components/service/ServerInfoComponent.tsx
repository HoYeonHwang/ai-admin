import Badge from "../ui/badge/Badge";
import Spinner from "../ui/spinner/Spinner";
import { ArrowDownIcon, ArrowUpIcon } from "../../icons";
import type { ServiceHealth } from "../../api/killswitch";
import { useLastUpdated } from "../../hooks/useLastUpdated";

interface Props {
  services: ServiceHealth[];
  loading: boolean;
  onRefresh: () => void;
  updatedAt?: Date | null;
}

export default function ServerInfoComponent({ services, loading, onRefresh, updatedAt = null }: Props) {
  const lastUpdated = useLastUpdated(updatedAt);

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            서비스 {services.filter((s) => s.status === "healthy").length}/{services.length} 정상
          </span>
          {lastUpdated && (
            <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>
          )}
        </div>
        <button
          onClick={onRefresh}
          disabled={loading}
          className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors disabled:opacity-50"
        >
          <svg
            className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`}
            viewBox="0 0 24 24"
            fill="none"
          >
            <path d="M4 4v5h5M20 20v-5h-5M4 9a9 9 0 0115-2.66M20 15a9 9 0 01-15 2.66" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          새로고침
        </button>
      </div>

      {loading && services.length === 0 ? (
        <div className="flex justify-center py-8">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {services.map((service) => (
            <div
              key={service.name}
              className={`rounded-xl border p-3 transition-colors ${
                service.status === "healthy"
                  ? "border-success-200 bg-success-50 dark:border-success-500/20 dark:bg-success-500/10"
                  : service.status === "unhealthy"
                  ? "border-error-200 bg-error-50 dark:border-error-500/20 dark:bg-error-500/10"
                  : "border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-gray-800"
              }`}
            >
              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-2 truncate">
                {service.name}
              </p>
              <div className="flex items-center justify-between">
                <Badge
                  size="sm"
                  color={
                    service.status === "healthy"
                      ? "success"
                      : service.status === "unhealthy"
                      ? "error"
                      : "warning"
                  }
                >
                  {service.status === "healthy" ? (
                    <><ArrowUpIcon /> Active</>
                  ) : service.status === "unhealthy" ? (
                    <><ArrowDownIcon /> Down</>
                  ) : (
                    "Unknown"
                  )}
                </Badge>
                {service.status === "healthy" && (
                  <span className="text-xs text-gray-400">{service.latency_ms}ms</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
