import { useState, useEffect } from "react";
import Button from "../ui/button/Button";
import Input from "../form/input/InputField";
import Label from "../form/Label";
import Spinner from "../ui/spinner/Spinner";
import { useToast } from "../../context/ToastContext";
import { getSystemLimit, updateSystemLimit, type SystemLimit } from "../../api/systemLimit";

interface FormState {
  token_limit: string;
  request_limit: string;
}

const toForm = (data: Pick<SystemLimit, "token_limit" | "request_limit">): FormState => ({
  token_limit: String(data.token_limit),
  request_limit: String(data.request_limit),
});

export default function SystemLimitComponent() {
  const { showToast } = useToast();

  const [saved, setSaved] = useState<FormState>({ token_limit: "", request_limit: "" });
  const [form, setForm] = useState<FormState>({ token_limit: "", request_limit: "" });
  const [meta, setMeta] = useState<{ updated_at?: string; updated_by?: string }>({});

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const isDirty = form.token_limit !== saved.token_limit || form.request_limit !== saved.request_limit;

  useEffect(() => {
    getSystemLimit()
      .then((data) => {
        const values = toForm(data);
        setSaved(values);
        setForm(values);
        setMeta({ updated_at: data.updated_at, updated_by: data.updated_by });
      })
      .catch(() => showToast("error", "제한 설정 조회에 실패했습니다."))
      .finally(() => setLoading(false));
  }, [showToast]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const tokenLimit = Number(form.token_limit);
    const requestLimit = Number(form.request_limit);
    if (!form.token_limit || !form.request_limit || tokenLimit <= 0 || requestLimit <= 0) {
      showToast("warning", "제한 값은 1 이상이어야 합니다.");
      return;
    }
    setSaving(true);
    try {
      const updated = await updateSystemLimit({ token_limit: tokenLimit, request_limit: requestLimit });
      const values = toForm(updated);
      setSaved(values);
      setMeta({ updated_at: updated.updated_at, updated_by: updated.updated_by });
      showToast("success", "제한 설정이 저장되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "저장에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setForm(saved);
    showToast("info", "저장된 값으로 초기화되었습니다.");
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03] lg:p-10">
      <div className="mb-6">
        <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">
          사용 제한 설정
        </h4>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          입력 토큰 및 요청 횟수 제한을 설정합니다.
        </p>
        {meta.updated_at && (
          <p className="mt-1 text-xs text-gray-400">
            마지막 수정: {meta.updated_by && `${meta.updated_by} · `}{meta.updated_at}
          </p>
        )}
      </div>

      <form onSubmit={handleSave}>
        <div className="grid grid-cols-1 gap-x-8 gap-y-6 lg:grid-cols-2">

          {/* 입력 토큰 제한 */}
          <div className="rounded-xl border border-gray-200 bg-gray-50 p-5 dark:border-gray-700 dark:bg-gray-800/40">
            <Label>입력 토큰 제한 (일일)</Label>
            <div className="relative mt-1">
              <Input
                type="text"
                value={form.token_limit}
                onChange={(e) => setForm((p) => ({ ...p, token_limit: e.target.value.replace(/[^0-9]/g, "") }))}
                className="pr-14"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none">
                tokens
              </span>
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
              하루 동안 사용자가 입력할 수 있는 총 토큰 수를 제한합니다.
            </p>
            {form.token_limit !== saved.token_limit && (
              <p className="mt-1 text-xs text-warning-500">
                저장 전: {Number(saved.token_limit).toLocaleString()} tokens
              </p>
            )}
          </div>

          {/* 요청 횟수 제한 */}
          <div className="rounded-xl border border-gray-200 bg-gray-50 p-5 dark:border-gray-700 dark:bg-gray-800/40">
            <Label>요청 횟수 제한 (일일)</Label>
            <div className="relative mt-1">
              <Input
                type="text"
                value={form.request_limit}
                onChange={(e) => setForm((p) => ({ ...p, request_limit: e.target.value.replace(/[^0-9]/g, "") }))}
                className="pr-10"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 pointer-events-none">
                회
              </span>
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
              하루 동안 사용자가 요청할 수 있는 횟수를 제한합니다.
            </p>
            {form.request_limit !== saved.request_limit && (
              <p className="mt-1 text-xs text-warning-500">
                저장 전: {Number(saved.request_limit).toLocaleString()} 회
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 mt-8">
          <Button
            size="sm"
            variant="outline"
            type="button"
            onClick={handleReset}
            disabled={saving || !isDirty}
          >
            초기화
          </Button>
          <Button
            size="sm"
            type="submit"
            disabled={saving || !isDirty}
            startIcon={saving ? <Spinner size="sm" /> : undefined}
          >
            {saving ? "저장 중..." : "저장"}
          </Button>
        </div>
      </form>
    </div>
  );
}
