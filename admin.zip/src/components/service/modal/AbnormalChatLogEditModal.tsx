import { useState, useEffect } from "react";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Input from "../../form/input/InputField";
import Label from "../../form/Label";
import TextArea from "../../form/input/TextArea";
import Select from "../../form/Select";
import Spinner from "../../ui/spinner/Spinner";
import { updateAbnormalChatLog, type AbnormalChatLog, type AbnormalChatLogUpdateRequest } from "../../../api/abnormalChatLog";
import { useToast } from "../../../context/ToastContext";

const STATUS_OPTIONS = [
  { label: "Active", value: "Active" },
  { label: "Pending", value: "Pending" },
  { label: "Delete", value: "Delete" },
];

interface Props {
  isOpen: boolean;
  log: AbnormalChatLog | null;
  onClose: () => void;
  onSuccess: () => void;
}

export default function AbnormalChatLogEditModal({ isOpen, log, onClose, onSuccess }: Props) {
  const { showToast } = useToast();
  const [form, setForm] = useState<AbnormalChatLogUpdateRequest>({ status: "Active", admin_note: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (log) {
      setForm({ status: log.status, admin_note: log.admin_note });
    }
  }, [log]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!log) return;
    setSaving(true);
    try {
      await updateAbnormalChatLog(log.log_id, form);
      onSuccess();
      onClose();
      showToast("success", "이상 채팅 로그가 수정되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "수정에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="max-w-[700px] m-4">
      <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
        <div className="px-2 pr-14 mb-6">
          <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">이상 채팅 변경</h4>
          <p className="text-sm text-gray-500 dark:text-gray-400">이상 채팅 로그의 상태 및 의견을 변경합니다.</p>
        </div>

        <form onSubmit={handleSave}>
          <div className="custom-scrollbar max-h-[500px] overflow-y-auto px-2 pb-3 space-y-5">
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
              <div>
                <Label>고유 식별자</Label>
                <Input type="text" value={log?.log_id ?? ""} disabled />
              </div>
              <div>
                <Label>거래번호</Label>
                <Input type="text" value={log?.trx_no ?? ""} disabled />
              </div>
              <div>
                <Label>탐지 시스템</Label>
                <Input type="text" value={log?.detect_system ?? ""} disabled />
              </div>
              <div>
                <Label>상태</Label>
                <Select
                  key={log?.log_id}
                  options={STATUS_OPTIONS}
                  defaultValue={form.status}
                  onChange={(v) => setForm((p) => ({ ...p, status: v as AbnormalChatLog["status"] }))}
                />
              </div>
              <div>
                <Label>탐지 일시</Label>
                <Input type="text" value={log?.detect_at ?? ""} disabled />
              </div>
            </div>
            <div>
              <Label>원본 내용</Label>
              <TextArea value={log?.origin_content ?? ""} onChange={() => {}} rows={3} disabled />
            </div>
            <div>
              <Label>탐지 내용</Label>
              <TextArea value={log?.outlier_content ?? ""} onChange={() => {}} rows={3} disabled />
            </div>
            <div>
              <Label>의견</Label>
              <TextArea
                value={form.admin_note}
                onChange={(v) => setForm((p) => ({ ...p, admin_note: v }))}
                rows={4}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
            <Button size="sm" variant="outline" type="button" onClick={onClose} disabled={saving}>닫기</Button>
            <Button size="sm" type="submit" disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
              {saving ? "저장 중..." : "저장"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
