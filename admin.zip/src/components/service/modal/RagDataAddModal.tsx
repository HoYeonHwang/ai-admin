import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useModal } from "../../../hooks/useModal";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Spinner from "../../ui/spinner/Spinner";
import { createRagDocument } from "../../../api/ragData";
import { useToast } from "../../../context/ToastContext";

interface Props {
  onSuccess: () => void;
}

const ACCEPTED_TYPES = {
  "application/pdf": [".pdf"],
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
  "application/msword": [".doc"],
  "text/plain": [".txt"],
};

export default function RagDataAddModal({ onSuccess }: Props) {
  const { showToast } = useToast();
  const { isOpen, openModal, closeModal } = useModal();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) setSelectedFile(acceptedFiles[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    multiple: false,
  });

  const handleClose = () => {
    setSelectedFile(null);
    closeModal();
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      showToast("warning", "파일을 선택해주세요.");
      return;
    }
    setSaving(true);
    try {
      await createRagDocument(selectedFile);
      onSuccess();
      handleClose();
      showToast("success", "RAG 문서가 등록되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "등록에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md bg-brand-500 text-xs font-medium text-white hover:bg-brand-600 transition-colors"
      >
        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
        </svg>
        Add
      </button>

      <Modal isOpen={isOpen} onClose={handleClose} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14 mb-6">
            <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">RAG 데이터 등록</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">RAG 데이터를 등록합니다. (등록 후 상태: Pending)</p>
          </div>

          <form onSubmit={handleSave}>
            <div className="px-2 pb-3">
              {/* 드롭존 */}
              <div
                {...getRootProps()}
                className={`cursor-pointer rounded-xl border-2 border-dashed p-10 text-center transition-colors ${
                  isDragActive
                    ? "border-brand-500 bg-brand-50 dark:bg-brand-500/10"
                    : "border-gray-300 bg-gray-50 hover:border-brand-500 dark:border-gray-700 dark:bg-gray-800/40"
                }`}
              >
                <input {...getInputProps()} />
                <div className="flex flex-col items-center gap-3">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-400">
                    <svg className="fill-current" width="28" height="28" viewBox="0 0 29 28">
                      <path fillRule="evenodd" clipRule="evenodd" d="M14.5019 3.91699C14.2852 3.91699 14.0899 4.00891 13.953 4.15589L8.57363 9.53186C8.28065 9.82466 8.2805 10.2995 8.5733 10.5925C8.8661 10.8855 9.34097 10.8857 9.63396 10.5929L13.7519 6.47752V18.667C13.7519 19.0812 14.0877 19.417 14.5019 19.417C14.9161 19.417 15.2519 19.0812 15.2519 18.667V6.48234L19.3653 10.5929C19.6583 10.8857 20.1332 10.8855 20.426 10.5925C20.7188 10.2995 20.7186 9.82463 20.4256 9.53184L15.0838 4.19378C14.9463 4.02488 14.7367 3.91699 14.5019 3.91699ZM5.91626 18.667C5.91626 18.2528 5.58047 17.917 5.16626 17.917C4.75205 17.917 4.41626 18.2528 4.41626 18.667V21.8337C4.41626 23.0763 5.42362 24.0837 6.66626 24.0837H22.3339C23.5766 24.0837 24.5839 23.0763 24.5839 21.8337V18.667C24.5839 18.2528 24.2482 17.917 23.8339 17.917C23.4197 17.917 23.0839 18.2528 23.0839 18.667V21.8337C23.0839 22.2479 22.7482 22.5837 22.3339 22.5837H6.66626C6.25205 22.5837 5.91626 22.2479 5.91626 21.8337V18.667Z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-base font-semibold text-gray-800 dark:text-white/90">
                      {isDragActive ? "여기에 놓으세요" : "파일을 드래그하거나 클릭하여 선택"}
                    </p>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">PDF, DOCX, DOC, TXT 파일 지원</p>
                  </div>
                </div>
              </div>

              {/* 선택된 파일 표시 */}
              {selectedFile && (
                <div className="mt-4 flex items-center gap-3 rounded-lg border border-brand-200 bg-brand-50 px-4 py-3 dark:border-brand-500/30 dark:bg-brand-500/10">
                  <svg className="w-5 h-5 shrink-0 text-brand-500" viewBox="0 0 24 24" fill="none">
                    <path fillRule="evenodd" clipRule="evenodd" d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zm-1 1.5V8H18.5L13 3.5zM6 4h6v5h5v11H6V4z" fill="currentColor" />
                  </svg>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-brand-700 dark:text-brand-400">{selectedFile.name}</p>
                    <p className="text-xs text-brand-500">{(selectedFile.size / 1024).toFixed(1)} KB</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedFile(null)}
                    className="text-brand-400 hover:text-brand-600"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                      <path fillRule="evenodd" clipRule="evenodd" d="M6.225 4.811a1 1 0 011.414 0L12 9.172l4.361-4.361a1 1 0 111.414 1.414L13.414 10.586l4.361 4.361a1 1 0 01-1.414 1.414L12 12l-4.361 4.361a1 1 0 01-1.414-1.414l4.361-4.361-4.361-4.361a1 1 0 010-1.414z" />
                    </svg>
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
              <Button size="sm" variant="outline" type="button" onClick={handleClose} disabled={saving}>닫기</Button>
              <Button size="sm" type="submit" disabled={saving || !selectedFile} startIcon={saving ? <Spinner size="sm" /> : undefined}>
                {saving ? "등록 중..." : "등록"}
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </>
  );
}
