import { useState, useEffect } from "react";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Input from "../../form/input/InputField";
import Label from "../../form/Label";
import Select from "../../form/Select";
import Spinner from "../../ui/spinner/Spinner";
import { updateRagDocument, type RagDocument, type RagDocumentUpdateRequest } from "../../../api/ragData";
import { useToast } from "../../../context/ToastContext";

const STATUS_OPTIONS = [
  { label: "Active", value: "Active" },
  { label: "Pending", value: "Pending" },
  { label: "Delete", value: "Delete" },
];

interface Props {
  isOpen: boolean;
  document: RagDocument | null;
  onClose: () => void;
  onSuccess: () => void;
}

export default function RagDataEditModal({ isOpen, document, onClose, onSuccess }: Props) {
  const { showToast } = useToast();
  const [form, setForm] = useState<RagDocumentUpdateRequest>({ document_name: "", status: "Active" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (document) {
      setForm({ document_name: document.document_name, status: document.status });
    }
  }, [document]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!document) return;
    if (!form.document_name.trim()) {
      showToast("warning", "문서 이름을 입력해주세요.");
      return;
    }
    setSaving(true);
    try {
      await updateRagDocument(document.rag_id, form);
      onSuccess();
      onClose();
      showToast("success", "RAG 문서가 수정되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "수정에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="max-w-[700px] m-4">
      <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
        <div className="px-2 pr-14 mb-6">
          <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">RAG 데이터 변경</h4>
          <p className="text-sm text-gray-500 dark:text-gray-400">RAG 데이터의 내용을 변경합니다.</p>
        </div>

        <form onSubmit={handleSave}>
          <div className="custom-scrollbar max-h-[500px] overflow-y-auto px-2 pb-3 space-y-5">
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
              <div>
                <Label>RAG ID</Label>
                <Input type="text" value={document?.rag_id ?? ""} disabled />
              </div>
              <div>
                <Label>버전</Label>
                <Input type="text" value={document?.document_version ?? ""} disabled />
              </div>
              <div>
                <Label>문서 이름</Label>
                <Input
                  type="text"
                  value={form.document_name}
                  onChange={(e) => setForm((p) => ({ ...p, document_name: e.target.value }))}
                />
              </div>
              <div>
                <Label>문서 타입</Label>
                <Input type="text" value={document?.document_type ?? ""} disabled />
              </div>
              <div>
                <Label>문서 사이즈</Label>
                <Input type="text" value={document?.document_size ?? ""} disabled />
              </div>
              <div>
                <Label>상태</Label>
                <Select
                  key={document?.rag_id}
                  options={STATUS_OPTIONS}
                  defaultValue={form.status}
                  onChange={(v) => setForm((p) => ({ ...p, status: v as RagDocument["status"] }))}
                />
              </div>
              <div>
                <Label>등록자</Label>
                <Input type="text" value={document?.created_by ?? ""} disabled />
              </div>
              <div>
                <Label>등록일시</Label>
                <Input type="text" value={document?.create_at ?? ""} disabled />
              </div>
              <div>
                <Label>수정일시</Label>
                <Input type="text" value={document?.update_at ?? ""} disabled />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
            <Button size="sm" variant="outline" type="button" onClick={onClose} disabled={saving}>닫기</Button>
            <Button size="sm" type="submit" disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
              {saving ? "저장 중..." : "저장"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
