import { useState, useEffect } from "react";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Input from "../../form/input/InputField";
import Label from "../../form/Label";
import TextArea from "../../form/input/TextArea";
import Select from "../../form/Select";
import Spinner from "../../ui/spinner/Spinner";
import { updateRagOutlier, type RagOutlier, type RagOutlierUpdateRequest } from "../../../api/ragOutlier";
import { useToast } from "../../../context/ToastContext";

const STATUS_OPTIONS = [
  { label: "Active", value: "Active" },
  { label: "Pending", value: "Pending" },
  { label: "Delete", value: "Delete" },
];

interface Props {
  isOpen: boolean;
  outlier: RagOutlier | null;
  onClose: () => void;
  onSuccess: () => void;
}

export default function RagOutlierEditModal({ isOpen, outlier, onClose, onSuccess }: Props) {
  const { showToast } = useToast();
  const [form, setForm] = useState<RagOutlierUpdateRequest>({ status: "Active", outlier_note: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (outlier) {
      setForm({ status: outlier.status, outlier_note: outlier.outlier_note });
    }
  }, [outlier]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!outlier) return;
    setSaving(true);
    try {
      await updateRagOutlier(outlier.outlier_id, form);
      onSuccess();
      onClose();
      showToast("success", "위변조 내역이 수정되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "수정에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="max-w-[700px] m-4">
      <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
        <div className="px-2 pr-14 mb-6">
          <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">위변조 내역 변경</h4>
          <p className="text-sm text-gray-500 dark:text-gray-400">위변조 내역의 상태 및 메모를 변경합니다.</p>
        </div>

        <form onSubmit={handleSave}>
          <div className="custom-scrollbar max-h-[500px] overflow-y-auto px-2 pb-3 space-y-5">
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
              <div>
                <Label>고유 식별자</Label>
                <Input type="text" value={outlier?.outlier_id ?? ""} disabled />
              </div>
              <div>
                <Label>구분</Label>
                <Input type="text" value={outlier?.outlier_dcd ?? ""} disabled />
              </div>
              <div>
                <Label>원본 문서 ID</Label>
                <Input type="text" value={outlier?.origin_document_id ?? ""} disabled />
              </div>
              <div>
                <Label>상태</Label>
                <Select
                  key={outlier?.outlier_id}
                  options={STATUS_OPTIONS}
                  defaultValue={form.status}
                  onChange={(v) => setForm((p) => ({ ...p, status: v as RagOutlier["status"] }))}
                />
              </div>
              <div>
                <Label>검출 Hash 값</Label>
                <Input type="text" value={outlier?.outlier_hash ?? ""} disabled />
              </div>
              <div>
                <Label>원본 Hash 값</Label>
                <Input type="text" value={outlier?.origin_document_hash ?? ""} disabled />
              </div>
              <div>
                <Label>탐지 일시</Label>
                <Input type="text" value={outlier?.detect_at ?? ""} disabled />
              </div>
            </div>
            <div>
              <Label>메모</Label>
              <TextArea
                value={form.outlier_note}
                onChange={(v) => setForm((p) => ({ ...p, outlier_note: v }))}
                rows={5}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
            <Button size="sm" variant="outline" type="button" onClick={onClose} disabled={saving}>닫기</Button>
            <Button size="sm" type="submit" disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
              {saving ? "저장 중..." : "저장"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
