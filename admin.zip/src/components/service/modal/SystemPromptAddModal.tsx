import { useState } from "react";
import { useModal } from "../../../hooks/useModal";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Input from "../../form/input/InputField";
import Label from "../../form/Label";
import TextArea from "../../form/input/TextArea";
import Spinner from "../../ui/spinner/Spinner";
import { createSystemPrompt, type SystemPromptCreateRequest } from "../../../api/systemPrompt";
import { useToast } from "../../../context/ToastContext";

const EMPTY: SystemPromptCreateRequest = {
  prompt_name: "",
  prompt_type: "",
  prompt_content: "",
};

interface Props {
  onSuccess: () => void;
}

export default function SystemPromptAddModal({ onSuccess }: Props) {
  const { showToast } = useToast();
  const { isOpen, openModal, closeModal } = useModal();
  const [form, setForm] = useState<SystemPromptCreateRequest>(EMPTY);
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.prompt_name.trim() || !form.prompt_type.trim() || !form.prompt_content.trim()) {
      showToast("warning", "모든 항목을 입력해주세요.");
      return;
    }
    setSaving(true);
    try {
      await createSystemPrompt(form);
      onSuccess();
      handleClose();
      showToast("success", "시스템 프롬프트가 등록되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "등록에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setForm(EMPTY);
    closeModal();
  };

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md bg-brand-500 text-xs font-medium text-white hover:bg-brand-600 disabled:opacity-50 transition-colors"
      >
        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
        </svg>
        Add
      </button>

      <Modal isOpen={isOpen} onClose={handleClose} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14 mb-6">
            <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">시스템 프롬프트 등록</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">신규 시스템 프롬프트를 등록합니다. (등록 후 상태: Pending)</p>
          </div>

          <form onSubmit={handleSave}>
            <div className="custom-scrollbar max-h-[500px] overflow-y-auto px-2 pb-3 space-y-5">
              <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                <div>
                  <Label>프롬프트 이름</Label>
                  <Input
                    type="text"
                    placeholder="프롬프트 이름"
                    value={form.prompt_name}
                    onChange={(e) => setForm((p) => ({ ...p, prompt_name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>프롬프트 타입</Label>
                  <Input
                    type="text"
                    placeholder="예: WELSON 챗봇용"
                    value={form.prompt_type}
                    onChange={(e) => setForm((p) => ({ ...p, prompt_type: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <Label>프롬프트 내용</Label>
                <TextArea
                  placeholder="시스템 프롬프트 내용을 입력하세요."
                  value={form.prompt_content}
                  onChange={(v) => setForm((p) => ({ ...p, prompt_content: v }))}
                  rows={10}
                />
              </div>
            </div>

            <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
              <Button size="sm" variant="outline" type="button" onClick={handleClose} disabled={saving}>닫기</Button>
              <Button size="sm" type="submit" disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
                {saving ? "등록 중..." : "등록"}
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </>
  );
}
