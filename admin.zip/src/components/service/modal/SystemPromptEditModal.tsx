import { useState, useEffect } from "react";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Input from "../../form/input/InputField";
import Label from "../../form/Label";
import TextArea from "../../form/input/TextArea";
import Select from "../../form/Select";
import Spinner from "../../ui/spinner/Spinner";
import { updateSystemPrompt, type SystemPrompt, type SystemPromptUpdateRequest } from "../../../api/systemPrompt";
import { useToast } from "../../../context/ToastContext";

const STATUS_OPTIONS = [
  { label: "Active", value: "Active" },
  { label: "Pending", value: "Pending" },
  { label: "Delete", value: "Delete" },
];

interface Props {
  isOpen: boolean;
  prompt: SystemPrompt | null;
  onClose: () => void;
  onSuccess: () => void;
}

export default function SystemPromptEditModal({ isOpen, prompt, onClose, onSuccess }: Props) {
  const { showToast } = useToast();
  const [form, setForm] = useState<SystemPromptUpdateRequest>({ prompt_name: "", prompt_type: "", prompt_content: "", status: "Active" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (prompt) {
      setForm({
        prompt_name: prompt.prompt_name,
        prompt_type: prompt.prompt_type,
        prompt_content: prompt.prompt_content,
        status: prompt.status,
      });
    }
  }, [prompt]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;
    if (!form.prompt_name.trim() || !form.prompt_content.trim()) {
      showToast("warning", "이름과 내용을 입력해주세요.");
      return;
    }
    setSaving(true);
    try {
      await updateSystemPrompt(prompt.prompt_id, form);
      onSuccess();
      onClose();
      showToast("success", "시스템 프롬프트가 수정되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "수정에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} className="max-w-[700px] m-4">
      <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
        <div className="px-2 pr-14 mb-6">
          <h4 className="mb-1 text-2xl font-semibold text-gray-800 dark:text-white/90">시스템 프롬프트 수정</h4>
          <p className="text-sm text-gray-500 dark:text-gray-400">시스템 프롬프트 내용을 변경합니다.</p>
        </div>

        <form onSubmit={handleSave}>
          <div className="custom-scrollbar max-h-[500px] overflow-y-auto px-2 pb-3 space-y-5">
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
              <div>
                <Label>프롬프트 ID</Label>
                <Input type="text" value={prompt?.prompt_id ?? ""} disabled />
              </div>
              <div>
                <Label>버전</Label>
                <Input type="text" value={prompt?.prompt_version ?? ""} disabled />
              </div>
              <div>
                <Label>프롬프트 이름</Label>
                <Input
                  type="text"
                  value={form.prompt_name}
                  onChange={(e) => setForm((p) => ({ ...p, prompt_name: e.target.value }))}
                />
              </div>
              <div>
                <Label>프롬프트 타입</Label>
                <Input
                  type="text"
                  value={form.prompt_type}
                  onChange={(e) => setForm((p) => ({ ...p, prompt_type: e.target.value }))}
                />
              </div>
              <div>
                <Label>등록자</Label>
                <Input type="text" value={prompt?.created_by ?? ""} disabled />
              </div>
              <div>
                <Label>상태</Label>
                <Select
                  key={prompt?.prompt_id}
                  options={STATUS_OPTIONS}
                  defaultValue={form.status}
                  onChange={(v) => setForm((p) => ({ ...p, status: v as SystemPrompt["status"] }))}
                />
              </div>
              <div>
                <Label>등록일시</Label>
                <Input type="text" value={prompt?.create_at ?? ""} disabled />
              </div>
              <div>
                <Label>수정일시</Label>
                <Input type="text" value={prompt?.update_at ?? ""} disabled />
              </div>
            </div>
            <div>
              <Label>프롬프트 내용</Label>
              <TextArea
                value={form.prompt_content}
                onChange={(v) => setForm((p) => ({ ...p, prompt_content: v }))}
                rows={10}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
            <Button size="sm" variant="outline" type="button" onClick={onClose} disabled={saving}>닫기</Button>
            <Button size="sm" type="submit" disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
              {saving ? "저장 중..." : "저장"}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
}
