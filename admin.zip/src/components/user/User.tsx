import { useState, useEffect, useCallback } from "react";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import { Modal } from "../ui/modal";
import { UserCircleIcon } from "../../icons";
import { useModal } from "../../hooks/useModal";
import Badge from "../ui/badge/Badge";
import Button from "../ui/button/Button";
import Input from "../form/input/InputField";
import Label from "../form/Label";
import Select from "../form/Select";
import Spinner from "../ui/spinner/Spinner";
import UserAddModal from "./UserAddModal";
import { getUsers, updateUser, type User } from "../../api/user";
import { useToast } from "../../context/ToastContext";

const STATUS_OPTIONS = [
  { label: "Active", value: "Active" },
  { label: "Pending", value: "Pending" },
  { label: "Delete", value: "Delete" },
];

const ROLE_OPTIONS = [
  { label: "Admin", value: "Admin" },
  { label: "User", value: "User" },
];

export default function UserManagement() {
  const { showToast } = useToast();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const { isOpen, data: selectedUser, openModal, closeModal } = useModal<User>();
  const [form, setForm] = useState<Partial<User>>({});

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getUsers();
      setUsers(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "목록 조회에 실패했습니다.";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const handleRowClick = (user: User) => {
    setForm({
      user_name: user.user_name,
      user_department: user.user_department,
      user_email: user.user_email,
      status: user.status,
      user_role: user.user_role,
    });
    openModal(user);
  };

  const handleSave = async () => {
    if (!selectedUser) return;
    setSaving(true);
    try {
      await updateUser(selectedUser.user_id, form);
      await fetchUsers();
      closeModal();
      showToast("success", "사용자 정보가 저장되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "저장에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  const statusColor = (status: User["status"]) =>
    status === "Active" ? "success" : status === "Pending" ? "warning" : "error";

  return (
    <>
      <div className="rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
        <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">사용자</h3>
          <UserAddModal onSuccess={fetchUsers} />
        </div>

        {/* 로딩 */}
        {loading && (
          <div className="flex justify-center items-center py-16">
            <Spinner size="lg" />
          </div>
        )}

        {/* 에러 */}
        {!loading && error && (
          <div className="flex flex-col items-center justify-center py-16 gap-3 text-error-500">
            <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1 5a1 1 0 112 0v5a1 1 0 11-2 0V7zm1 10a1.25 1.25 0 110-2.5A1.25 1.25 0 0113 17z" fill="currentColor" />
            </svg>
            <p className="text-sm font-medium">{error}</p>
            <Button size="sm" variant="outline" onClick={fetchUsers}>다시 시도</Button>
          </div>
        )}

        {/* 테이블 */}
        {!loading && !error && (
          <div className="max-w-full overflow-x-auto">
            <Table>
              <TableHeader className="border-gray-100 dark:border-gray-800 border-y">
                <TableRow>
                  {["사용자 정보", "사번", "이메일 주소", "등록일시", "변경일시", "마지막 로그인", "권한", "상태"].map((h) => (
                    <TableCell key={h} isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-gray-100 dark:divide-gray-800">
                {users.map((user) => (
                  <TableRow
                    key={user.user_id}
                    className="cursor-pointer hover:bg-gray-50 dark:hover:bg-white/[0.03] transition-colors"
                    onClick={() => handleRowClick(user)}
                  >
                    <TableCell className="py-3">
                      <div className="flex items-center gap-3">
                        <UserCircleIcon className="h-10 w-10 text-gray-400" />
                        <div>
                          <p className="font-medium text-gray-800 text-theme-sm dark:text-white/90">{user.user_name}</p>
                          <span className="text-gray-500 text-theme-xs dark:text-gray-400">{user.user_department}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_id}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_email}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_create_at}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_update_at}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_last_login_at}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_role}</TableCell>
                    <TableCell className="py-3">
                      <Badge size="sm" color={statusColor(user.status)}>{user.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* 수정 모달 */}
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14 mb-6">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">사용자 정보 수정</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">사용자 정보 및 권한을 변경합니다.</p>
          </div>

          <div className="custom-scrollbar max-h-[500px] overflow-y-auto px-2 pb-3">
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
              <div>
                <Label>이름</Label>
                <Input value={form.user_name ?? ""} onChange={(e) => setForm((p) => ({ ...p, user_name: e.target.value }))} />
              </div>
              <div>
                <Label>사번</Label>
                <Input value={selectedUser?.user_id ?? ""} disabled />
              </div>
              <div>
                <Label>부서명</Label>
                <Input value={form.user_department ?? ""} onChange={(e) => setForm((p) => ({ ...p, user_department: e.target.value }))} />
              </div>
              <div>
                <Label>이메일 주소</Label>
                <Input value={form.user_email ?? ""} onChange={(e) => setForm((p) => ({ ...p, user_email: e.target.value }))} />
              </div>
              <div>
                <Label>등록일시</Label>
                <Input value={selectedUser?.user_create_at ?? ""} disabled />
              </div>
              <div>
                <Label>마지막 로그인</Label>
                <Input value={selectedUser?.user_last_login_at ?? ""} disabled />
              </div>
              <div>
                <Label>권한</Label>
                <Select
                  options={ROLE_OPTIONS}
                  defaultValue={form.user_role}
                  onChange={(v) => setForm((p) => ({ ...p, user_role: v as User["user_role"] }))}
                />
              </div>
              <div>
                <Label>상태</Label>
                <Select
                  options={STATUS_OPTIONS}
                  defaultValue={form.status}
                  onChange={(v) => setForm((p) => ({ ...p, status: v as User["status"] }))}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
            <Button size="sm" variant="outline" onClick={closeModal} disabled={saving}>닫기</Button>
            <Button size="sm" onClick={handleSave} disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
              {saving ? "저장 중..." : "저장"}
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
}
