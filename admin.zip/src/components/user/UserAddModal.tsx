import { useState, useRef } from "react";
import { useModal } from "../../hooks/useModal";
import { Modal } from "../ui/modal";
import Button from "../ui/button/Button";
import Input from "../form/input/InputField";
import Label from "../form/Label";
import Select from "../form/Select";
import Spinner from "../ui/spinner/Spinner";
import { createUser, type UserCreateRequest } from "../../api/user";
import { useToast } from "../../context/ToastContext";

const EMPTY_FORM: UserCreateRequest = {
  user_id: "",
  user_name: "",
  user_department: "",
  user_email: "",
  user_role: "User",
  status: "Active",
};

const FIELDS = [
  { name: "user_name", label: "이름", type: "input", placeholder: "이름" },
  { name: "user_id", label: "사번", type: "input", placeholder: "사번" },
  { name: "user_department", label: "부서명", type: "input", placeholder: "부서명" },
  { name: "user_email", label: "이메일 주소", type: "input", placeholder: "이메일 주소" },
  {
    name: "user_role",
    label: "권한",
    type: "select",
    options: [
      { label: "Admin", value: "Admin" },
      { label: "User", value: "User" },
    ],
  },
  {
    name: "status",
    label: "상태",
    type: "select",
    options: [
      { label: "Active", value: "Active" },
      { label: "Pending", value: "Pending" },
      { label: "Delete", value: "Delete" },
    ],
  },
];

interface Props {
  onSuccess?: () => void;
}

export default function UserAddModal({ onSuccess }: Props) {
  const { showToast } = useToast();
  const { isOpen, openModal, closeModal } = useModal();
  const [form, setForm] = useState<UserCreateRequest>(EMPTY_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof UserCreateRequest, boolean>>>({});
  const [saving, setSaving] = useState(false);
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const handleChange = (name: string, value: string) => {
    setForm((p) => ({ ...p, [name]: value }));
    setErrors((p) => ({ ...p, [name]: false }));
  };

  const validate = () => {
    for (const field of FIELDS) {
      const value = form[field.name as keyof UserCreateRequest];
      if (!value?.toString().trim()) {
        setErrors({ [field.name]: true });
        inputRefs.current[field.name]?.focus();
        return false;
      }
    }
    return true;
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      await createUser(form);
      onSuccess?.();
      handleClose();
      showToast("success", "사용자가 등록되었습니다.");
    } catch (err) {
      showToast("error", err instanceof Error ? err.message : "저장에 실패했습니다.");
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setForm(EMPTY_FORM);
    setErrors({});
    closeModal();
  };

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md bg-brand-500 text-xs font-medium text-white hover:bg-brand-600 transition-colors"
      >
        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
        </svg>
        Add
      </button>

      <Modal isOpen={isOpen} onClose={handleClose} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14 mb-6">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">사용자 등록</h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">신규 사용자를 등록합니다.</p>
          </div>

          <form onSubmit={handleSave}>
            <div className="custom-scrollbar max-h-[450px] overflow-y-auto px-2 pb-3">
              <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                {FIELDS.map((field) => (
                  <div key={field.name}>
                    <Label>{field.label}</Label>
                    {field.type === "select" ? (
                      <Select
                        options={field.options as { label: string; value: string }[]}
                        defaultValue={form[field.name as keyof UserCreateRequest]}
                        onChange={(v) => handleChange(field.name, v)}
                        className={errors[field.name as keyof UserCreateRequest] ? "border border-red-500 rounded" : ""}
                      />
                    ) : (
                      <Input
                        type="text"
                        placeholder={("placeholder" in field ? field.placeholder : "") as string}
                        value={form[field.name as keyof UserCreateRequest]}
                        onChange={(e) => handleChange(field.name, e.target.value)}
                        error={!!errors[field.name as keyof UserCreateRequest]}
                        ref={(el) => { inputRefs.current[field.name] = el; }}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
              <Button size="sm" variant="outline" onClick={handleClose} type="button" disabled={saving}>닫기</Button>
              <Button size="sm" type="submit" disabled={saving} startIcon={saving ? <Spinner size="sm" /> : undefined}>
                {saving ? "저장 중..." : "저장"}
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </>
  );
}
