import { useState, useCallback, useRef } from "react";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import Input from "../form/input/InputField";
import DatePicker from "../form/date-picker";
import Button from "../ui/button/Button";
import Spinner from "../ui/spinner/Spinner";
import { getConversations, type ChatHistory, type ConversationFilter } from "../../api/conversation";

const EMPTY_FILTER: ConversationFilter = {
  user_id: "",
  key: "",
  cls_dcd: "",
  opi_dcd: "",
  archive: "",
  startDate: "",
  endDate: "",
};

const CLS_DCD_OPTIONS = [
  { value: "", label: "피드백" },
  { value: "00", label: "00" },
  { value: "01", label: "01" },
  { value: "02", label: "02" },
];

const OPI_DCD_OPTIONS = [
  { value: "", label: "의견" },
  { value: "00", label: "00" },
  { value: "01", label: "01" },
  { value: "02", label: "02" },
  { value: "03", label: "03" },
  { value: "04", label: "04" },
  { value: "05", label: "05" },
  { value: "06", label: "06" },
];

const ARCHIVE_OPTIONS = [
  { value: "", label: "구분" },
  { value: "수신(교본)", label: "수신(교본)" },
  { value: "여신(규정)", label: "여신(규정)" },
  { value: "여신/총무", label: "여신/총무" },
  { value: "정보규정", label: "정보규정" },
];

const AI_MESSAGE_MAX = 60;

const truncate = (text: string) =>
  text.length > AI_MESSAGE_MAX ? text.slice(0, AI_MESSAGE_MAX) + "…" : text;

export default function UserConversation() {
  const [filter, setFilter] = useState<ConversationFilter>(EMPTY_FILTER);
  const [items, setItems] = useState<ChatHistory[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);
  const offsetRef = useRef(0);

  const hasMore = items.length < total;

  const fetchFirst = useCallback(async (currentFilter: ConversationFilter) => {
    setLoading(true);
    setError(null);
    offsetRef.current = 0;
    try {
      const res = await getConversations(currentFilter, 0);
      setItems(res.items);
      setTotal(res.total);
      offsetRef.current = res.items.length;
      setSearched(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "조회에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchMore = useCallback(async () => {
    setLoadingMore(true);
    try {
      const res = await getConversations(filter, offsetRef.current);
      setItems((prev) => [...prev, ...res.items]);
      offsetRef.current += res.items.length;
    } catch (err) {
      setError(err instanceof Error ? err.message : "조회에 실패했습니다.");
    } finally {
      setLoadingMore(false);
    }
  }, [filter]);

  const handleSearch = () => fetchFirst(filter);

  const setField = (key: keyof ConversationFilter, value: string) =>
    setFilter((p) => ({ ...p, [key]: value }));

  return (
    <div className="rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">

      {/* 필터 영역 */}
      <div className="mb-5 rounded-xl border border-gray-200 bg-gray-50 px-3 py-2 dark:border-gray-700 dark:bg-gray-800/40">
        <div className="flex items-center gap-1.5">

          {/* 텍스트 검색 */}
          <Input
            type="text"
            placeholder="사번"
            value={filter.user_id}
            onChange={(e) => setField("user_id", e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="!h-8 !py-1.5 !text-xs !px-3 w-20 shrink-0"
          />
          <Input
            type="text"
            placeholder="조회 키"
            value={filter.key}
            onChange={(e) => setField("key", e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="!h-8 !py-1.5 !text-xs !px-3 w-24 shrink-0"
          />

          <div className="shrink-0 h-4 w-px bg-gray-300 dark:bg-gray-600" />

          {/* 코드 필터 */}
          {([
            { opts: CLS_DCD_OPTIONS, field: "cls_dcd" as const, w: "w-24" },
            { opts: OPI_DCD_OPTIONS, field: "opi_dcd" as const, w: "w-24" },
            { opts: ARCHIVE_OPTIONS, field: "archive" as const, w: "w-28" },
          ] as const).map(({ opts, field, w }) => (
            <div key={field} className={`relative shrink-0 ${w}`}>
              <select
                value={filter[field]}
                onChange={(e) => setField(field, e.target.value)}
                className="h-8 w-full appearance-none rounded-md border border-gray-200 bg-white pl-2.5 pr-6 text-xs text-gray-600 focus:border-brand-300 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 cursor-pointer"
              >
                {opts.map((o) => (
                  <option key={o.value} value={o.value} className="dark:bg-gray-900">{o.label}</option>
                ))}
              </select>
              <svg className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          ))}

          <div className="shrink-0 h-4 w-px bg-gray-300 dark:bg-gray-600" />

          {/* 날짜 범위 */}
          <div className="shrink-0 w-28 [&_input]:!h-8 [&_input]:!py-1.5 [&_input]:!text-xs [&_input]:!px-3">
            <DatePicker id="conv_start_date" placeholder="시작일자" onChange={(_, d) => setField("startDate", d)} />
          </div>
          <span className="shrink-0 text-xs text-gray-400 select-none">~</span>
          <div className="shrink-0 w-28 [&_input]:!h-8 [&_input]:!py-1.5 [&_input]:!text-xs [&_input]:!px-3">
            <DatePicker id="conv_end_date" placeholder="종료일자" onChange={(_, d) => setField("endDate", d)} />
          </div>

          {/* 조회 버튼 */}
          <button
            type="button"
            onClick={handleSearch}
            disabled={loading}
            className="shrink-0 ml-auto inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-brand-500 text-xs font-medium text-white hover:bg-brand-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading
              ? <Spinner size="sm" />
              : <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none"><path fillRule="evenodd" clipRule="evenodd" d="M10.5 3a7.5 7.5 0 105.185 12.894l3.71 3.71a1 1 0 001.414-1.414l-3.71-3.71A7.5 7.5 0 0010.5 3zm-5.5 7.5a5.5 5.5 0 1111 0 5.5 5.5 0 01-11 0z" fill="currentColor" /></svg>
            }
            {loading ? "조회 중..." : "조회"}
          </button>
        </div>
      </div>

      {/* 결과 건수 */}
      {searched && !loading && (
        <p className="mb-2 text-xs text-gray-500 dark:text-gray-400">
          전체 <span className="font-semibold text-gray-700 dark:text-gray-200">{total}</span>건
        </p>
      )}

      {/* 로딩 */}
      {loading && (
        <div className="flex justify-center items-center py-16">
          <Spinner size="lg" />
        </div>
      )}

      {/* 에러 */}
      {!loading && error && (
        <div className="flex flex-col items-center justify-center py-16 gap-3 text-error-500">
          <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
            <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1 5a1 1 0 112 0v5a1 1 0 11-2 0V7zm1 10a1.25 1.25 0 110-2.5A1.25 1.25 0 0113 17z" fill="currentColor" />
          </svg>
          <p className="text-sm font-medium">{error}</p>
          <Button size="sm" variant="outline" onClick={handleSearch}>다시 시도</Button>
        </div>
      )}

      {/* 초기 안내 */}
      {!loading && !error && !searched && (
        <div className="flex flex-col items-center justify-center py-16 gap-2 text-gray-400">
          <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
            <path fillRule="evenodd" clipRule="evenodd" d="M10.5 3a7.5 7.5 0 105.185 12.894l3.71 3.71a1 1 0 001.414-1.414l-3.71-3.71A7.5 7.5 0 0010.5 3zm-5.5 7.5a5.5 5.5 0 1111 0 5.5 5.5 0 01-11 0z" fill="currentColor" />
          </svg>
          <p className="text-sm">조건을 입력하고 조회 버튼을 눌러주세요.</p>
        </div>
      )}

      {/* 빈 결과 */}
      {!loading && !error && searched && items.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 gap-2 text-gray-400">
          <p className="text-sm">조회된 대화 내역이 없습니다.</p>
        </div>
      )}

      {/* 테이블 */}
      {!loading && !error && items.length > 0 && (
        <>
          <div className="max-w-full overflow-x-auto">
            <Table>
              <TableHeader className="border-gray-100 dark:border-gray-800 border-y">
                <TableRow>
                  {["사번", "구분", "키", "일련번호", "질문 내용", "AI 응답 내용", "피드백", "의견 코드", "의견 내용", "시간"].map((h) => (
                    <TableCell key={h} isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400 whitespace-nowrap">
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-gray-100 dark:divide-gray-800">
                {items.map((row, idx) => (
                  <TableRow key={`${row.user_id}-${row.sequence}-${idx}`}>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{row.user_id}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{row.archive}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{row.key}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{row.sequence}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 max-w-[200px]">{truncate(row.HumanMessage)}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 max-w-[200px]">{truncate(row.AIMessage)}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{row.cls_dcd}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{row.opi_dcd}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 max-w-[150px]">{row.opi_cont || "-"}</TableCell>
                    <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400 whitespace-nowrap">{row.timestamp}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* 더 보기 */}
          {hasMore && (
            <div className="flex justify-center mt-4">
              <Button size="sm" variant="outline" onClick={fetchMore} disabled={loadingMore} startIcon={loadingMore ? <Spinner size="sm" /> : undefined}>
                {loadingMore ? "불러오는 중..." : `더 보기 (${items.length} / ${total})`}
              </Button>
            </div>
          )}

          {!hasMore && (
            <p className="text-center mt-4 text-xs text-gray-400">모든 내역을 불러왔습니다. ({total}건)</p>
          )}
        </>
      )}
    </div>
  );
}
