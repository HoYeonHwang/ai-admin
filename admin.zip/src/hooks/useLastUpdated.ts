import { useState, useEffect } from "react";

function format(date: Date): string {
  const diffMin = Math.floor((Date.now() - date.getTime()) / 60000);
  if (diffMin < 1) return "방금 전";
  return `${diffMin}분 전`;
}

export function useLastUpdated(updatedAt: Date | null): string {
  const [label, setLabel] = useState(updatedAt ? format(updatedAt) : "");

  useEffect(() => {
    if (!updatedAt) return;
    setLabel(format(updatedAt));
    const id = setInterval(() => setLabel(format(updatedAt)), 60000);
    return () => clearInterval(id);
  }, [updatedAt]);

  return label;
}
