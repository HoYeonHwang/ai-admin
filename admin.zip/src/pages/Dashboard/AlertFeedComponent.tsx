import { useState, useEffect } from "react";
import Spinner from "../../components/ui/spinner/Spinner";
import { getNotifications, type Notification, type NotificationType } from "../../api/notification";

const TYPE_CONFIG: Record<NotificationType, { dot: string; label: string }> = {
  error:   { dot: "bg-error-500",   label: "오류" },
  warning: { dot: "bg-warning-500", label: "경고" },
  info:    { dot: "bg-brand-500",   label: "정보" },
  success: { dot: "bg-success-500", label: "완료" },
};

function formatTime(dateStr: string) {
  const d = new Date(dateStr.replace(" ", "T"));
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 60) return `${diffMin}분 전`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `${diffHour}시간 전`;
  return `${Math.floor(diffHour / 24)}일 전`;
}

export default function AlertFeedComponent() {
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getNotifications()
      .then(setItems)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-5 pt-5 pb-5 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6 sm:pt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">최근 이상 징후</h3>
        {!loading && (
          <span className="text-xs text-gray-400 dark:text-gray-500">
            미확인 {items.filter((n) => !n.is_read).length}건
          </span>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-10">
          <Spinner size="md" />
        </div>
      ) : items.length === 0 ? (
        <p className="py-6 text-center text-sm text-gray-400">이상 징후 없음</p>
      ) : (
        <div className="relative">
          {/* 타임라인 세로선 */}
          <div className="absolute left-[7px] top-2 bottom-2 w-px bg-gray-100 dark:bg-gray-800" />
          <ul className="space-y-4">
            {items.map((item) => {
              const cfg = TYPE_CONFIG[item.type];
              return (
                <li key={item.notification_id} className="flex gap-3 pl-1">
                  <div className="relative flex-shrink-0 mt-1">
                    <span className={`block w-3.5 h-3.5 rounded-full border-2 border-white dark:border-gray-900 ${cfg.dot}`} />
                  </div>
                  <div className={`flex-1 ${item.is_read ? "opacity-50" : ""}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium text-gray-800 dark:text-white/90 leading-tight">
                        {item.title}
                      </span>
                      <span className="flex-shrink-0 text-xs text-gray-400 dark:text-gray-500">
                        {formatTime(item.created_at)}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                      {item.message}
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
