import { useState, useEffect } from "react";
import Spinner from "../../components/ui/spinner/Spinner";
import { getErrorRates, type ServiceErrorRate } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

function getErrorColor(rate: number) {
  if (rate >= 5) return { bar: "bg-error-500", badge: "bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-400" };
  if (rate >= 2) return { bar: "bg-warning-500", badge: "bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-warning-400" };
  return { bar: "bg-success-500", badge: "bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-400" };
}

export default function ErrorRateComponent() {
  const [data, setData] = useState<ServiceErrorRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getErrorRates()
      .then((d) => { setData(d); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-5 pt-5 pb-5 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6 sm:pt-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">서비스 에러율</h3>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
            <span className="inline-block w-2 h-2 rounded-full bg-success-500 mr-1" />{"< 2% 정상"}
            <span className="inline-block w-2 h-2 rounded-full bg-warning-500 mx-1 ml-3" />{"2–5% 주의"}
            <span className="inline-block w-2 h-2 rounded-full bg-error-500 mx-1 ml-3" />{"> 5% 위험"}
          </p>
        </div>
        {lastUpdated && (
          <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-10">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="space-y-4">
          {data.map((svc) => {
            const color = getErrorColor(svc.error_rate);
            const barWidth = Math.min(100, svc.error_rate * 5);
            return (
              <div key={svc.service_name}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm font-medium text-gray-700 dark:text-white/80">{svc.service_name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400 dark:text-gray-500">
                      {svc.error_count.toLocaleString()} / {svc.request_count.toLocaleString()}건
                    </span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${color.badge}`}>
                      {svc.error_rate.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div className="h-2 w-full rounded-full bg-gray-100 dark:bg-gray-700">
                  <div
                    className={`h-2 rounded-full transition-all duration-500 ${color.bar}`}
                    style={{ width: `${barWidth}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
