import { useState, useEffect, useCallback } from "react";
import TodayComponent from "./TodayComponent";
import MonthlyChart from "./MonthlyChart";
import MonthlyTarget from "./MonthlyTarget";
import ServiceUsageComponent from "./ServiceUsageComponent";
import ErrorRateComponent from "./ErrorRateComponent";
import ResponseTimeTrendComponent from "./ResponseTimeTrendComponent";
import AlertFeedComponent from "./AlertFeedComponent";
import SessionHeatmapComponent from "./SessionHeatmapComponent";
import PageMeta from "../../components/common/PageMeta";
import ServerInfoComponent from "../../components/service/ServerInfoComponent";
import ComponentCard from "../../components/common/ComponentCard";
import { getHealthCheck, type ServiceHealth } from "../../api/killswitch";

export default function Home() {
  const [services, setServices] = useState<ServiceHealth[]>([]);
  const [loadingServices, setLoadingServices] = useState(true);
  const [healthUpdatedAt, setHealthUpdatedAt] = useState<Date | null>(null);

  const fetchHealth = useCallback(async () => {
    try {
      const data = await getHealthCheck();
      setServices(data);
      setHealthUpdatedAt(new Date());
    } catch {
      // 조회 실패 시 빈 배열 유지
    } finally {
      setLoadingServices(false);
    }
  }, []);

  useEffect(() => {
    fetchHealth();
  }, [fetchHealth]);

  return (
    <>
      <PageMeta title="현황 대시보드" />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        {/* 금일 사용자 / 금일 질문 수 + 월간 차트 */}
        <div className="col-span-12 space-y-6 xl:col-span-7">
          <TodayComponent />
          <MonthlyChart />
        </div>

        {/* 토큰 사용량 + 최근 이상 징후 */}
        <div className="col-span-12 space-y-6 xl:col-span-5">
          <MonthlyTarget />
          <AlertFeedComponent />
        </div>

        {/* 응답시간 추이 */}
        <div className="col-span-12">
          <ResponseTimeTrendComponent />
        </div>

        {/* 서비스 사용량 + 에러율 */}
        <div className="col-span-12 xl:col-span-7">
          <ServiceUsageComponent />
        </div>
        <div className="col-span-12 xl:col-span-5">
          <ErrorRateComponent />
        </div>

        {/* 사용자 세션 분포 히트맵 */}
        <div className="col-span-12">
          <SessionHeatmapComponent />
        </div>

        {/* 서비스 상태 */}
        <div className="col-span-12">
          <ComponentCard title="서비스 상태">
            <ServerInfoComponent
              services={services}
              loading={loadingServices}
              onRefresh={fetchHealth}
              updatedAt={healthUpdatedAt}
            />
          </ComponentCard>
        </div>
      </div>
    </>
  );
}
