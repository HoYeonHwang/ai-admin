import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import Spinner from "../../components/ui/spinner/Spinner";
import { getMonthlyUsage, type MonthlyUsage } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

export default function MonthlyChart() {
  const [data, setData] = useState<MonthlyUsage | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getMonthlyUsage()
      .then((d) => { setData(d); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  const options: ApexOptions = {
    colors: ["#f03a1a", "#ffc2b0"],
    chart: {
      fontFamily: "Outfit, sans-serif",
      type: "bar",
      height: 180,
      toolbar: { show: false },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "39%",
        borderRadius: 5,
        borderRadiusApplication: "end",
      },
    },
    dataLabels: { enabled: false },
    stroke: { show: true, width: 4, colors: ["transparent"] },
    xaxis: {
      categories: data?.months ?? [],
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    legend: {
      show: true,
      position: "top",
      horizontalAlign: "left",
      fontFamily: "Outfit",
    },
    yaxis: { title: { text: undefined } },
    grid: { yaxis: { lines: { show: true } } },
    fill: { opacity: 1 },
    tooltip: {
      x: { show: false },
      y: { formatter: (val: number) => `${val.toLocaleString()}` },
    },
  };

  const series = [
    { name: "질문 수", data: data?.question_counts ?? [] },
    { name: "사용자 수", data: data?.user_counts ?? [] },
  ];

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-5 pt-5 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6 sm:pt-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">월간 사용량</h3>
        {lastUpdated && (
          <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-[180px]">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="max-w-full overflow-x-auto custom-scrollbar">
          <div className="-ml-5 min-w-[650px] xl:min-w-full pl-2">
            <Chart options={options} series={series} type="bar" height={180} />
          </div>
        </div>
      )}
    </div>
  );
}
