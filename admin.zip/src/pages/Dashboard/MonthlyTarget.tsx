import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import Spinner from "../../components/ui/spinner/Spinner";
import { getTokenUsage, type TokenUsage } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

export default function MonthlyTarget() {
  const [data, setData] = useState<TokenUsage | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getTokenUsage()
      .then((d) => { setData(d); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  const usedPct = data?.used_pct ?? 0;
  const isOver = usedPct >= 90;

  const options: ApexOptions = {
    colors: ["#f03a1a"],
    chart: {
      fontFamily: "Outfit, sans-serif",
      type: "radialBar",
      height: 330,
      sparkline: { enabled: true },
    },
    plotOptions: {
      radialBar: {
        startAngle: -85,
        endAngle: 85,
        hollow: { size: "80%" },
        track: {
          background: "#FFE8E2",
          strokeWidth: "100%",
          margin: 5,
        },
        dataLabels: {
          name: { show: false },
          value: {
            fontSize: "36px",
            fontWeight: "600",
            offsetY: -40,
            color: "#1D2939",
            formatter: (val) => val + "%",
          },
        },
      },
    },
    fill: { type: "solid", colors: ["#f03a1a"] },
    stroke: { lineCap: "round" },
    labels: ["사용량"],
  };

  const fmt = (n: number) => n.toLocaleString();

  return (
    <div className="rounded-2xl border border-gray-200 bg-gray-100 dark:border-gray-800 dark:bg-white/[0.03]">
      <div className="px-5 pt-5 bg-white shadow-default rounded-2xl pb-11 dark:bg-gray-900 sm:px-6 sm:pt-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">토큰 사용량</h3>
            <p className="mt-1 text-gray-500 text-theme-sm dark:text-gray-400">현재 월 토큰 전체 대비 사용량</p>
          </div>
          {lastUpdated && (
            <span className="text-xs text-gray-400 dark:text-gray-500 mt-1">{lastUpdated} 갱신</span>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-[330px]">
            <Spinner size="md" />
          </div>
        ) : (
          <>
            <div className="relative">
              <div className="max-h-[330px]" id="chartDarkStyle">
                <Chart options={options} series={[usedPct]} type="radialBar" height={330} />
              </div>
              <span className={`absolute left-1/2 top-full -translate-x-1/2 -translate-y-[95%] rounded-full px-3 py-1 text-xs font-medium ${
                isOver
                  ? "bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500"
                  : "bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400"
              }`}>
                {isOver ? `⚠️ ${usedPct}% 초과 주의` : `사용 ${usedPct}%`}
              </span>
            </div>
            <p className="mx-auto mt-10 w-full max-w-[380px] text-center text-sm text-gray-500 sm:text-base">
              {isOver
                ? `⚠️ 한도 대비 ${usedPct}% 사용 중입니다. 한도 조정을 검토하세요.`
                : `총 ${fmt(data!.limit_tokens)} 토큰 중 ${fmt(data!.limit_tokens - data!.remaining_tokens)} 사용 중입니다.`}
            </p>
          </>
        )}
      </div>

      <div className="flex items-center justify-center gap-5 px-6 py-3.5 sm:gap-8 sm:py-5">
        <div>
          <p className="mb-1 text-center text-gray-500 text-theme-xs dark:text-gray-400 sm:text-sm">잔여 토큰</p>
          <p className="flex items-center justify-center gap-1 text-base font-semibold text-gray-800 dark:text-white/90 sm:text-lg">
            {loading ? "-" : fmt(data!.remaining_tokens)}
          </p>
        </div>
        <div className="w-px bg-gray-200 h-7 dark:bg-gray-800" />
        <div>
          <p className="mb-1 text-center text-gray-500 text-theme-xs dark:text-gray-400 sm:text-sm">일평균 사용</p>
          <p className="flex items-center justify-center gap-1 text-base font-semibold text-gray-800 dark:text-white/90 sm:text-lg">
            {loading ? "-" : fmt(data!.avg_daily_tokens)}
          </p>
        </div>
        <div className="w-px bg-gray-200 h-7 dark:bg-gray-800" />
        <div>
          <p className="mb-1 text-center text-gray-500 text-theme-xs dark:text-gray-400 sm:text-sm">금일 사용</p>
          <p className="flex items-center justify-center gap-1 text-base font-semibold text-gray-800 dark:text-white/90 sm:text-lg">
            {loading ? "-" : fmt(data!.today_tokens)}
          </p>
        </div>
      </div>
    </div>
  );
}
