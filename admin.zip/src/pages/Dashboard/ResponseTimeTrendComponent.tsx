import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import Spinner from "../../components/ui/spinner/Spinner";
import { getResponseTimeTrend, type ResponseTimePoint } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

export default function ResponseTimeTrendComponent() {
  const [data, setData] = useState<ResponseTimePoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getResponseTimeTrend()
      .then((d) => { setData(d); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  const options: ApexOptions = {
    colors: ["#f03a1a", "#ffc2b0"],
    chart: {
      fontFamily: "Outfit, sans-serif",
      type: "line",
      height: 200,
      toolbar: { show: false },
      zoom: { enabled: false },
    },
    stroke: { curve: "smooth", width: [2, 2], dashArray: [0, 4] },
    dataLabels: { enabled: false },
    markers: { size: 0 },
    xaxis: {
      categories: data.map((d) => d.time),
      tickAmount: 8,
      axisBorder: { show: false },
      axisTicks: { show: false },
      labels: { style: { fontSize: "11px" } },
    },
    yaxis: {
      title: { text: "ms", style: { fontSize: "11px" } },
      labels: { formatter: (v) => `${v}ms` },
    },
    legend: {
      show: true,
      position: "top",
      horizontalAlign: "left",
      fontFamily: "Outfit",
    },
    grid: { yaxis: { lines: { show: true } } },
    tooltip: {
      y: { formatter: (v) => `${v}ms` },
    },
  };

  const series = [
    { name: "p50 (중앙값)", data: data.map((d) => d.p50) },
    { name: "p95", data: data.map((d) => d.p95) },
  ];

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-5 pt-5 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6 sm:pt-6">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">응답시간 추이</h3>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">오늘 시간대별 p50 / p95 응답시간</p>
        </div>
        {lastUpdated && (
          <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-[200px]">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="max-w-full overflow-x-auto custom-scrollbar">
          <div className="-ml-5 min-w-[600px] xl:min-w-full pl-2">
            <Chart options={options} series={series} type="line" height={200} />
          </div>
        </div>
      )}
    </div>
  );
}
