import { useState, useEffect } from "react";
import Spinner from "../../components/ui/spinner/Spinner";
import { getServiceUsage, type ServiceUsage } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

export default function ServiceUsageComponent() {
  const [services, setServices] = useState<ServiceUsage[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getServiceUsage()
      .then((data) => { setServices(data); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  const fmt = (n: number) => n.toLocaleString();

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-4 pb-4 pt-5 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">서비스 사용량</h3>
        {lastUpdated && (
          <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-10">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {services.map((svc) => (
            <div
              key={svc.service_name}
              className="rounded-xl border border-gray-100 bg-gray-50 p-4 dark:border-gray-800 dark:bg-white/[0.02]"
            >
              <p className="text-sm font-medium text-gray-700 dark:text-white/80 mb-3">{svc.service_name}</p>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500 dark:text-gray-400">요청 수</span>
                  <span className="font-semibold text-gray-800 dark:text-white/90">{fmt(svc.request_count)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500 dark:text-gray-400">토큰 사용</span>
                  <span className="font-semibold text-gray-800 dark:text-white/90">{fmt(svc.token_count)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500 dark:text-gray-400">평균 응답</span>
                  <span className="font-semibold text-gray-800 dark:text-white/90">{svc.avg_response_ms}ms</span>
                </div>
              </div>
              {/* 요청 비율 바 */}
              <div className="mt-3">
                <div className="h-1.5 w-full rounded-full bg-gray-200 dark:bg-gray-700">
                  <div
                    className="h-1.5 rounded-full bg-brand-500"
                    style={{
                      width: `${Math.min(100, (svc.request_count / Math.max(...services.map((s) => s.request_count))) * 100).toFixed(1)}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
