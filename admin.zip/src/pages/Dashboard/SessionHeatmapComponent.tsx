import { useState, useEffect } from "react";
import Chart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import Spinner from "../../components/ui/spinner/Spinner";
import { getSessionHeatmap, type SessionHeatmapData } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

export default function SessionHeatmapComponent() {
  const [data, setData] = useState<SessionHeatmapData | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getSessionHeatmap()
      .then((d) => { setData(d); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  const series = data
    ? data.days.map((day, i) => ({
        name: day,
        data: data.hours.map((hour, h) => ({ x: hour, y: data.counts[i][h] })),
      }))
    : [];

  const options: ApexOptions = {
    chart: {
      fontFamily: "Outfit, sans-serif",
      type: "heatmap",
      height: 200,
      toolbar: { show: false },
    },
    dataLabels: { enabled: false },
    colors: ["#f03a1a"],
    plotOptions: {
      heatmap: {
        shadeIntensity: 0.65,
        radius: 4,
        useFillColorAsStroke: false,
        colorScale: {
          ranges: [
            { from: 0,  to: 5,   color: "#FFF5F3", name: "매우 낮음" },
            { from: 6,  to: 20,  color: "#FFCFC5", name: "낮음" },
            { from: 21, to: 50,  color: "#FF8B72", name: "보통" },
            { from: 51, to: 75,  color: "#F05A3B", name: "높음" },
            { from: 76, to: 999, color: "#C62B10", name: "매우 높음" },
          ],
        },
      },
    },
    xaxis: {
      type: "category",
      tickAmount: 8,
      axisBorder: { show: false },
      axisTicks: { show: false },
      labels: { style: { fontSize: "11px" } },
    },
    yaxis: {
      labels: { style: { fontSize: "12px" } },
    },
    grid: { padding: { right: 20 } },
    legend: {
      show: true,
      position: "bottom",
      horizontalAlign: "center",
      fontFamily: "Outfit",
      fontSize: "11px",
    },
    tooltip: {
      y: { formatter: (v) => `${v}명` },
    },
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-5 pt-5 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6 sm:pt-6">
      <div className="flex items-center justify-between mb-2">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">사용자 세션 분포</h3>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">요일 × 시간대별 활성 사용자 수</p>
        </div>
        {lastUpdated && (
          <span className="text-xs text-gray-400 dark:text-gray-500">{lastUpdated} 갱신</span>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-[200px]">
          <Spinner size="md" />
        </div>
      ) : (
        <div className="max-w-full overflow-x-auto custom-scrollbar">
          <div className="-ml-5 min-w-[640px] xl:min-w-full pl-2">
            <Chart options={options} series={series} type="heatmap" height={220} />
          </div>
        </div>
      )}
    </div>
  );
}
