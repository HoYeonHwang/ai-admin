import { useState, useEffect } from "react";
import { ArrowDownIcon, ArrowUpIcon, BoxIconLine, GroupIcon } from "../../icons";
import Badge from "../../components/ui/badge/Badge";
import Spinner from "../../components/ui/spinner/Spinner";
import { getTodayStats, type TodayStats } from "../../api/dashboard";
import { useLastUpdated } from "../../hooks/useLastUpdated";

export default function TodayComponent() {
  const [stats, setStats] = useState<TodayStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const lastUpdated = useLastUpdated(updatedAt);

  useEffect(() => {
    getTodayStats()
      .then((data) => { setStats(data); setUpdatedAt(new Date()); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6">
        {[0, 1].map((i) => (
          <div key={i} className="flex items-center justify-center rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6 min-h-[120px]">
            <Spinner size="md" />
          </div>
        ))}
      </div>
    );
  }

  const userUp = (stats?.user_change_pct ?? 0) >= 0;
  const questionUp = (stats?.question_change_pct ?? 0) >= 0;

  return (
    <div className="space-y-1.5">
      {lastUpdated && (
        <p className="text-xs text-gray-400 dark:text-gray-500 text-right">{lastUpdated} 갱신</p>
      )}
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6">
      {/* 금일 사용자 */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-center justify-center w-12 h-12 bg-brand-50 rounded-xl dark:bg-brand-500/10">
          <GroupIcon className="text-brand-500 size-6" />
        </div>
        <div className="flex items-end justify-between mt-5">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">금일 사용자</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {stats?.today_users.toLocaleString() ?? "-"}
            </h4>
          </div>
          <Badge color={userUp ? "success" : "error"}>
            {userUp ? <ArrowUpIcon /> : <ArrowDownIcon />}
            {Math.abs(stats?.user_change_pct ?? 0).toFixed(2)}%
          </Badge>
        </div>
      </div>

      {/* 금일 질문 수 */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-center justify-center w-12 h-12 bg-brand-50 rounded-xl dark:bg-brand-500/10">
          <BoxIconLine className="text-brand-500 size-6" />
        </div>
        <div className="flex items-end justify-between mt-5">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">금일 질문 수</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {stats?.today_questions.toLocaleString() ?? "-"}
            </h4>
          </div>
          <Badge color={questionUp ? "success" : "error"}>
            {questionUp ? <ArrowUpIcon /> : <ArrowDownIcon />}
            {Math.abs(stats?.question_change_pct ?? 0).toFixed(2)}%
          </Badge>
        </div>
      </div>
    </div>
    </div>
  );
}
