import ApprovalComponent from "../../components/service/ApprovalComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function Approval() {
  return (
    <>
      <PageMeta title="승인 대기열" />
      <PageBreadcrumb pageTitle="승인 대기열" />
      <div className="space-y-6">
        <ApprovalComponent />
      </div>
    </>
  );
}
