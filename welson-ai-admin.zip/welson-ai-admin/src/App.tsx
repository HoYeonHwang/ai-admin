import { BrowserRouter as Router, Routes, Route } from "react-router";
import SignIn from "./pages/AuthPages/SignIn";
import NotFound from "./pages/OtherPage/NotFound";
import AppLayout from "./layout/AppLayout";
import { ScrollToTop } from "./components/common/ScrollToTop";
import Home from "./pages/Dashboard/Home";
import SystemPrompt from "./pages/ServiceManagement/SystemPrompt";
import SystemLimit from "./pages/SystemManagement/SystemLimit";
import RagData from "./pages/ServiceManagement/RagData";
import RagOutlier from "./pages/ServiceManagement/RagOutlier";
import AbnormalChatLog from "./pages/ServiceManagement/AbnormalChatLog";
import UserManagement from "./pages/UserManagement/UserManagement";
import UserConversation from "./pages/UserManagement/UserConversation";
import KillSwitch from "./pages/SystemManagement/KillSwitch";

export default function App() {
  return (
    <>
      <Router>
        <ScrollToTop />
        <Routes>
          <Route element={<AppLayout />}>
            {/* 대시보드 */}
            <Route index path="/" element={<Home />} />

            {/* 서비스 관리 */}
            <Route path="/systemprompt" element={<SystemPrompt />} />
            <Route path="/ragData" element={<RagData />} />
            <Route path="/ragOutlier" element={<RagOutlier />} />
            <Route path="/abnormalChatLog" element={<AbnormalChatLog />} />

            {/* 시스템 관리 */}
            <Route path="/killSwitch" element={<KillSwitch />} />
            <Route path="/systemLimit" element={<SystemLimit />} />

            {/* 사용자 관리 */}
            <Route path="/userManagement" element={<UserManagement />} />
            <Route path="/userConversation" element={<UserConversation />} />
          </Route>

          {/* Auth Layout */}
          <Route path="/signin" element={<SignIn />} />

          {/* Fallback Route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </>
  );
}
