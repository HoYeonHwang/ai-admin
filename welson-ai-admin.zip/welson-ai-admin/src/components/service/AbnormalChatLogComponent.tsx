import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";

import Badge from "../ui/badge/Badge";
import Select from "../form/Select";
import AbnormalChatLogEditModal from "./modal/AbnormalChatLogEditModal";

interface AbnormalChat {
  id: string; // 고유 식별자
  trx_no: string; // 거래 번호
  outlier_content: string; // 이상 탐지 본문
  detect_system: string; // 탐지 시스템 위치
  status: "Active" | "Pendding" | "Deleted"; // 상태
  timestamp: string; // 탐지 일시
}

// Define the table data using the interface
const tableData: AbnormalChat[] = [
  {
    id: "1",
    trx_no: "2026041600000001",
    outlier_content: "바보",
    detect_system: "bedrock",
    status: "Active",
    timestamp: "2026-04-13 15:32:18",
  },
  {
    id: "2",
    trx_no: "2026041600000001",
    outlier_content: "멍청이",
    detect_system: "bedrock",
    status: "Active",
    timestamp: "2026-04-13 15:32:18",
  },
  {
    id: "3",
    trx_no: "2026041600000001",
    outlier_content: "주민번호",
    detect_system: "PII",
    status: "Active",
    timestamp: "2026-04-13 15:32:18",
  },
];

export default function AbnormalChatLogComponent() {
  const status = [
    { value: "전체", label: "전체" },
    { value: "Active", label: "Active" },
    { value: "Pendding", label: "Pendding" },
    { value: "Deleted", label: "Deleted" },
  ];
  const handleStatusChange = (value: string) => {
    console.log("handleStatusChange value:", value);
  };
  return (
    <div className="relative w-full overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
      <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="px-2 pr-14">
          <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
            이상 채팅 관리
          </h4>
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
            이상 채팅을 탐지하고 관리합니다.
          </p>
        </div>
        <div className="flex w-full ml-auto gap-2 lg:inline-flex lg:w-auto">
          <Select
            options={status}
            placeholder="상태"
            onChange={handleStatusChange}
            className="dark:bg-dark-900"
            defaultValue="Active"
          />
        </div>
        <div className="flex-center">
          <AbnormalChatLogEditModal />
        </div>
      </div>
      <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-1">
        <div className="custom-scrollbar h-[450px] overflow-y-auto px-2 pb-3">
          <Table>
            {/* Table Header */}
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  고유 식별자
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  거래번호
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  이상 탐지 본문
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  탐지 시스템 위치
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  상태
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  탐지 일시
                </TableCell>
              </TableRow>
            </TableHeader>

            {/* Table Body */}
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {tableData.map((AbnormalChat) => (
                <TableRow key={AbnormalChat.id}>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {AbnormalChat.id}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {AbnormalChat.trx_no}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {AbnormalChat.outlier_content}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {AbnormalChat.detect_system}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    <Badge
                      size="sm"
                      color={
                        AbnormalChat.status === "Active"
                          ? "success"
                          : AbnormalChat.status === "Pending"
                          ? "warning"
                          : "error"
                      }
                    >
                      {AbnormalChat.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {AbnormalChat.timestamp}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
