import ComponentCard from "../common/ComponentCard";
import ServerInfoComponent from "./ServerInfoComponent"
import Switch from "../form/switch/Switch";
import Alert from "../ui/alert/Alert";

export default function KillSwitchComponent() {
  const handleSwitchChange = (checked: boolean) => {
    console.log("Switch is now:", checked ? "ON" : "OFF");
  };
  return (
    <>
    <div className="mb-2">
    <Alert
        variant="warning"
        title="Kill Switch 동작 전 안내"
        message="Kill Swith 동작시 LLM 서비스 이용이 불가합니다. 반드시 확인 후 실행해주세요."
        showLink={false}
    />
    </div>
    <ComponentCard title="서비스 상태" className="mb-2">
        <ServerInfoComponent />
    </ComponentCard>
    <ComponentCard title="Kill Switch" desc="개인정보 유출의 위험이나 서비스의 긴급 정지가 필요한 경우 시스템을 종료할 수 있습니다. 🚫">
      <Switch
          label=""
          defaultChecked={true}
          onChange={handleSwitchChange}
      />
    </ComponentCard>
    </>
  );
}
