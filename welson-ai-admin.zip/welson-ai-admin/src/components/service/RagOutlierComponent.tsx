import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";

import Badge from "../ui/badge/Badge";
import Select from "../form/Select";
import RagOutlierEditModal from "./modal/RagOutlierEditModal";

interface Outlier {
  id: string; // 고유 식별자
  outlier_dcd: string; // 이상치 구분
  outlier_hash: string; // 이상치 검출 Hash 값
  origin_document_id: string; // 원본 문서 id
  origin_document_hash: string; // 원본 문서 Hash 값
  status: "Active" | "Pendding " | "Deleted"; // 상태
  timestamp: string; // 탐지 일시
}

// Define the table data using the interface
const tableData: Outlier[] = [
  {
    id: "1",
    outlier_dcd: "RAG",
    outlier_hash: "213o4iher8ghadguba8se7rh2374",
    origin_document_id: "DOC_1",
    origin_document_hash: "0s9dufa98sdyun2p983has9p8syhfd",
    status: "Active",
    timestamp: "2026-04-13 15:32:18",
  },
  {
    id: "2",
    outlier_dcd: "RAG",
    outlier_hash: "9as0d87f0a9s8d98as7df098asdf",
    origin_document_id: "DOC_2",
    origin_document_hash: "23h314uh234iu5h2i3l1u45hl234",
    status: "Active",
    timestamp: "2026-04-13 15:32:18",
  },
  {
    id: "3",
    outlier_dcd: "RAG",
    outlier_hash: "34lk7345l6kj34;l5k6j3;l4k5j6l3k45",
    origin_document_id: "DOC_3",
    origin_document_hash: "123i4jop1i234h12b34ku1h2b34kjh",
    status: "Deleted",
    timestamp: "2026-04-13 15:32:18",
  },
  {
    id: "4",
    outlier_dcd: "RAG",
    outlier_hash: "4567jh5l6k7jh456lkj7h54k6l7j",
    origin_document_id: "DOC_4",
    origin_document_hash: "234k5j23h4lk5jh23lk45jh2l3k4j5",
    status: "Deleted",
    timestamp: "2026-04-13 15:32:18",
  },
  {
    id: "5",
    outlier_dcd: "RAG",
    outlier_hash: "234jh5lk2j34h5lk2j3h45lkj2h34l5kj",
    origin_document_id: "DOC_5",
    origin_document_hash: "5k67j8n56lk78jh56k7j8hl5k67j85lk",
    status: "Active",
    timestamp: "2026-04-13 15:32:18",
  },
];

export default function RagOutlierComponent() {
  const status = [
    { value: "전체", label: "전체" },
    { value: "Active", label: "Active" },
    { value: "Pendding", label: "Pendding" },
    { value: "Deleted", label: "Deleted" },
  ];
  const handleStatusChange = (value: string) => {
    console.log("handleStatusChange value:", value);
  };
  return (
    <div className="relative w-full overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
      <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="px-2 pr-14">
          <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
            위변조 Hash 관리
          </h4>
          <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
            Hash 값의 변조를 탐지하고 관리합니다.
          </p>
        </div>
        <div className="flex w-full ml-auto gap-2 lg:inline-flex lg:w-auto">
          <Select
            options={status}
            placeholder="상태"
            onChange={handleStatusChange}
            className="dark:bg-dark-900"
            defaultValue="Active"
          />
        </div>
        <div className="flex-center">
          <RagOutlierEditModal />
        </div>
      </div>
      <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-1">
        <div className="custom-scrollbar h-[450px] overflow-y-auto px-2 pb-3">
          <Table>
            {/* Table Header */}
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  고유 식별자
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  구분
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  검출 Hash 값
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  원본 문서 ID
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  원본 문서 Hash 값
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  상태
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  탐지 일시
                </TableCell>
              </TableRow>
            </TableHeader>

            {/* Table Body */}
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {tableData.map((Outlier) => (
                <TableRow key={Outlier.id}>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Outlier.id}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Outlier.outlier_dcd}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Outlier.outlier_hash}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Outlier.origin_document_id}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Outlier.origin_document_hash}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    <Badge
                      size="sm"
                      color={
                        Outlier.status === "Active"
                          ? "success"
                          : Outlier.status === "Pending"
                          ? "warning"
                          : "error"
                      }
                    >
                      {Outlier.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Outlier.timestamp}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
