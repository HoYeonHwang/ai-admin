import ComponentCard from "../../components/common/ComponentCard";
import Badge from "../../components/ui/badge/Badge";
import { ArrowDownIcon, ArrowUpIcon } from "../../icons";

export default function ServerInfoComponent() {
  return (
    <>
      <div className="flex-center">
        <ComponentCard title="welson-ai-backend-1" className="flex-items">
          <div className="flex gap-4">
            <Badge color="success">
              <ArrowUpIcon />
              Active
            </Badge>
          </div>
        </ComponentCard>
        <ComponentCard title="welson-ai-backend-2" className="flex-items">
          <div className="flex gap-4">
            <Badge color="success">
              <ArrowUpIcon />
              Active
            </Badge>
          </div>
        </ComponentCard>
        <ComponentCard title="welson-ai-frontend-1" className="flex-items">
          <div className="flex gap-4">
            <Badge color="success">
              <ArrowUpIcon />
              Active
            </Badge>
          </div>
        </ComponentCard>
        <ComponentCard title="welson-ai-frontend-2" className="flex-items">
          <div className="flex gap-4">
            <Badge color="success">
              <ArrowUpIcon />
              Active
            </Badge>
          </div>
        </ComponentCard>
      </div>
    </>
  );
}
