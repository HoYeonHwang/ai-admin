import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";

import Badge from "../ui/badge/Badge";
import Button from "../ui/button/Button";
import Input from "../form/input/InputField";
import Label from "../form/Label";

interface Prompt {
  prompt_id: string; // 프롬프트 ID
  prompt_type: string; // 프롬프트 타입
  prompt_content: string; // 프롬프트 내용
  prompt_create_at: string; // 프롬프트 생성일시
  prompt_update_at: string; // 프롬프트 마지막 수정 일시
  prompt_status: "Active" | "Pending" | "Delete"; // Status of the product
  prompt_hash: string;
}

// Define the table data using the interface
const tableData: Prompt[] = [
  {
    prompt_id: "시스템 프롬프트 1", // 프롬프트 ID
    prompt_type: "welson 프롬프트", // 프롬프트 타입
    prompt_content: "시스템 프롬프트 내용...", // 프롬프트 내용
    prompt_create_at: "2026-04-13 15:32:18", // 프롬프트 생성일시
    prompt_update_at: "2026-04-13 15:32:18", // 프롬프트 마지막 수정 일시
    prompt_status: "Active", // 상태코드
    prompt_hash: "a1234",
  },
  {
    prompt_id: "시스템 프롬프트 2", // 프롬프트 ID
    prompt_type: "welson 프롬프트", // 프롬프트 타입
    prompt_content: "시스템 프롬프트 내용...", // 프롬프트 내용
    prompt_create_at: "2026-04-13 15:32:18", // 프롬프트 생성일시
    prompt_update_at: "2026-04-13 15:32:18", // 프롬프트 마지막 수정 일시
    prompt_status: "Pending", // 상태코드
    prompt_hash: "a1234",
  },
  {
    prompt_id: "시스템 프롬프트 2", // 프롬프트 ID
    prompt_type: "채무/챗봇 프롬프트", // 프롬프트 타입
    prompt_content: "시스템 프롬프트 내용...", // 프롬프트 내용
    prompt_create_at: "2026-04-13 15:32:18", // 프롬프트 생성일시
    prompt_update_at: "2026-04-13 15:32:18", // 프롬프트 마지막 수정 일시
    prompt_status: "Delete", // 상태코드
    prompt_hash: "a1234",
  },
];

export default function ServiceSettingsComponent() {
  const handleSave = () => {
    // FIXME 저장 로직
    console.log("Save Click...");
  };
  const handleReset = () => {
    // FIXME 초기화 로직
    console.log("Reset Click....");
  };
  return (
    <div className="no-scrollbar relative w-full overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
      <div className="px-2 pr-14">
        <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
          사용 제한 설정
        </h4>
        <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
          입력 토큰 및 요청 횟수 제한을 설정합니다.
        </p>
      </div>
      <form className="flex flex-col">
        <div className="custom-scrollbar h-[450px] overflow-y-auto px-2 pb-3">
          <div>
            <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
              <div>
                <Label>입력 토큰 제한 설정</Label>
                <Input type="text" value="5000" className="mb-2" />
                <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
                  하루 동안 사용자가 입력할 수 있는 총 토큰 수를 제한합니다.
                </p>
              </div>
              <div>
                <Label>요청 횟수 제한 설정</Label>
                <Input type="text" value="5000" className="mb-2" />
                <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
                  하루 동안 사용자가 요청할 수 있는 횟수를 제한합니다.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
          <Button size="sm" variant="outline" onClick={handleReset}>
            reset
          </Button>
          <Button size="sm" onClick={handleSave}>
            Save
          </Button>
        </div>
      </form>
    </div>
  );
}
