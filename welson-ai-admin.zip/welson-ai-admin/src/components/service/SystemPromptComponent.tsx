import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";

import Badge from "../ui/badge/Badge";
import SystemPromptAddMoadl from "./modal/SystemPromptAddModal";
import SystemPromptEditModal from "./modal/SystemPromptEditModal";
import Select from "../form/Select";

interface Prompt {
  prompt_id: string; // 프롬프트 ID
  prompt_name: string; // 프롬프트 이름
  prompt_version: string; // 프롬프트 버전
  prompt_size: string; // 프롬프트 사이즈
  prompt_type: string; // 프롬프트 타입
  create_at: string; // 프롬프트 생성일시
  status: "Active" | "Pending" | "Delete"; // Status
}

// Define the table data using the interface
const tableData: Prompt[] = [
  {
    prompt_id: "1", // 프롬프트 ID
    prompt_name: "시스템 프롬프트", // 프롬프트 이름
    prompt_version: "1.0", // 프롬프트 버전
    prompt_size: "1024bytes", // 프롬프트 사이즈
    prompt_type: ".txt", // 프롬프트 타입
    create_at: "2026-04-13 15:32:18", // 프롬프트 생성일시
    status: "Active", // Status of the product
  },
];

export default function SystemPromptComponent() {
  const status = [
    { value: "전체", label: "전체" },
    { value: "Active", label: "Active" },
    { value: "Pendding", label: "Pendding" },
    { value: "Deleted", label: "Deleted" },
  ];
  const handleStatusChange = (value: string) => {
    console.log("handleStatusChange value:", value);
  };

  return (
    <>
      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
        <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="px-2 pr-14">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
              시스템 프롬프트 내역
            </h4>
            <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
              시스템 프롬프트의 내역을 확인합니다.
            </p>
          </div>
          <div className="flex w-full ml-auto gap-2 lg:inline-flex lg:w-auto">
            <Select
              options={status}
              placeholder="상태"
              onChange={handleStatusChange}
              className="dark:bg-dark-900"
              defaultValue="Active"
            />
          </div>
          <div className="flex-center">
            <SystemPromptEditModal />
            <SystemPromptAddMoadl />
          </div>
        </div>
        <div className="max-w-full overflow-x-auto">
          <Table>
            {/* Table Header */}
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  시스템 프롬프트 이름
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  시스템 프롬프트 버전
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  프롬프트 사이즈
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  프롬프트 타입
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  등록일자
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  상태
                </TableCell>
              </TableRow>
            </TableHeader>

            {/* Table Body */}
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {tableData.map((Prompt) => (
                <TableRow key={Prompt.prompt_id}>
                  <TableCell className="px-5 py-4 sm:px-6 text-start">
                    <div className="flex items-center gap-3">
                      <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                        {Prompt.prompt_name}
                      </span>
                      <span className="block text-gray-500 text-theme-xs dark:text-gray-400">
                        {Prompt.prompt_id}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Prompt.prompt_version}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Prompt.prompt_size}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Prompt.prompt_type}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    {Prompt.create_at}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    <Badge
                      size="sm"
                      color={
                        Prompt.status === "Active"
                          ? "success"
                          : Prompt.status === "Pending"
                          ? "warning"
                          : "error"
                      }
                    >
                      {Prompt.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </>
  );
}
