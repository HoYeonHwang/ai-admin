import { useModal } from "../../../hooks/useModal";
import { Modal } from "../../ui/modal";
import Button from "../../ui/button/Button";
import Input from "../../form/input/InputField";
import Label from "../../form/Label";
import TextArea from "../../form/input/TextArea";

export default function SystemPromptAddModal() {
  const { isOpen, openModal, closeModal } = useModal();
  const handleSave = () => {
    // Handle save logic here
    console.log("Saving changes...");
    closeModal();
  };
  return (
    <>
      <Button
        onClick={openModal}
        className="flex w-full items-center justify-center gap-2 lg:inline-flex lg:w-auto"
        size="sm"
        variant="primary"
      >
        Add +
      </Button>
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">
              시스템 프롬프트 등록
            </h4>
            <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">
              시스템 프롬프트를 등록합니다.
            </p>
          </div>
          <form className="flex flex-col">
            <div className="custom-scrollbar h-[450px] overflow-y-auto px-2 pb-3">
              <div>
                <h5 className="mb-5 text-lg font-medium text-gray-800 dark:text-white/90 lg:mb-6">
                  시스템 프롬프트 정보
                </h5>
                <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                  <div>
                    <Label>프롬프트 이름</Label>
                    <Input type="text" value="시스템 프롬프트" />
                  </div>
                  <div>
                    <Label>프롬프트 타입</Label>
                    <Input type="text" value="WELSON 챗봇용" />
                  </div>
                  <div className="col-span-2">
                    <Label>프롬프트 내용</Label>
                    <TextArea
                      value="시스템 프롬프트 내용이 들어갈 겁니다."
                      onChange={(value) => setMessage(value)}
                      rows={12}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
              <Button size="sm" variant="outline" onClick={closeModal}>
                Close
              </Button>
              <Button size="sm" onClick={handleSave}>
                Save
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </>
  );
}
