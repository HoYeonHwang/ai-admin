import { useState, useEffect, useCallback } from "react";

import { Table, TableBody, TableCell, TableHeader, TableRow } from "../ui/table";
import { Modal } from "../ui/modal";
import { UserCircleIcon } from "../../icons";
import { useModal } from "../../hooks/useModal";
import Badge from "../ui/badge/Badge";
import UserAddModal from "./UserAddModal";
import Button from "../ui/button/Button";
import Input from "../form/input/InputField";
import Label from "../form/Label";

interface User {
  user_id: string; // 사용자 사번
  user_name: string; // 사용자 이름
  user_department: string; // 사용자 부서명
  user_email: string; // 사용자 이메일주소
  user_create_at: string; // 사용자 생성일시
  user_update_at: string; // 사용자 마지막 수정 일시
  user_last_login_at: string; // 사용자 마지막 로그인 일시
  status: "Active" | "Pending" | "Delete"; // 상태코드
  user_role: "Admin" | "User"; // 사용자 권한
}

// API 명세
const userAPI = {
  /** 전체 사용자 조회 */
  fetchAll: async (): Promise<User[]> => {
    const response = await fetch(BASE_URL);
    if (!response.ok) {
      throw new Error("서버 오류가 발생했습니다.");
    }
    return response.json();
  },

  /** 사용자 정보 수정 */
  update: async (user_id: string, body: Partial<User>): Promise<User> => {
    const response = await fetch(BASE_URL + `/${user_id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error("서버 오류가 발생했습니다.");
    }
    return response.json();
  },
};

export default function UserManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { isOpen, data, openModal, closeModal } = useModal<User>();
  const [toast, setToast] = useState();

  const handleSave = async () => {
    const updated = await userAPI.update(data.user_id, data);
    alert("저장 완료");
    closeModal();
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  };
  const handleRowClick = (user: User) => {
    openModal(user);
  };

  const fetchUsers = useCallback(async () => {
    try {
      const response = await fetch(BASE_URL);
      if (!response.ok) {
        throw new Error("서버 오류가 발생했습니다.");
      }
      const data = await response.json();
      setUsers(data.users);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  if (loading) return <p> 로딩중...</p>;
  if (error) return <p> 에러: {error}</p>;

  return (
    <>
      <div className="rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
        <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">사용자</h3>
          </div>
          <div className="flex-center">
            <UserAddModal onSuccess={fetchUsers} />
          </div>
        </div>

        <div className="max-w-full overflow-x-auto">
          <Table>
            {/* Table Header */}
            <TableHeader className="border-gray-100 dark:border-gray-800 border-y">
              <TableRow>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  사용자 정보
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  사번
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  이메일 주소
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  등록일시
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  변경일시
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  마지막 로그인 일시
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  사용자 권한
                </TableCell>
                <TableCell isHeader className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                  사용자 상태
                </TableCell>
              </TableRow>
            </TableHeader>

            {/* Table Body */}

            <TableBody className="divide-y divide-gray-100 dark:divide-gray-800">
              {users.map((user) => (
                <TableRow key={user.user_id} className="cursor-pointer hover:bg-[#fff1ee] transition-colors" onClick={() => handleRowClick(user)}>
                  <TableCell className="py-3">
                    <div className="flex items-center gap-3">
                      <UserCircleIcon className="h-[50px] w-[50px]" />
                      <div>
                        <p className="font-medium text-gray-800 text-theme-sm dark:text-white/90">{user.user_name}</p>
                        <span className="text-gray-500 text-theme-xs dark:text-gray-400">{user.user_department}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_id}</TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_email}</TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_create_at}</TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_update_at}</TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_last_login_at}</TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">{user.user_role}</TableCell>
                  <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    <Badge size="sm" color={user.status === "Active" ? "success" : user.status === "Pending" ? "warning" : "error"}>
                      {user.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">사용자 정보 변경</h4>
            <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">사용자 정보 및 권한을 변경합니다.</p>
          </div>
          <form className="flex flex-col">
            <div className="custom-scrollbar h-[450px] overflow-y-auto px-2 pb-3">
              <div>
                <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                  <div>
                    <Label>이름</Label>
                    <Input type="text" value={data?.user_name} />
                  </div>

                  <div>
                    <Label>사번</Label>
                    <Input type="text" value={data?.user_id} />
                  </div>

                  <div>
                    <Label>부서명</Label>
                    <Input type="text" value={data?.user_department} />
                  </div>

                  <div>
                    <Label>이메일주소</Label>
                    <Input type="text" value={data?.user_email} />
                  </div>

                  <div>
                    <Label>생성일</Label>
                    <Input type="text" value={data?.user_create_at} />
                  </div>

                  <div>
                    <Label>수정일</Label>
                    <Input type="text" value={data?.user_update_at} />
                  </div>

                  <div>
                    <Label>마지막 로그인 일시</Label>
                    <Input type="text" value={data?.user_last_login_at} />
                  </div>

                  <div>
                    <Label>사용자 상태</Label>
                    <Input type="text" value={data?.status} />
                  </div>
                </div>
              </div>
              <div className="mt-7">
                <h5 className="mb-5 text-lg font-medium text-gray-800 dark:text-white/90 lg:mb-6">권한 정보</h5>

                <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                  <div className="col-span-2 lg:col-span-1">
                    <Label>권한 구분</Label>
                    <Input type="text" value={data?.user_role} />
                  </div>
                </div>
              </div>
              <div className="mt-7">
                <h5 className="mb-5 text-lg font-medium text-gray-800 dark:text-white/90 lg:mb-6">토큰 정보</h5>

                <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                  <div className="col-span-2 lg:col-span-1">
                    <Label>토큰 사용량</Label>
                    <Input type="text" value="100" />
                  </div>

                  <div className="col-span-2 lg:col-span-1">
                    <Label>채팅 사용량</Label>
                    <Input type="text" value="40" />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
              <Button size="sm" variant="outline" onClick={closeModal}>
                Close
              </Button>
              <Button size="sm" onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </>
  );
}
