import { useState, useRef } from "react";
import { useModal } from "../../hooks/useModal";
import { Modal } from "../ui/modal";
import Button from "../ui/button/Button";
import Input from "../form/input/InputField";
import Label from "../form/Label";
import Select from "../form/Select";

export default function UserAddModal({ onSuccess }) {
  const userForm = {
    user_id: "",
    user_name: "",
    user_department: "",
    user_email: "",
    user_role: "",
    status: "",
  };

  const { isOpen, openModal, closeModal } = useModal();
  const [user, setUser] = useState(userForm);

  const [errors, setErrors] = useState({});
  const inputRefs = useRef({});

  const fields = [
    { name: "user_name", label: "이름", type: "input", placeholder: "이름" },
    { name: "user_id", label: "사번", type: "input", placeholder: "사번" },
    { name: "user_department", label: "부서명", type: "input", placeholder: "부서명" },
    { name: "user_email", label: "이메일 주소", type: "input", placeholder: "이메일 주소" },
    {
      name: "user_role",
      label: "권한",
      type: "select",
      placeholder: "권한",
      options: [
        { label: "Admin", value: "Admin" },
        { label: "User", value: "User" },
      ],
    },
    {
      name: "status",
      label: "상태",
      type: "select",
      placeholder: "상태",
      options: [
        { label: "Active", value: "Active" },
        { label: "Pendding", value: "Pendding" },
        { label: "Deleted", value: "Deleted" },
      ],
    },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target ?? e;
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: false,
    }));
  };

  const validate = () => {
    const newErrors = {};
    for (const field of fields) {
      const value = user[field.name];
      if (!value || !value.toString().trim()) {
        newErrors[field.name] = true;
        break;
      }
    }

    setErrors(newErrors);
    const firstError = Object.keys(newErrors)[0];

    if (firstError) {
      inputRefs.current[firstError]?.focus?.();
      return false;
    }
    return true;
  };

  const handleSave = async (e) => {
    e.preventDefault();

    if (!validate()) return;
    try {
      const ressponse = await fetch(BASE_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      });

      if (!ressponse.ok) throw new Error("save failed");

      alert("저장 완료");

      onSuccess?.();
      handleClose();
    } catch (err) {
      alert(err);
    }
  };

  const handleClose = () => {
    setErrors({});
    setUser(userForm);
    closeModal();
  };

  const getInputClass = (name) => `transition-all w-full ${errors[name] ? "border border-red-500 shake rounded" : "border border-gray-300 rounded"}`;

  const renderField = (field) => {
    const commonProps = {
      name: field.name,
      value: user[field.name],
      onChange: handleChange,
      className: getInputClass(field.name),
      placeholder: field.placeholder || "",
      ref: (el) => (inputRefs.current[field.name] = el),
    };

    switch (field.type) {
      case "select":
        return (
          <Select
            {...commonProps}
            options={field.options}
            onChange={(value) =>
              handleChange({
                name: field.name,
                value,
              })
            }
          />
        );

      default:
        return <Input {...commonProps} type="text" />;
    }
  };

  return (
    <>
      <Button onClick={openModal} className="flex w-full items-center justify-center gap-2 lg:inline-flex lg:w-auto" size="sm" variant="primary">
        Add +
      </Button>
      <Modal isOpen={isOpen} onClose={closeModal} className="max-w-[700px] m-4">
        <div className="no-scrollbar relative w-full max-w-[700px] overflow-y-auto rounded-3xl bg-white p-4 dark:bg-gray-900 lg:p-11">
          <div className="px-2 pr-14">
            <h4 className="mb-2 text-2xl font-semibold text-gray-800 dark:text-white/90">사용자 등록</h4>
            <p className="mb-6 text-sm text-gray-500 dark:text-gray-400 lg:mb-7">신규 사용자를 등록합니다.</p>
          </div>
          <form className="flex flex-col" onSubmit={handleSave}>
            <div className="custom-scrollbar h-[450px] overflow-y-auto px-2 pb-3">
              <div>
                <h5 className="mb-5 text-lg font-medium text-gray-800 dark:text-white/90 lg:mb-6">사용자 정보</h5>
                <div className="grid grid-cols-1 gap-x-6 gap-y-5 lg:grid-cols-2">
                  {fields.map((field) => (
                    <div key={field.name}>
                      <Label>{field.label}</Label>
                      {renderField(field)}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3 px-2 mt-6 lg:justify-end">
              <Button size="sm" variant="outline" onClick={handleClose}>
                Close
              </Button>
              <Button size="sm" type="submit">
                Save
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </>
  );
}
