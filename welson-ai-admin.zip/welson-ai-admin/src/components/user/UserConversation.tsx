import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import ComponentCard from "../common/ComponentCard";
import Label from "../form/Label";
import Input from "../form/input/InputField";
import Select from "../form/Select";
import DatePicker from "../form/date-picker.tsx";
import { PlusIcon } from "../../icons";
import Badge from "../../components/ui/badge/Badge";

interface search_params {
  user_id: string; // 사번
  key: string; // 
  opi_dcd: string; // 의견 구분코드
  archive: string; // 구분
  startDate: string; // 조회시작일자
  endDate: string; // 조회종료일자
}

interface chat_history {
  user_id: string; // 사번
  archive: string; // 구분
  key: string; // 
  sequence: string; // 일련번호
  HumanMessage: string; // 질문 내용
  AIMessage: string; // AI응답 내용
  cls_dcd: string; // 피드백 구분코드
  opi_dcd: string; // 의견 구분코드
  opi_cont: string; // 의견 내용
  timestamp: string; // 시간
}

const AIMessage = "##### **개인정보 보호 원칙**  #FIXME 일정 바이트 수 이상 slice";

const tableData: chat_history[] = [
{
  user_id: "087191", // 사번
  archive: "정보규정", // 구분
  key: "이거 뭐냐....?", // 
  sequence: "0", // 일련번호
  HumanMessage: "개인정보보호 원칙에 대해 알려줘", // 질문 내용
  AIMessage: AIMessage, // AI응답 내용
  cls_dcd: "00", // 피드백 구분코드
  opi_dcd: "00", // 의견 구분코드
  opi_cont: "", // 의견 내용
  timestamp: "Jan 21, 2025 @ 23:04:45.000", // 시간
},
]
export default function UserConversation() {
  const cls_dcd_option = [
    { value: "전체", label: "전체" },
    { value: "00", label: "00" },
    { value: "01", label: "01" },
    { value: "02", label: "02" },
  ];
  const opi_dcd_option = [
    { value: "전체", label: "전체" },
    { value: "01", label: "01" },
    { value: "02", label: "02" },
    { value: "03", label: "03" },
    { value: "04", label: "04" },
    { value: "05", label: "05" },
    { value: "06", label: "06" },
  ];
  const archive_option = [
    { value: "전체", label: "전체" },
    { value: "수신(교본)", label: "01" },
    { value: "여신(규정)", label: "02" },
    { value: "여신(규정)", label: "03" },
    { value: "여신/총무", label: "04" },
    { value: "정보규정", label: "05" },
  ];
  const handleClsDcdChange = (value: string) => {
    console.log("handleClsDcdChange value:", value);
  };
  const handleOpiDcdChange = (value: string) => {
    console.log("handleOpiDcdChange value:", value);
  };
  const handleArchiveChange = (value: string) => {
    console.log("handleArchiveChange value:", value);
  };

  return (
    <div className="h-[80vh] rounded-2xl border border-gray-200 bg-white px-4 pb-3 pt-4 dark:border-gray-800 dark:bg-white/[0.03] sm:px-6">
      <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">
            대화 내역
          </h3>
        </div>
        <div className="w-[70%] flex items-end gap-1">
          <div className="flex-items">
              <Input type="text" id="user_id" placeholder="사번"/>
          </div>
          <div className="flex-items ">
              <Input type="text" id="key" placeholder="조회 키"/>
          </div>
          <div className="flex-items">
              <Select
                  options={cls_dcd_option}
                  placeholder="피드백"
                  onChange={handleClsDcdChange}
                  className="dark:bg-dark-900"
              />
          </div>
          <div className="flex-items">
              <Select
                  options={opi_dcd_option}
                  placeholder="의견"
                  onChange={handleOpiDcdChange}
                  className="dark:bg-dark-900"
              />
          </div>
          <div className="flex-items">
              <Select
                  options={archive_option}
                  placeholder="구분"
                  onChange={handleArchiveChange}
                  className="dark:bg-dark-900"
              />
          </div>
          <div className="flex-items">
            <DatePicker
              id="start_date"
              placeholder="시작일자"
              onChange={(dates, currentDateString) => {
              // Handle your logic
              console.log({ dates, currentDateString });
              }}
              className="dark:bg-dark-900 h-9"
            />
          </div>
          <div className="flex-items">
            <DatePicker
              id="end_date"
              placeholder="종료일자"
              onChange={(dates, currentDateString) => {
              // Handle your logic
              console.log({ dates, currentDateString });
              }}
              className="dark:bg-dark-900"
            />
          </div>
          <div className = "flex-items">
            <Badge variant="light" color="light" startIcon={<PlusIcon />}>
              Filter
            </Badge>
          </div>
        </div>
      </div>
      <div className="max-w-full overflow-x-auto">
        <Table>
          {/* Table Header */}
          <TableHeader className="border-gray-100 dark:border-gray-800 border-y">
            <TableRow>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                사용자 정보
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                구분
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                키
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                일련번호
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                질문 내용
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                AI 응답 내용
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                피드백 구분코드
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                의견 구분코드
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                의견 내용
              </TableCell>
              <TableCell
                isHeader
                className="py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
              >
                시간
              </TableCell>
            </TableRow>
          </TableHeader>

          {/* Table Body */}

          <TableBody className="divide-y divide-gray-100 dark:divide-gray-800">
            {tableData.map((chat_history) => (
              <TableRow key={chat_history.user_id} className="">
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.user_id}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.archive}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.key}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.sequence}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.HumanMessage}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.AIMessage}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.cls_dcd}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.opi_dcd}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.opi_cont}
                </TableCell>
                <TableCell className="py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                  {chat_history.timestamp}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
