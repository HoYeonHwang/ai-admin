import { useState, useCallback } from "react";

export const useModal = <T>(initialState: boolean = false) => {
  const [isOpen, setIsOpen] = useState(initialState);
  const [data, setData] = useState<T | null>(null);

  const openModal = useCallback((modalData?: T | null) => {
    setData(modalData);
    setIsOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setData(null);
    setIsOpen(false);
  }, []);
  const toggleModal = useCallback(() => setIsOpen((prev) => !prev), []);

  return { isOpen, data, openModal, closeModal, toggleModal };
};
