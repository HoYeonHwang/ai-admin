import TodayComponent from "./TodayComponent";
import MonthlyChart from "./MonthlyChart";
import MonthlyTarget from "./MonthlyTarget";
import PageMeta from "../../components/common/PageMeta";
import ServerInfoComponent from "../../components/service/ServerInfoComponent";
import ComponentCard from "../../components/common/ComponentCard";

export default function Home() {
  return (
    <>
      <PageMeta
        title="현황 대시보드"
      />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        <div className="col-span-12 space-y-6 xl:col-span-7">
          <TodayComponent />
          <MonthlyChart />
        </div>

        <div className="col-span-12 xl:col-span-5">
          <MonthlyTarget />
        </div>

        <div className="col-span-12 xl:col-span-12">
          <ComponentCard>
            <ServerInfoComponent />
          </ComponentCard>
        </div>
      </div>
    </>
  );
}
