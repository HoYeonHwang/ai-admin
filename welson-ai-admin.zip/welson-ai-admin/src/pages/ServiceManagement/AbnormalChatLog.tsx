import AbnormalChatLogComponent from "../../components/service/AbnormalChatLogComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function AbnormalChatLog() {
  return (
    <>
      <PageMeta title="이상 채팅 로그" />
      <PageBreadcrumb pageTitle="이상 채팅 로그" />
      <div className="space-y-6">
        <AbnormalChatLogComponent />
      </div>
    </>
  );
}
