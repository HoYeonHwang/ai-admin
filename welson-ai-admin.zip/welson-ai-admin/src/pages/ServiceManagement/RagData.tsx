import RagDataComponent from "../../components/service/RagDataComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function RagData() {
  return (
    <>
      <PageMeta
        title="RAG 데이터 관리"
      />
      <PageBreadcrumb pageTitle="RAG 데이터 관리" />
      <div className="space-y-6">
          <RagDataComponent />
      </div>
    </>
  );
}
