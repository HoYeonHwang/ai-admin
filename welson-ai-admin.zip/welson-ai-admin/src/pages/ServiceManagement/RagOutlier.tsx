import RagOutlierComponent from "../../components/service/RagOutlierComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function RagOutlier() {
  return (
    <>
      <PageMeta title="RAG 이상치" />
      <PageBreadcrumb pageTitle="RAG 이상치" />
      <div className="space-y-6">
        <RagOutlierComponent />
      </div>
    </>
  );
}
