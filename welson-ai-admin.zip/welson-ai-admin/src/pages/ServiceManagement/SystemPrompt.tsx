import SystemPromptComponent from "../../components/service/SystemPromptComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function SystemPromt() {
  return (
    <>
      <PageMeta title="시스템 프롬프트" />
      <PageBreadcrumb pageTitle="시스템 프롬프트 관리" />
      <div className="space-y-6">
        <SystemPromptComponent />
      </div>
    </>
  );
}
