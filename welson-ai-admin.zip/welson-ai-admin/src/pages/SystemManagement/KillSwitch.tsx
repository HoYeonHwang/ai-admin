import KillSwitchComponent from "../../components/service/KillSwitchComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function KillSwitch() {
  return (
    <>
      <PageMeta
        title="킬 스위치"
      />
      <PageBreadcrumb pageTitle="킬 스위치" />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        <div className="col-span-12">
          <KillSwitchComponent />
        </div>
      </div>
    </>
  );
}