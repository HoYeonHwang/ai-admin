import SystemLimitComponent from "../../components/service/SystemLimitComponent";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function SystemLimit() {
  return (
    <>
      <PageMeta title="시스템 제한 설정" />
      <PageBreadcrumb pageTitle="시스템 제한 설정" />
      <div>
        <SystemLimitComponent />
      </div>
    </>
  );
}
