import UserConv from "../../components/user/UserConversation";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function UserConversation() {
  return (
    <>
      <PageMeta
        title="대화 내역 조회"
      />
      <PageBreadcrumb pageTitle="대화 내역 조회" />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        <div className="col-span-12">
          <UserConv />
        </div>
      </div>
    </>
  );
}
