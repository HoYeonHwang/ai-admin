import User from "../../components/user/User";
import PageMeta from "../../components/common/PageMeta";
import PageBreadcrumb from "../../components/common/PageBreadCrumb";

export default function UserManagement() {
  return (
    <>
      <PageMeta
        title="사용자 관리"
      />
      <PageBreadcrumb pageTitle="사용자 관리" />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        <div className="col-span-12">
          <User />
        </div>
      </div>
    </>
  );
}
