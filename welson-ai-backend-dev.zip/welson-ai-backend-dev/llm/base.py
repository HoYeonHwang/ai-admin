from abc import ABC, abstractmethod

class LLMInterface(ABC):
    @abstractmethod
    async def generate(self, prompt: str, **kwargs):
        pass

    @abstractmethod
    async def stream(self, prompt: str, **kwargs):
        pass