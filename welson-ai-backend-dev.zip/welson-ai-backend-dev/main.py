from fastapi import FastAPI, Request, HTTPException, Response

from routes.rag_routes import router as rag_router

import uvicorn
from contextlib import asynccontextmanager

from utils import utils
    
app = FastAPI(lifespan=lifespan, docs_url = None)
logger = utils.createLogger(__name__)

app.include_router(rag_router, prefix="/api")

if __name__ == "__main__":
    print(f"__name : {__name__}")
    uvicorn.run("main:app", host="0.0.0.0", port=8090, reload=True, workers=4)

