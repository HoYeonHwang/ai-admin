from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import List
from typing import List, Optional, Dict, Any, Union


#  process_question 요청 모델 정의
class RequestForm(BaseModel):
    user_id: str
    conversation_id: str
    sequence: int
    user_query: str
    query_type: Optional[Union[str, List[str]]] = Field(
        default_factory=list
    )  # str | List[str]
    answerType: Optional[str] = None
    sel_sequence: Optional[int] = None
    trx_gid: Optional[str] = None


class FAQResult(BaseModel):
    score: float | None
    question: str | None
    answer: str | None


class MetaData(BaseModel):
    source: str
    section_level: str
    page_num: int


class SearchResponse(BaseModel):
    total_context: List[str]
    total_meta: List[MetaData]


# process_question 응답 모델 정의
class ProcessResponse(BaseModel):
    status_code: str
    generate_yn_code: Optional[str] = None
    filtered_result: Optional[str] = None
    answer: Optional[str] = None
    multi_querys: Optional[List[str]] = None
    total_context: Optional[List[str]] = None
    doc_info: Optional[str] = None


class StreamResponse(BaseModel):
    status_code: str
    generate_yn_code: str
    filtered_result: Optional[str] = None
    multi_querys: Optional[List[str]] = None
    total_context: Optional[List[str]] = None
    doc_info: Optional[str] = None
    answer: Optional[str] = None


# generate answer: streaming 방식으로
class FinalRequest(BaseModel):
    user_id: str
    conversation_id: str
    user_query: str
    query_type: str
    multi_querys: Optional[List[str]] = None
    total_context: Optional[List[str]] = None
    answer: Optional[str] = None
    doc_info: Optional[str] = None


class GenerateRequest(BaseModel):
    user_id: str
    conversation_id: str
    user_query: str
    query_type: str
    multi_querys: Optional[List[str]] = None
    total_context: Optional[List[str]] = None


# save conversation
class QnARequest(BaseModel):
    user_id: str
    conversation_id: str
    query_type: str
    user_query: str
    answer: str
    doc_info: str


# 3. FAQ 탐색
class Query(BaseModel):
    query: str


class FAQRequestForm(BaseModel):
    user_query: str
    query_type: str
    multi_querys: List[str]


class FAQResponse(BaseModel):
    result: FAQResult | None


# 4. 벡터 DB 검색
class SearchRequest(BaseModel):
    user_query: str
    query_type: str
    multi_querys: List[str]


# 6. serve meta
class MetaRequest(BaseModel):
    query_type: str
    total_meta: List[MetaData]
