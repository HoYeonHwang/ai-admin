try:
    from process.rag.rag_category import RAGPipeline
    from utils.utils import read_yaml_file_safe, read_yaml_file
    from services import chat_services
    from utils import utils
except Exception as e:
    raise e
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser, PydanticOutputParser
from pydantic import BaseModel, Field
from typing import List, Union
import pandas as pd


# init logger
logger = utils.createLogger(__name__)
        
class QuestionSet(BaseModel):
    questions: List[str] = Field(..., description="파생된 질문 3개")
            
class RulePipeline(RAGPipeline):
    def __init__(self):
        super().__init__()

    def multi_query(self, user_query, query_type):
        meta_dict = self.metadata[query_type]
        mq_key = meta_dict['multiquery']   # rule1, rule2, rule3

        # rewrite query
        user_query = self.rewrite_query(user_query, query_type)
        
        # set for multi query
        dict_prompt = read_yaml_file("process/rag/prompt/multiquery.yaml") 
        prompt_template = dict_prompt[mq_key]
        prompt_query = PromptTemplate.from_template(prompt_template)

        llm_chain2 = prompt_query | self.llm_mq | StrOutputParser()
        rewritten_questions = llm_chain2.invoke({"question": user_query})
        rewritten_questions = [
            question for question in rewritten_questions.split("\n") for j in range(1, 4) if question.startswith(f"{j}.")
        ]
        rewritten_questions = [q.replace('1.', '').replace('2.', '').replace('3.', '').strip() for q in rewritten_questions]
        
        return rewritten_questions

    async def amulti_query(self, user_query, query_type):
        meta_dict = self.metadata[query_type]
        mq_key = meta_dict['multiquery']   # rule1, rule2, rule3

        # set for multi query
        dict_prompt = read_yaml_file("process/rag/prompt/multiquery.yaml") 
        prompt_template = dict_prompt[mq_key]
        prompt_query = PromptTemplate.from_template(prompt_template)

        llm_chain2 = prompt_query | self.llm_mq | StrOutputParser()
        rewritten_questions = llm_chain2.invoke({"question": user_query})
        rewritten_questions = [
            question for question in rewritten_questions.split("\n") for j in range(1, 4) if question.startswith(f"{j}.")
        ]
        rewritten_questions = [q.replace('1.', '').replace('2.', '').replace('3.', '').strip() for q in rewritten_questions]
        
        return rewritten_questions
    
    async def agenerate_multi_query(self, user_query: str, query_type: Union[str, list], user_id: str, conversation_id: str, count: int = 5) -> list:
        final_query_type, _ = self.validate_query_type(query_type)
        
        meta_dict = self.metadata[final_query_type]
        mq_key = meta_dict['multiquery']   # rule1, rule2, rule3
        
        # load past questions
        _store = chat_services.get_user_session(user_id, conversation_id) # pd.DataFrame
        past_questions = _store.get("HumanMessage", pd.Series()).to_list()[-count:]
        
        # set prompt and output schema
        dict_prompt = read_yaml_file_safe("process/rag/prompt/multiquery.yaml", "/data/venvs/chatai/app/process/rag/prompt/multiquery.yaml")
        prompt_template = dict_prompt[mq_key]

        parser = PydanticOutputParser(pydantic_object=QuestionSet)    
        prompt_query = PromptTemplate(
            template=prompt_template, 
            input_variables=["question", "past_questions"],
            partial_variables={"format_instructions": parser.get_format_instructions()}
        )

        llm_chain2 = prompt_query | self.llm_mq | parser # StrOutputParser()
        rewritten_questions = llm_chain2.invoke({"question": user_query, "past_questions": past_questions})
        
        # get questions
        questions = rewritten_questions.questions 
        
        # get embedding
        self.multi_query_embedding = self.embedding.embed_documents(questions) # list of list
        
        return questions