from concurrent.futures import ThreadPoolExecutor
import concurrent.futures

def pre_multiprocessing(df_part, index_name, query_embedding):
    import os
    list_args = list()
    for idx, val in df_part.iterrows():
        list_args.append({
            'idx' : idx,
            'index_name' : index_name,
            'query_embedding' : query_embedding,
            'df_part' : df_part,

        })
    return list_args

def run_multithread(tasks, func):
    threads = []
    
    executor = ThreadPoolExecutor(max_workers=32)
    
    for task in tasks:
        threads.append(executor.submit(func, task))
            
    concurrent.futures.wait(threads)
    executor.shutdown(wait=False)
