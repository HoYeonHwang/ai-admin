from abc import *
import warnings

warnings.filterwarnings("ignore")
import pandas as pd
from pydantic import BaseModel, Field
from typing import List, Union
import numpy as np
import re
import asyncio
from typing import List, Optional, Any, Iterator
from datetime import datetime
from zoneinfo import ZoneInfo  # Python 3.9 이상
from langchain_core.outputs import ChatResult, ChatGeneration
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import (
    ChatPromptTemplate,
    PromptTemplate,
    MessagesPlaceholder,
)
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.output_parsers import PydanticOutputParser
from flashrank import Ranker, RerankRequest
from langchain_core.messages import BaseMessage, AIMessage

try:
    from utils.utils import read_yaml_file_safe
    from utils import utils
    from process.rag.llm_interface import ClovaStudio, OpenAI
    from process.search.search_process import (
        opensearch_client,
        get_score_matrix,
        search_neighbor,
        search_ensemble_with_filter,
    )
    from services.chat_services import get_chat_cache
    from process.rag.multi import pre_multiprocessing, run_multithread
except Exception as e:
    raise e
from langchain_core.outputs import GenerationChunk
from langchain.llms.base import LLM

# init logger
logger = utils.createLogger(__name__)

FAQ_INDEX_NAME = utils.server_mode + "_welcome-chatbot-faq"
import time

class Query(BaseModel):
    query: str


# FAQ 서치 결과에 대한 답변 모델
class FAQResult(BaseModel):
    score: float | None
    question: str | None
    answer: str | None


# 각 상품에 대한 답변을 나타내는 모델
class Answer(BaseModel):
    result: str = Field(description="Product Description or Answer Text")


# 최종 응답은 사용자 질문과 3개의 답변(Answer 리스트)로 구성됨
class ResponseModel(BaseModel):
    yn_related: bool = Field(
        description="Whether the query is related to certain loan products"
    )
    products: List[Answer] = Field(
        description="Lists of products associated with the query"
    )


class RAGPipeline(metaclass=ABCMeta):
    def __init__(self, llm_name: str = "gpt"):

        metadata = read_yaml_file_safe(
            "config/metadata.yaml", "/data/venvs/chatai/app/config/metadata.yaml"
        )
        self.metadata = metadata
        self.llm_name = llm_name
        self.openai = OpenAI()
        self.embedding = self.openai.Embedding()

        # set llm
        self.set_llm()

    def time_logging(self, *args):
        timestamp = utils.get_current_time_kst("%Y/%m/%d %H:%M:%S")
        list_args = [string for string in args]
        logger.info(f"[[{timestamp}]]::" + " ".join(list_args))

    def set_llm(self):
        """Init 시 받은 파라미터를 이용한 LLM 세팅

        Raises:
            ValueError: 클로바x 혹은 gpt가 아니면 에러
        """
        if self.llm_name == "hcx":
            self.llm_filter = self.clovastudio.ChatClovax(
                model="HCX-003", max_tokens=10
            )
            self.llm_mq = self.clovastudio.ChatClovax(model="HCX-003", max_tokens=100)
            self.llm_qa = self.clovastudio.ChatClovax(
                max_tokens=1024, temperature=0.0001
            )
        elif self.llm_name == "gpt":
            self.llm_filter = self.openai.GPTModel(
                model="gpt-4o-mini", temperature=0.3, max_tokens=10
            )
            self.llm_mq = self.openai.GPTModel(
                model="gpt-4o", temperature=0.5, max_tokens=100
            )
            self.llm_qa = self.openai.GPTModel(
                model="gpt-4o-mini", temperature=0.0, max_tokens=1024
            )
        else:
            raise ValueError(
                "지원하는 언어모델이 아닙니다. hcx 또는 gpt 중 선택하세요."
            )

    def set_llm_qa(
        self, model_name: str, temperature: float = 0.0, max_tokens: int = 1024
    ):
        """답변 생성용 언어모델을 변경하는 함수

        Args:
            model_name (str): 사용할 모델 이름 (예: 'gpt-4o-mini', 'gpt-4-turbo' 등)
            temperature (float, optional): LLM의 temperature 설정. 기본값은 0.0.
            max_tokens (int, optional): 출력 최대 토큰 수. 기본값은 1024.
        """
        self.llm_qa = self.openai.GPTModel(
            model=model_name, temperature=temperature, max_tokens=max_tokens
        )
        self.qa_model_name = model_name
        logger.info(f"LLM QA 모델이 {self.qa_model_name}로 변경되었습니다.")

    def validate_query_type(self, query_type: Union[str, list]):

        # list에 있는 내부 string 값들이 validated 한지 검토하는 내부 함수
        def _validate_type_in_list(lst):
            validated = [
                "C000",
                "C101",
                "C102",
                "C103",
                "C104",
                "C105",
                "C106",
                "C199",
                "C201",
            ]
            not_valid_items = [item for item in lst if item not in validated]
            if len(not_valid_items) > 0:
                raise ValueError(f"{not_valid_items}는 지원하지 않는 query_type입니다.")
            else:
                pass

        def _set_type(lst):
            count = len(lst)
            if count >= 3:
                final_query_type = "C199"  # metadata의 type 적용 위한 값
                types = lst  # 전체 카테고리 코드
            elif count >= 2:
                selected = [item for item in lst if item != "C000"][0]
                final_query_type = selected
                types = lst
            elif count == 1:  # 아마 C000만 값으로 들어온 경우
                final_query_type = lst[0]
                types = lst
            else:  #
                final_query_type = "C000"
                types = ["C000"]
                logger.error(
                    "VALIDATE QUERY TYPE WARNING:: query_type이 비어있어 C000으로 설정합니다."
                )

            return final_query_type, types

        if isinstance(query_type, list):
            try:
                _validate_type_in_list(query_type)
                final_query_type, types = _set_type(query_type)
            except:
                logger.error(f"{query_type} 처리 중 에러 발생")

        elif isinstance(query_type, str):
            try:
                splitted = query_type.split("_")
                _validate_type_in_list(splitted)
                final_query_type, types = _set_type(splitted)
            except:
                logger.error(f"{query_type} 처리 중 에러 발생")
        else:
            raise ValueError(
                f"query_type: {type(query_type)}, query_type은 str 또는 list여야 합니다."
            )

        return final_query_type, types

    def get_session_history(self, session_ids):
        print(f"[대화 세션ID]: {session_ids}")
        if session_ids not in self.store:  # 세션 ID가 store에 없는 경우
            # 새로운 ChatMessageHistory 객체를 생성하여 store에 저장
            self.store[session_ids] = ChatMessageHistory()
        return self.store[session_ids]  # 해당 세션 ID에 대한 세션 기록 반환

    def filter_question(self, user_query: str, query_type: str):
        return asyncio.run(self.afilter_question(user_query, query_type))

    async def afilter_question(
        self, user_query: str, query_type: Union[str, list]
    ) -> str:
        """사용자가 작성한 질의가 실제 서비스의 목적에 부합하는 질문인지 그 타당성을 검토하는 비동기 함수

        Args:
            user_query (str): 사용자 질의

        Return:
            answer (str):  a text value of either Y, N, or E
        """
        final_query_type, _ = self.validate_query_type(query_type)
        filter_type = self.metadata[final_query_type]["filter_question"]

        dict_prompt_filter = read_yaml_file_safe(
            "process/rag/prompt/filter.yaml",
            "/data/venvs/chatai/app/process/rag/prompt/filter.yaml",
        )
        prompt_filter = dict_prompt_filter[filter_type]
        prompt_yn = PromptTemplate.from_template(prompt_filter)
        llm_chain1 = prompt_yn | self.llm_filter | StrOutputParser()
        answer = llm_chain1.invoke({"question": user_query})

        return answer

    def rewrite_query(self, user_query: str, query_type: Union[str, list]) -> str:
        """사용자의 질의를 키워드 기반으로 재작성하는 함수

        서비스별 실제 사용자가 사용하는 키워드와 문서상 키워드의 갭을 최소화하기 위하여 질의를 재작성하고, 임베딩 결과를 attr로 저장한다.
        ex. 수신(교본): 도장을 관리하는 방법 -> 도장(인감)을 관리하는 방법

        Args:
            user_query (str)
            query_type (str)

        Return:
            user_query (str): rewritted_query
        """

        def _replace(match):
            word = match.group(0)
            return f"{word}({word_dict[word]})"

        # llm 연결시 주석해제
        if 1 == 1:
            return user_query

        dictionary = read_yaml_file_safe(
            "config/dictionary.yaml", "/data/venvs/chatai/app/config/dictionary.yaml"
        )

        try:
            final_query_type, _ = self.validate_query_type(query_type)
            if final_query_type == "C199":
                lst_query = ["C103", "C104", "C105", "C106"]
                word_dict = {}
                for query in lst_query:
                    word_dict.update(dictionary[query])
            else:
                word_dict = dictionary[final_query_type]
        except Exception as e:
            logger.info(
                f"REWRITE QUERY INFO:: {query_type} is not in dictionary AND Return user_query"
            )
            user_query = user_query.lower()
            self.query_embedding = self.embedding.embed_query(user_query)
            return user_query

        try:
            user_query = user_query.lower()
            pattern = "|".join(map(re.escape, word_dict.keys()))
            rewritted_query = re.sub(pattern, _replace, user_query)
            logger.info(f"REWRITE QUERY RESULT:: {rewritted_query}")
            self.query_embedding = self.embedding.embed_query(user_query)
            return rewritted_query
        except Exception as e:
            logger.error(e, exc_info=True)
            user_query = user_query.lower()
            self.query_embedding = self.embedding.embed_query(user_query)
            return user_query

    def _generate_query_embedding(self, user_query: str) -> list:
        """사용자 쿼리에 대한 임베딩을 확인하고 부재시 생성 및 반환하는 함수"""
        query_embedding = getattr(self, "query_embedding", None)
        if query_embedding is None:
            embedding = self.clovastudio.Embedding()
            query_embedding = embedding.embed_query(user_query)
            self.query_embedding = query_embedding

        return query_embedding

    def _generate_query_embedding_openai(self, user_query: str) -> list:
        """사용자 쿼리에 대한 임베딩을 확인하고 부재시 생성 및 반환하는 함수"""
        query_embedding = getattr(self, "query_embedding", None)
        if query_embedding is None:
            embedding = self.openai.Embedding()
            query_embedding = embedding.embed_query(user_query)
            self.query_embedding = query_embedding

        return query_embedding

    @abstractmethod
    def multi_query(self, inputs):
        pass

    @abstractmethod
    async def amulti_query(self, inputs):
        pass

    def search_multi_faq(
        self,
        user_query: str,
        query_type: Union[str, list],
        multi_querys: list,
        threshold: float = 0.92,
    ):
        return asyncio.run(
            self.asearch_multi_faq(user_query, query_type, multi_querys, threshold)
        )

    async def asearch_multi_faq(
        self,
        user_query: str,
        query_type: Union[str, list],
        multi_querys: list,
        threshold: float = 0.92,
    ) -> FAQResult:
        """질의마다 FAQ를 탐색하여 유사한 질의를 찾고 대응하는 답변을 반환하는 비동기 함수

        Args:
            user_query (str)
            query_type (str | List[str])
            multi_querys: (List[str])
            threshold (float)

        Return:
            FAQResult
        """
        results = []

        # Initialize query embedding if not already set
        query_embedding = self._generate_query_embedding(user_query)

        # Combine multi_querys and user_query into a single list for parallel processing
        querys = multi_querys + [user_query]
        embeddings = [query_embedding] + self.multi_query_embedding

        # Prepare tasks for run_multithread
        final_query_type, types = self.validate_query_type(query_type)
        tasks = list()
        for typ in types:
            for query, embedding in zip(querys, embeddings):
                tasks.append(
                    {"user_query": query, "service": typ, "embedding": embedding}
                )
        # tasks = [{"user_query": query, "service": query_type, "embedding": embedding} for query, embedding in zip(querys, embeddings)]
        threads = run_multithread(tasks, self._search_faq)

        # Collect results from threads
        for thread in threads:
            try:
                result = thread.result()
                if result["max_score"] is not None:
                    results.append(
                        [result["max_score"], result["question"], result["answer"]]
                    )
            except Exception as e:
                logger.error(f"Error in thread execution: {e}")

        # Find the best result based on max_score
        try:
            sim_faq = max(results, key=lambda x: x[0])
            if sim_faq[0] >= threshold:
                return FAQResult(
                    score=sim_faq[0], question=sim_faq[1], answer=sim_faq[2]
                )
            else:
                return FAQResult(score=None, question=None, answer=None)
        except Exception as e:
            logger.error(f"Error in finding the best FAQ result: {e}")
            return FAQResult(score=None, question=None, answer=None)

    def _search_faq(self, args: dict):
        """질의에 대해 서비스별 유사한 질의가 있는지 벡터 탐색하여 반환하는 함수

        Args:
            user_query (str)
            serivce (str) e.g. "C101"
            embedding (List[float]|None): 질의의 임베딩 벡터

        Return:
            result (dict): 질의에 대한 FAQ 결과
                max_score (float|None): 질의와 FAQ 내 질의의 유사도
                question (str): FAQ에 등록된 질의
                answer (str): 질의에 대응하는 답변
        """
        embedding = args.get("embedding", None)
        user_query = args.get("user_query", None)
        service = args.get("service", None)

        if embedding is None:
            # get query vector
            embedding = self.embedding.embed_query(user_query)

        # set archive
        try:
            if "C103" in service:
                archive = ["교본(수신)"]
            elif "C104" in service:
                archive = ["교본(여신관리)", "교본(여신심사)", "여신업무"]
            elif "C101" in service:
                archive = ["규정(인사/총무)"]
            elif "C102" in service:
                archive = ["규정(인사/총무)"]
            elif "C106" in service:
                archive = ["규정(정보)"]
            else:
                archive = list()
                pass  # raise ValueError(f"{service}는 유효하지 않은 서비스입니다.")

        except ValueError as e:
            print(e)

        # OpenSearch 쿼리 본문 생성
        body = {
            "_source": {"exclude": ["vector_field"]},
            "size": 5,
            "query": {
                "bool": {
                    "must": [{"knn": {"vector_field": {"vector": embedding, "k": 10}}}]
                }
            },
        }

        if len(archive) > 0:
            body["query"]["bool"]["filter"] = [{"terms": {"metadata.archive": archive}}]

        # OpenSearch에 요청 보내기
        try:
            # AWS opensearch로 변경
            # client = opensearch_client()
            client = opensearch_client_aws()

            index_name = FAQ_INDEX_NAME
            results = client.search(index=index_name, body=body)  # vector search 결과
            # keyword search 추가
            max_score = results.get("hits", {}).get("max_score", None)
            hits = results.get("hits", {}).get("hits", [])
            if len(hits) > 0:
                question = hits[0]["_source"]["text"]
                answer = hits[0]["_source"]["metadata"]["answer"]
            else:
                question = ""
                answer = ""

            return {
                "max_score": max_score,
                "question": question,
                "answer": answer,
            }
        except Exception as e:
            raise e

    def filter_products_using_llm(self, user_query: str, query_type: str):
        """LLM을 이용하여 사용자 질문과 연관된 상품을 필터링함

        Args:
            user_query (str)
            query_type (str)
        Return:
            result (ResponseModel)
        """
        document_filter = read_yaml_file_safe(
            "config/document_filter.yaml",
            "/data/venvs/chatai/app/config/document_filter.yaml",
        )

        # 프롬프트 용도 분리 필요: 수신 상품용 / 여신 상품용
        template = """
        You are an AI assistant that processes user queries related to loan products handled by Welcome Savings Bank. Your task consists of two steps:

        1. Determine whether the user's question is about a specific product.
        - If the question explicitly mentions a product name or provides sufficient context to infer a specific product, classify it as a product-related question.
        - If the question is general or lacks sufficient product-related details, classify it as NOT related to a specific product.
        - If the question requires a **comparison or analysis of all loan products**, classify it as **NOT related to a specific product (`"False"`)**.
        - Your response **must** be either `"True"` (Yes) or `"False"` (No), without any additional text.

       2. If the question is about a specific product (`"Y"`), identify **exactly 3 relevant products** from the provided [Product List].  
        - **Understand and extract the loan name mentioned in the question.**  
        - Compare the extracted loan name with the product list and select the **3 most similar loan names** based on relevance.  
        - You must always select exactly 3 products, even if only one or two seem highly relevant. If fewer than 3 obvious matches are available, choose the next most relevant products from the list.  
        - **You must use the exact product names as they appear in the original [Product List] without any modifications, abbreviations, or paraphrasing.**  
        - **Pay special attention to numbers and spacing—these must be preserved exactly as they are in the original product names.**
        
        [Product List]
        {list_products}
        
        ### **Response Format (JSON)**
        Your output must strictly follow this JSON format:
        {format_instructions}

        Query: {question}
        """
        parser = PydanticOutputParser(pydantic_object=ResponseModel)
        prompt = PromptTemplate.from_template(template=template)
        prompt = prompt.partial(format_instructions=parser.get_format_instructions())

        chain = (
            prompt
            | self.openai.GPTModel(model="gpt-4o-mini", max_tokens=500, temperature=0.3)
            | parser
        )
        result = chain.invoke(
            {
                "list_products": "\n".join(document_filter[query_type]),
                "question": user_query,
            }
        )

        return result

    def filter_products_using_keyword(
        self, user_query: str, query_type: str, n=5, threshold=2.0
    ):
        """한국어 토크나이저를 사용하여 질의와 유사한 상품을 리스트업하는 함수

        Args:
            user_query (str): _description_
            query_type (str): _description_

        Returns:
            (list): _description_
        """
        from rank_bm25 import BM25Okapi
        from kiwipiepy import Kiwi

        document_filter = read_yaml_file_safe(
            "config/document_filter.yaml",
            "/data/venvs/chatai/app/config/document_filter.yaml",
        )

        corpus = document_filter[query_type]
        tokenized = document_filter[query_type + "토큰"]  # [[상품별 기분리된 토큰]]
        kiwi = Kiwi()
        bm25 = BM25Okapi(tokenized)
        query_tokens = [token.form for token in kiwi.tokenize(user_query)]

        scores = bm25.get_scores(query_tokens)
        scored_docs = sorted(zip(scores, corpus), key=lambda x: -x[0])
        top_candidates = scored_docs[:n]

        if top_candidates[0][0] < threshold:
            return list()

        return [doc for _, doc in top_candidates]  # result

    def filter_products_using_cosine_similarity2(self, args: dict) -> list:
        """cosine similarity를 사용하여 질의와 유사한 상품을 리스트업하는 함수

        Args:
            query_embedding (list): 질의의 임베딩 벡터
            query_type (str): 질의 유형

        Returns:
            top_candidates (list): 유사한 상품 리스트
        """

        query_embedding = args.get("query_embedding", None)
        query_type = args.get("query_type", None)
        n = args.get("n", 5)
        threshold = args.get("threshold", 0.5)

        document_filter = read_yaml_file_safe(
            "config/document_filter.yaml",
            "/data/venvs/chatai/app/config/document_filter.yaml",
        )

        corpus = document_filter[query_type]

        # user_query와 corpus를 벡터화
        # embedding = self.clovastudio.Embedding()
        corpus_embeddings = self.embedding.embed_documents(
            corpus
        )  # Batch embedding for efficiency

        # 코사인 유사도 계산
        query_embedding_np = np.array(query_embedding)
        corpus_embeddings_np = np.array(corpus_embeddings)

        # Vectorized cosine similarity computation
        dot_products = np.dot(corpus_embeddings_np, query_embedding_np)
        query_norm = np.linalg.norm(query_embedding_np)
        corpus_norms = np.linalg.norm(corpus_embeddings_np, axis=1)
        cosine_similarities = dot_products / (query_norm * corpus_norms)

        # 유사도 점수와 문서 쌍을 정렬
        scored_docs = sorted(zip(cosine_similarities, corpus), key=lambda x: -x[0])

        # 상위 n개 문서 선택
        top_candidates = [doc for score, doc in scored_docs if score >= threshold][:n]

        return top_candidates

    def filter_products_using_cosine_similarity(
        self, query_embedding: list, query_type: str, n=5, threshold=0.5
    ) -> list:
        """cosine similarity를 사용하여 질의와 유사한 상품을 리스트업하는 함수

        Args:
            query_embedding (list): 질의의 임베딩 벡터
            query_type (str): 질의 유형

        Returns:
            top_candidates (list): 유사한 상품 리스트
        """

        document_filter = read_yaml_file_safe(
            "config/document_filter.yaml",
            "/data/venvs/chatai/app/config/document_filter.yaml",
        )

        corpus = document_filter[query_type]

        # user_query와 corpus를 벡터화
        # embedding = self.clovastudio.Embedding()
        corpus_embeddings = self.embedding.embed_documents(
            corpus
        )  # Batch embedding for efficiency

        # 코사인 유사도 계산
        query_embedding_np = np.array(query_embedding)
        corpus_embeddings_np = np.array(corpus_embeddings)

        # Vectorized cosine similarity computation
        dot_products = np.dot(corpus_embeddings_np, query_embedding_np)
        query_norm = np.linalg.norm(query_embedding_np)
        corpus_norms = np.linalg.norm(corpus_embeddings_np, axis=1)
        cosine_similarities = dot_products / (query_norm * corpus_norms)

        # 유사도 점수와 문서 쌍을 정렬
        scored_docs = sorted(zip(cosine_similarities, corpus), key=lambda x: -x[0])

        # 상위 n개 문서 선택
        top_candidates = [doc for score, doc in scored_docs if score >= threshold][:n]

        return top_candidates

    def filter_products_using_threads(
        self, user_query: str, query_type: str, n=5, threshold=0.5
    ) -> list:
        """filter_products_using_cosine_similarity를 멀티스레드로 실행하는 함수"""
        results = []
        query_embedding = self._generate_query_embedding(user_query)
        embeddings = [query_embedding] + self.multi_query_embedding
        tasks = [
            {
                "query_embedding": embedding,
                "query_type": query_type,
                "n": n,
                "threshold": threshold,
            }
            for embedding in embeddings
        ]
        threads = run_multithread(tasks, self.filter_products_using_cosine_similarity2)

        for thread in threads:
            try:
                result = thread.result()
                if result is not None:
                    results.extend(result)
            except Exception as e:
                logger.error(f"Error in thread execution: {e}")

        # 중복 제거
        results = list(set(results))  # 비어있을때 되는지 확인 필요

        return results

    def _execute_search(
        self,
        multi_querys: list,
        multi_query_embeddings: list,
        index_name: str | list,
        filters: list,
    ) -> pd.DataFrame:
        """멀티 쿼리를 사용하여 검색을 실행하고 결과를 데이터프레임으로 반환하는 함수"""
        df_part = pd.DataFrame()
        for query, embedding in zip(multi_querys, multi_query_embeddings):
            logger.info(f"MULTI QUERY 임베딩: {query}")
            _, contexts, metas, vectors = search_ensemble_with_filter(
                index_name, query, filters, embedding
            )
            section_levels = [meta["section_level"] for meta in metas]
            chunk_ids = [meta["chunk_id"] for meta in metas]
            sources = [meta["source"] for meta in metas]
            page_nums = [meta["page_num"] for meta in metas]
            priority = [meta["priority"] for meta in metas]

            temp = pd.DataFrame(
                {
                    "context": contexts,
                    "section_level": section_levels,
                    "chunk_id": chunk_ids,
                    "source": sources,
                    "page_num": page_nums,
                    "vector": vectors,
                    "priority": priority,
                }
            )
            df_part = pd.concat([df_part, temp])

        return df_part

    def _get_rerank_score(
        self,
        df_part: pd.DataFrame,
        user_query: str,
        query_embedding: list,
        rerank_model: str,
    ) -> list:
        """Rerank score를 계산하는 함수
        e
        Args:
            df_part (pd.DataFrame): 검색 결과 데이터프레임
            user_query (str): 사용자 질의
            query_embedding (list): 사용자 질의의 임베딩 벡터
            rerank_model (str): rerank 모델 이름
        Returns:
            list_score (list): rerank score 리스트
        """
        if rerank_model == "flashrank":
            logger.info("RERANK Start: apply flashrank")
            ranker = Ranker(model_name="ms-marco-MultiBERT-L-12", cache_dir="../models")
            documents = [{"text": text} for text in df_part["context"].values]
            request = RerankRequest(query=user_query, passages=documents)
            results = ranker.rerank(request)
            results_dict = {
                item["text"]: item["score"] for item in results
            }  # text를 키로 하는 딕셔너리 생성
            list_score = [
                results_dict[item["text"]] for item in documents
            ]  # doc의 순서에 맞게 score 값을 추출
        elif rerank_model == "cosine":
            list_score = get_score_matrix(df_part, query_embedding)
            list_score = [score[0] for score in list_score]
        else:
            list_score = [None for _ in len(df_part)]

        return list_score

    def _process_results(
        self,
        df_part: pd.DataFrame,
        query_type: str | list,
        total_chunk: int,
        query_embedding: list,
        index_name: str | list,
    ) -> tuple:
        """검색 결과를 처리하여 최종 결과를 반환하는 함수

        Args:
            df_part (pd.DataFrame): 검색 결과 데이터프레임
            query_type (str|list): 질의 유형
            total_chunk (int): 반환할 결과의 개수
            query_embedding (list): 사용자 질의의 임베딩 벡터
            index_name (str|list): 검색 인덱스 이름
        Returns:
            total_context (list): 최종 검색 결과의 문맥 리스트
            total_meta (list): 최종 검색 결과의 메타데이터 리스트
        """
        df_part = df_part.sort_values(
            ["priority", "score"], ascending=[True, False]
        ).reset_index(drop=True)
        total_chunk += df_part[
            (df_part.index < total_chunk)
            & (df_part.context.apply(lambda x: len(x)) < 200)
        ].shape[0]

        if query_type == "C103":  # "C103" in query_type:
            df_part["priority"] = df_part["priority"].fillna(9)
            num_per_prior = (
                total_chunk // df_part["priority"].nunique()
            )  # none 포함 위함
            df_final = (
                df_part.groupby("priority")
                .apply(lambda x: x.nlargest(num_per_prior, "score"))
                .reset_index(drop=True)
            )
        else:
            df_final = df_part.head(total_chunk)

        logger.info("ADD INFO Start")
        list_args = pre_multiprocessing(df_final, index_name, query_embedding)
        logger.info(f"ADD INFO List size: {len(list_args)}")
        list_thread = run_multithread(list_args, search_neighbor)
        list_thread = [thread.result() for thread in list_thread]
        df_final["context"] = list_thread
        logger.info("ADDINFO END")
        logger.info(df_final.shape)

        df_final = df_final.drop("vector", axis=1)
        df_final = df_final.drop_duplicates().reset_index(drop=True)

        df_max = (
            df_final[["section_level", "score"]]
            .groupby("section_level")
            .max("score")
            .reset_index()
            .rename(columns={"score": "max_score"})
        )
        df_final = pd.merge(df_final, df_max, on="section_level", how="left")
        df_final["context_length"] = df_final["context"].apply(len)
        df_final = df_final.sort_values(
            ["max_score", "context_length"], ascending=[False, False]
        )

        total_context = df_final["context"].values.tolist()
        list_meta = list(
            zip(
                df_final["source"].tolist(),
                df_final["section_level"].tolist(),
                df_final["page_num"].tolist(),
            )
        )
        total_meta = [
            {"source": source, "section_level": section_level, "page_num": page_num}
            for source, section_level, page_num in list_meta
        ]
        return total_context, total_meta

    def search_context(
        self,
        user_query: str,
        query_type: str,
        multi_querys: list,
        total_chunk=10,
        rerank_model="cosine",
    ):
        return asyncio.run(
            self.asearch_context(
                user_query, query_type, multi_querys, total_chunk, rerank_model
            )
        )

    async def asearch_context(
        self,
        user_query: str,
        query_type: Union[str, list],
        multi_querys: list,
        total_chunk=10,
        rerank_model="cosine",
    ) -> tuple:
        """질의 및 멀티 쿼리를 이용한 검색 결과를 반환하는 API용 비동기 함수

        Args
            user_query (str)
            query_type (Union[str, list])
            multi_querys (List[str])
            total_chunk (int)
            rerank_model (str): default="cosine"

        Return
            total_context (List[str])
            total_meta (List[{"source", "section_level", "page_num"}])
        """

        document_filter = read_yaml_file_safe(
            "config/document_filter.yaml",
            "/data/venvs/chatai/app/config/document_filter.yaml",
        )
        # query_type validation
        final_query_type, types = self.validate_query_type(query_type)
        try:
            list_filter = document_filter[final_query_type]  # C103, C104만 해당함
        except:
            list_filter = list()
        print("openai embedding")
        logger.info("openai 임베딩 시작")
        # query_embedding = self._generate_query_embedding(user_query)
        query_embedding = self._generate_query_embedding_openai(user_query)
        logger.info("openai 임베딩 종료")

        # filter products using keyword
        logger.info("질의 상품 관련성 검토 및 상품 선정 시작")
        if final_query_type == "C104":
            filters = self.filter_products_using_threads(user_query, final_query_type)
            if len(filters) > 0:
                filters.extend(document_filter["C104(일반)"])
        else:
            if len(list_filter) > 0:
                filters = [
                    filter
                    for filter in list_filter
                    if filter in user_query.replace(" ", "")
                ]
            else:
                filters = list()
        logger.info(f"관련 상품 목록: {filters}")
        logger.info("질의 상품 관련성 검토 및 상품 선정 종료")

        df_part = pd.DataFrame()
        index_name = list()
        if final_query_type == "C199":
            for typ in types:
                index_name.append(self.metadata[typ]["index_name"])
        else:
            index_name.append(self.metadata[final_query_type]["index_name"])
            index_name.append(self.metadata["C000"]["index_name"])  # default
        logger.info("START ENSEMBLE SEARCH")

        try:
            # multi query가 없는 경우(파싱 에러 등) 방어
            if len(multi_querys) == 0:
                multi_querys.append(user_query)
            else:
                pass
            logger.info(f"ALL MULTI QUERY: {multi_querys}")
            df_part = self._execute_search(
                multi_querys, self.multi_query_embedding, index_name, filters
            )
            df_part["vector"] = df_part["vector"].apply(
                tuple
            )  #############################
            df_part = df_part.drop_duplicates().reset_index(drop=True)
            df_part["vector"] = df_part["vector"].apply(
                list
            )  #############################
            logger.info("END ENSEMBLE SEARCH")
        except Exception as e:
            logger.error(e, exc_info=True)
            raise Exception("앙상블 검색 중 오류가 발생했습니다.")

        logger.info("START RERANK")
        try:
            list_score = self._get_rerank_score(
                df_part, user_query, query_embedding, rerank_model
            )
            df_part["score"] = list_score
        except Exception as e:
            logger.error(e, exc_info=True)
            return (
                list(),
                list(),
            )  # 검색 결과가 0개인 경우 대응 가능한 방어 로직 필요: 빈 total_context, total_meta 반환
        logger.info("END RERANK")

        logger.info("START PROCESS SEARCH RESULTS")
        """변경절차: rerank score 계산 후에 정렬, total_chunk(+알파)만큼 자른 후에 해당 건에 대해서만 add info
        add info 과정이 2~3초 소요되어 시간 단축 위해 수정
        """
        try:
            total_context, total_meta = self._process_results(
                df_part, final_query_type, total_chunk, query_embedding, index_name
            )
        except Exception as e:
            logger.error(e, exc_info=True)
            return list(), list()
        logger.info("END PROCESS SEARCH RESULTS")

        return total_context, total_meta

    def filter_by_threshold(self, threshold: int = 0.8):
        pass

    def get_meta(self, total_meta: list) -> str:
        """검색된 메타정보들의 정보를 취합하여 반환하는 함수

        Args:
            total_meta (List[dict]): 검색된 청크들의 메타정보

        Return:
            doc_info (str): 가공한 메타정보
        """
        return asyncio.run(self.aget_meta(total_meta))

    async def aget_meta(self, total_meta: list) -> str:
        """검색된 메타정보들의 정보를 취합하여 반환하는 비동기 함수

        Args:
            total_meta (List[dict]): 검색된 청크들의 메타정보

        Return:
            doc_info (str): 가공한 메타정보
        """
        try:
            # 중복 제거
            unique_meta = list()
            for d in total_meta:
                if (d["source"], d["page_num"]) not in [
                    (ud["source"], ud["page_num"]) for ud in unique_meta
                ]:
                    unique_meta.append(d)

            # 문서별 페이지 넘버를 comma로 구분하여 리스트업
            results = {}
            formatted_strings = []
            for d in unique_meta:
                source = d["source"]
                page = d["page_num"]
                if source not in results:
                    results[source] = []
                if page not in results[source]:
                    results[source].append(str(int(float(page))))

            for source, pages in results.items():
                sorted_pages = ",".join(sorted(pages, key=int))
                formatted_strings.append(
                    f'{{"page": "{sorted_pages}", "file":"{source}"}}'
                )
                # sorted_pages = ','.join(sorted(pages, key=int))
            # formatted_strings.append(f"Page {sorted_pages} of {source}")
            # doc_info = "  \n\n##### **[검색 문서]**\n" + "  \n".join(formatted_strings)
            doc_info = "[" + ",".join(formatted_strings) + "]"

            return doc_info
        except Exception as e:
            logger.error(e)
            return ""

    def generate_answer_temp(self, user_query: str):
        now_kst = datetime.now(ZoneInfo("Asia/Seoul"))
        date_str = now_kst.strftime("%Y년 %-m월 %-d일")  # Unix/Linux/macOS
        system_prompt = f"""
        당신은 웰컴저축은행 임직원의 질문에 답변하는 성실한 AI Assistant입니다.
        오늘의 날짜는 {date_str}이고, 여기는 대한민국입니다.
        사용자의 질문에 적절하게 2000토큰 이내에서 답변하세요.
        웹 검색 도구를 사용한다면, 반드시 검색된 출처 URL을 user에게 함께 제공하세요.
        """
        prompt_answer = ChatPromptTemplate.from_messages(
            [("system", system_prompt), ("user", "{user_query}")]
        )
        tool = {
            "type": "web_search_preview",
            "user_location": {"type": "approximate", "country": "KR", "city": "Seoul"},
            "search_context_size": "high",
        }
        self.set_llm_qa(model_name="gpt-4.1-mini", max_tokens=2048, temperature=0.3)
        llm_with_tools = self.llm_qa.bind_tools([tool], tool_choice="any")
        llm_chain3 = prompt_answer | llm_with_tools
        answer = llm_chain3.invoke({"user_query": user_query})
        return answer

    def generate_answer(
        self,
        user_query: str,
        query_type: Union[str, list],
        conversation_id: str,
        answerType: str,
        store: dict,
        total_context: str,
    ):
        """질의에 대한 답변을 stream 방식으로 생성하는 객체를 반환하는 함수

        Args:
            user_query (str): 사용자의 질문
            query_type (Union[str, list]): 질의 유형
            conversation_id (str): 대화 세션 ID
            answerType (str): 답변 유형
            store (dict): 메타정보
            total_context (str): 검색된 청크들의 내용

        Returns:
            (generator)
        """
        final_query_type, _ = self.validate_query_type(query_type)
        meta_dict = self.metadata[final_query_type]
        logger.info(f"tkkim meta_dict:{meta_dict}")
        self.store = store  # inputs["store"]

        dict_prompt_generate = read_yaml_file_safe(
            "process/rag/prompt/generate.yaml",
            "/data/venvs/chatai/app/process/rag/prompt/generate.yaml",
        )

        if answerType not in ["10", "11"]:
            # 문서검색
            if (answerType == "04") or (answerType == "05"):
                prompt_generate = dict_prompt_generate[meta_dict["answer_smarter"]]
            else:
                prompt_generate = dict_prompt_generate[meta_dict["answer_question"]]
            prompt_answer = ChatPromptTemplate.from_messages(
                [
                    MessagesPlaceholder(variable_name="chat_history"),
                    ("system", prompt_generate),
                    ("user", "{question}"),
                ]
            )
        else:
            # 대화하기
            now_kst = datetime.now(ZoneInfo("Asia/Seoul"))
            date_str = now_kst.strftime("%Y년 %-m월 %-d일")  # Unix/Linux/macOS
            system_prompt = f"""
            당신은 웰컴저축은행 임직원의 질문에 답변하는 성실한 AI Assistant입니다.
            오늘의 날짜는 {date_str}이고, 여기는 대한민국입니다.
            사용자의 질문에 적절하게 2000토큰 이내에서 답변하세요.
            웹 검색 도구를 사용한다면, 반드시 검색된 출처 URL을 user에게 함께 제공하세요.
            만약 회사와 관련된 정보를 문의한다면, "문서검색" 서비스를 이용하라고 안내하세요.
            """
            prompt_answer = ChatPromptTemplate.from_messages(
                [
                    ("system", system_prompt),
                    MessagesPlaceholder(variable_name="chat_history"),
                    ("user", "{question}"),
                ]
            )

        if answerType == "11":
            # 대화하기(웹서치)
            tool = {
                "type": "web_search_preview",
                "user_location": {
                    "type": "approximate",
                    "country": "KR",
                    "city": "Seoul",
                },
                "search_context_size": "high",
            }
            self.set_llm_qa(model_name="gpt-4.1-mini", max_tokens=2048, temperature=0.3)
            llm_with_tools = self.llm_qa.bind_tools([tool], tool_choice="any")
            llm_chain3 = prompt_answer | llm_with_tools | StrOutputParser()
        elif answerType == "10":
            self.set_llm_qa(model_name="gpt-4o", max_tokens=2048, temperature=0.3)
            llm_chain3 = prompt_answer | self.llm_qa | StrOutputParser()
        else:
            if (answerType == "04") or (answerType == "05"):
                self.set_llm_qa(model_name="gpt-4o")
            # 문서검색 및 대화하기(기본)
            llm_chain3 = prompt_answer | self.llm_qa | StrOutputParser()

        logger.info(f"chain_with_history {llm_chain3}")
        prompt_answer = ChatPromptTemplate.from_template(
        )

        stub = prompt_answer | MockModel(user_query) | StrOutputParser()

        chain_with_history = RunnableWithMessageHistory(
            #            llm_chain3,
            stub,
            self.get_session_history,  # 세션 기록을 가져오는 함수
            input_messages_key="question",  # 사용자의 질문이 템플릿 변수에 들어갈 key
            history_messages_key="chat_history",  # 기록 메시지의 키
        )
        total_context = "/n/n".join(
            f"Chunk {i+1}\n{v}" for i, v in enumerate(total_context)
        )  # 청크 구분을 위해 추가
        logger.info("total_context")
        return chain_with_history.stream(
            {"question": user_query, "total_context": total_context},
            config={"configurable": {"session_id": conversation_id}},
        )

    async def get_selected_result(
        self, user_id: str, conversation_id: str, seq: int
    ) -> tuple:

        logger.info("get_chat_cache START")
        response = get_chat_cache(user_id, conversation_id, seq)  # dict
        logger.info("get_chat_cache::", response)
        DEFAULT_CATEGORY = "C000"

        if len(response["hits"]["hits"]) == 0:
            logger.warning("get_chat_cache에서 검색결과 부재로 인한 디폴트 결과 반환")
            return list(), "", [DEFAULT_CATEGORY]
        else:
            total_context = response["hits"]["hits"][0]["_source"].get(
                "total_context", list()
            )  # list
            meta = response["hits"]["hits"][0]["_source"].get("meta", "")  # string
            archive = response["hits"]["hits"][0]["_source"].get(
                "archive", ""
            )  # string
            print(archive, type(archive))
            if isinstance(archive, str):
                query_type = archive.split("_")
                if (len(query_type) == 1) & (query_type[0] == ""):
                    logger.warning(
                        f"히스토리 중 archive split 에러 발생: {archive} > {query_type}"
                    )
                    query_type = [DEFAULT_CATEGORY]
                logger.info(f"SPLITTED QUERY TYPE::: {query_type}")
            elif isinstance(archive, list):
                query_type = archive
            else:
                raise TypeError(f"히스토리 중 archive 타입 에러 발생: {archive}")

            return total_context, meta, query_type

    def invoke(self, inputs):
        """py 테스트를 위한 기본 RAG 프로세스

        Args:
            inputs (dict): _description_

        Returns:
            _type_: _description_
        """
        # 1) 사용자 질문 입력
        user_query = inputs["user_input"]
        query_type = inputs["query_type"]
        inputs["meta_dict"] = self.metadata[
            query_type
        ]  # e.g) {'index_name': 'v1','multiquery': 'rule1'}

        # 2) 질의 타당성 검토
        is_filter = self.filter_question(user_query)

        # 3-1)[답변생성1] 질의 타당섬 검토 결과 N이거나 사용자 질문이 공백으로 들어온 경우 "답변할 수 없는 질문"으로 답변 출력
        if (is_filter == "N") or (user_query.strip() == ""):
            return {
                "original_question": user_query,
                "multi_querys": [],
                "answer": "질문이 모호하거나 답변할 수 없는 질문입니다. 다른 질문을 시도해주세요.",
                "meta": "",
            }
        else:
            # 3-2)[답변생성2] 질의 타당섬 검토 결과 Y 또는 E인 경우 다음 단계로 넘어감
            # 4) 멀티쿼리 생성 : 사용자의 질문을 3개로 재생성
            inputs = self.multi_query(inputs)
            # 5) 재생성 질문을 기반으로 자료 검색하여 답변 생성
            answer, meta = self.generate_answer(inputs)
            return {
                "original_question": user_query,
                "multi_querys": inputs[""],
                "answer": answer,
                "meta": meta,
            }
