from process.rag.category_rule import RulePipeline
from process.rag.category_conversation import ConversationPipeline
from typing import Union

class PipelineManager:
    @staticmethod
    def get_pipeline(query_type: Union[str, list]):  
        try:
            if "C201" in query_type:
                return ConversationPipeline()
            else:
                return RulePipeline()
        except:
            return ConversationPipeline()
