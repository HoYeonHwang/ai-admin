import logging
import boto3

from utils import utils 
# logger = utils.createLogger(__name__)

 
def time_logging(*args):
    import datetime
    KST = datetime.timezone(datetime.timedelta(hours=9))
    timestamp = datetime.datetime.now(KST).strftime("%Y/%m/%d %H:%M:%S")
    list_args = [string for string in args]
    print(f'[[{timestamp}]]::' +' '.join(list_args))

def opensearch_client_ncp():
    from opensearchpy import OpenSearch
    opensearch = OpenSearch(
        hosts=[{'host' : utils.getOsEnviron("OPENSEARCH_URL"), 'port' : 9200}], #text/html
        # http_auth = ('inotech', 'Welcome88!'),
        http_auth = (utils.getOsEnviron("OPENSEARCH_ID"), utils.getOsEnviron("OPENSEARCH_PWD")),
        use_ssl = True,
        verify_certs=False,
        ssl_show_warn = False,
        headers ={"User-Agent": "Mozilla/5.0"}
    )
    return opensearch

def opensearch_client():
    from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth 
    region = utils.getOsEnviron("REGION_NAME")
    service = 'aoss'
    session = boto3.Session(
        aws_access_key_id=utils.getOsEnviron("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=utils.getOsEnviron("AWS_SECRET_ACCESS_KEY"),
        region_name=region,
    )
    credentials = session.get_credentials()
    auth = AWSV4SignerAuth(credentials, region, service)
    opensearch = OpenSearch(
        hosts=[{'host': utils.getOsEnviron("OPENSEARCH_URL"), 'port': 443}],
        http_auth=auth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection # 중요: requests 기반 연결 사용
    )
    return opensearch

def conn_vector_store(index_name, embedding):
    from langchain_community.vectorstores import OpenSearchVectorSearch
    vector_store = OpenSearchVectorSearch(
        opensearch_url="http://welcomebank-ses-nlb-100287313-d7590f62f6e7.kr.lb.naverncp.com:9200",
        http_auth = ('inotech', 'Welcome88!'),
        use_ssl = True,
        verify_certs=False,
        ssl_show_warn = False,
        headers ={"User-Agent": "Mozilla/5.0"},
        index_name = index_name,
        embedding_function = embedding,
        dim=1024
    )
    return vector_store
    
def ensemble_search(user_query, index_name):
    try:
        from process.rag.llm_interface import ClovaStudio
    except ImportError:
        from process.rag.llm_interface import ClovaStudio
    except Exception as e:
        raise e
    from langchain_core.documents import Document
    from langchain.retrievers import EnsembleRetriever
    from langchain_community.retrievers import BM25Retriever
    
    clovastudio = ClovaStudio()
    embedding = clovastudio.Embedding()
    vector_store = conn_vector_store(index_name, embedding)
    # 1.벡터 검색기
    vector_retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k" : 10})
    # 1-1.벡터스코어
    list_vector = vector_store.similarity_search_with_score(user_query, k=10)
    list_score = [vec[1] for vec in list_vector]
    max_score = max(list_score)
    # 2.BM25검색기
    ids, docs, metas, scores = search_keyword(index_name, user_query, 10)
    list_text = [Document(id= id, metadata=meta, page_content= doc) for id, meta, doc in list(zip(ids, metas, docs))]
    if len(list_text)==0:
        list_result = vector_retriever.invoke(input=user_query)[:10]
    else:
        bm25_retriever = BM25Retriever.from_documents(list_text)
        bm25_retriever.k = 10
        
        # 3.앙상블 검색기
        ensemble_retriever = EnsembleRetriever(
            retrievers=[bm25_retriever, vector_retriever],
            weights=[0.3, 0.7],
        )
        # ensemble_retriever.invoke(user_query)
        list_result = ensemble_retriever.invoke(input=user_query)
    list_context = [result.page_content for result in list_result]
    list_meta = [result.metadata for result in list_result]         #변경### metadata(source, section_level, page_num) 리스트    
    return list_context, list_meta

def search_keyword(index_name, user_query, k):
    # import llm_interface 
    import json
    client = opensearch_client()
    # clova_studio = llm_interface.ClovaStudio()
    # embedding = clova_studio.Embedding()
    # user_embedding = embedding.embed_query(user_query)
    body = {
      "_source" : {
        "exclude" : [
            "vector_field"
          ]
      },
      "size" : k,
      "query" : {
        "multi_match" : {
            "query": user_query,
            "fields" : ["text"],
            "fuzziness" : "AUTO"
          }
        }
      }
    
    response = client.search(index=index_name, body=body)
    
    list_id=list();list_context=list();list_score=list();list_meta=list()
    for answer in response['hits']['hits']:
        list_id.append(answer['_id'])
        list_context.append(answer['_source']['text'])
        list_score.append(answer['_score'])
        dict_meta = answer['_source']['metadata']
        list_meta.append({
            'source' : dict_meta['source'],
            'section_level' : dict_meta['section_level'],
            'chunk_id' : dict_meta['chunk_id'],
            'page_num' : dict_meta['page_num']
        })
    return list_id, list_context, list_meta, list_score
    
def search_vector(index_name, user_query, k=10):
    """
    Perform a vector-based search on an OpenSearch index using a user query.
    Args:
        index_name (str): The name of the OpenSearch index to search.
        user_query (str): The query string provided by the user.
        k (int, optional): The number of top results to retrieve. Defaults to 10.
    Returns:
        tuple: A tuple containing the following lists:
            - list_id (list): A list of document IDs from the search results.
            - list_context (list): A list of text content from the search results.
            - list_meta (list): A list of metadata dictionaries for each result, containing:
                - source (str): The source of the document.
                - section_level (int): The section level of the document.
                - chunk_id (str): The chunk ID of the document.
                - page_num (int): The page number of the document.
            - list_score (list): A list of relevance scores for each result.
            - list_vector (list): A list of vector representations for each result.
    Raises:
        ImportError: If the required module `ClovaStudio` cannot be imported.
        Exception: If any other exception occurs during execution.
    """

    try:
        from process.rag.llm_interface import ClovaStudio
    except ImportError:
        from process.rag.llm_interface import ClovaStudio
    except Exception as e:
        raise e
        
    client = opensearch_client()
    clovastudio = ClovaStudio()
    embedding = clovastudio.Embedding()
    query_embedding = embedding.embed_query(user_query)
    
    body = {
      "size": k,
      "query": {
        "bool": {
          "should": [
            {
              "knn": {
                "vector_field": {
                  "vector": query_embedding,
                  "k": k
                }
              }
            }
            ]
        }
      }
    }
    response = client.search(index=index_name, body=body)
    list_id=list();list_context=list();list_score=list();list_meta=list();list_vector=list()
    for answer in response['hits']['hits']:
        list_id.append(answer['_id'])
        list_context.append(answer['_source']['text'])
        list_score.append(answer['_score'])
        list_vector.append(answer['_source']['vector_field'])
        dict_meta = answer['_source']['metadata']
        list_meta.append({
            'source' : dict_meta['source'],
            'section_level' : dict_meta['section_level'],
            'chunk_id' : dict_meta['chunk_id'],
            'page_num' : dict_meta['page_num']
        })
    return list_id, list_context, list_meta, list_score, list_vector

def search_keyword2(index_name, user_query, k=10):
    # import llm_interface 
    import json
    client = opensearch_client()
    # clova_studio = llm_interface.ClovaStudio()
    # embedding = clova_studio.Embedding()
    # user_embedding = embedding.embed_query(user_query)
    body = {
      # "_source" : {
      #   "exclude" : [
      #       "vector_field"
      #     ]
      # },
      "size" : k,
      "query" : {
        "multi_match" : {
            "query": user_query,
            "fields" : ["text"],
            "fuzziness" : "AUTO"
          }
        }
      }
    
    response = client.search(index=index_name, body=body)
    
    list_id=list();list_context=list();list_score=list();list_meta=list();list_vector=list()
    for answer in response['hits']['hits']:
        list_id.append(answer['_id'])
        list_context.append(answer['_source']['text'])
        list_score.append(answer['_score'])
        list_vector.append(answer['_source']['vector_field'])
        dict_meta = answer['_source']['metadata']
        list_meta.append({
            'source' : dict_meta['source'],
            'section_level' : dict_meta['section_level'],
            'chunk_id' : dict_meta['chunk_id'],
            'page_num' : dict_meta['page_num']
        })
    return list_id, list_context, list_meta, list_score, list_vector

#########################################################################################################
def search_keyword_with_filter(index_name, user_query, filters, k=10):
    # logger.info("키워드 검색 중")
    
    # import llm_interface 
    import json
    client = opensearch_client()
    # clova_studio = llm_interface.ClovaStudio()
    # embedding = clova_studio.Embedding()
    # user_embedding = embedding.embed_query(user_query)
    ################################################################## search_keyword2에 추가된 부분
    body = {
      "size": k,
      "query": {
        "bool": {
          "must": {
            "multi_match": {
              "query": user_query,
              "fields": ["text"],
              "fuzziness": "AUTO"
            }
          }
        }
      }
    }
    if len(filters) != 0:
        if "welcome-chatbot-104" == index_name:
            meta_key = "source"
        elif "welcome-chatbot-103" in index_name:
            meta_key = "filters"
        # if index_name == "welcome-chatbot-4*":
        #     meta_key = "source"
        # elif index_name == "welcome-chatbot-5*":
        #     meta_key = "filters"
        else:
            pass
        dict_filters = [{"term": {f"metadata.{meta_key}": filter}} for filter in filters] # metadata.filter
        body['query']['bool']['filter'] = {"bool": {"should": dict_filters}}
        
        # logger.info(f'키워드 검색 body 검토 len(filters) != 0: {body}')
    #################################################################
    
    response = client.search(index=index_name, body=body)
    list_id=list();list_context=list();list_score=list();list_meta=list();list_vector=list()
    
    for answer in response['hits']['hits']:
        list_id.append(answer['_id'])
        list_context.append(answer['_source']['text'])
        list_score.append(answer['_score'])
        list_vector.append(answer['_source']['vector_field'])
        dict_meta = answer['_source']['metadata']
        list_meta.append({
            'source': dict_meta['source'],
            'section_level': dict_meta['section_level'],
            'chunk_id': dict_meta['chunk_id'],
            'page_num': dict_meta['page_num'],
            'priority': dict_meta.get('priority', None),
            'load_date': dict_meta.get('load_date', None)
        })
    # logger.info(list_context)
    
    return list_id, list_context, list_meta, list_score, list_vector

def search_vector_with_filter(index_name, user_query, filters, embedding, k=10):
    # logger.info("벡터 검색 중")
    try:
        from process.rag.llm_interface import ClovaStudio
    except Exception as e:
        raise e
    client = opensearch_client()
    # clovastudio = ClovaStudio()
    # embedding = clovastudio.Embedding()
    # query_embedding = embedding.embed_query(user_query)
    
    body = {
      "size": k,
      "query": {
        "bool": {
          "should": [
                {
                    "knn": {
                        "vector_field": {
                            "vector": embedding,
                            "k": k*3
                        }
                    }
                }
            ]
        }
      }
    }
    if len(filters) != 0:
        if "welcome-chatbot-104" == index_name:
            meta_key = "source"
        elif "welcome-chatbot-103" in index_name:
            meta_key = "filters"
        # if index_name == "welcome-chatbot-4*":
        #     meta_key = "source"
        # elif index_name == "welcome-chatbot-5*":
        #     meta_key = "filters"
        else:
            pass
        dict_filters = [{"term": {f"metadata.{meta_key}": filter}} for filter in filters] # metadata.filter
        body['query']['bool']['filter'] = {"bool": {"should": dict_filters}}
        
        # logger.info(f'벡터 검색 body 검토 len(filters) != 0: {body}')
    #################################################################
    
    response = client.search(index=index_name, body=body)
    list_id=list();list_context=list();list_score=list();list_meta=list();list_vector=list()
    
    for answer in response['hits']['hits']:
        list_id.append(answer['_id'])
        list_context.append(answer['_source']['text'])
        list_score.append(answer['_score'])
        list_vector.append(answer['_source']['vector_field'])
        dict_meta = answer['_source']['metadata']
        list_meta.append({
            'source' : dict_meta['source'],
            'section_level' : dict_meta['section_level'],
            'chunk_id' : dict_meta['chunk_id'],
            'page_num' : dict_meta['page_num'],
            'priority': dict_meta.get('priority', None),
            'load_date': dict_meta.get('load_date', None)
        })
    # logger.info(list_context)
    
    return list_id, list_context, list_meta, list_score, list_vector


def search_ensemble_with_filter(index_name, user_query, filters, embedding):
    # logger.info(f'단계 search_ensemble_with_filter: {filters}')
    
    key_id, key_context, key_meta, _, key_vector = search_keyword_with_filter(index_name, user_query, filters)
    vec_id, vec_context, vec_meta, _, vec_vector = search_vector_with_filter(index_name, user_query, filters, embedding)
    
    list_id = key_id + vec_id
    list_context = key_context + vec_context
    list_meta = key_meta + vec_meta
    list_vector = key_vector + vec_vector
    
    return list_id, list_context, list_meta, list_vector

    
#########################################################################################################
def search_ensemble(index_name, user_query):
    key_id, key_context, key_meta, _, key_vector = search_keyword2(index_name, user_query)
    vec_id, vec_context, vec_meta, _, vec_vector = search_vector(index_name, user_query)
    
    list_id = key_id + vec_id
    list_context = key_context + vec_context
    list_meta = key_meta + vec_meta
    list_vector = key_vector + vec_vector
    return list_id, list_context, list_meta, list_vector

def get_score_matrix(df_part, query_embedding):
    import numpy as np
    matrix1 = np.array(df_part['vector'].tolist())
    matrix2 = np.array(query_embedding).reshape(1,-1)
    dot_products = np.dot(matrix1, matrix2.T)
    norm1 = np.linalg.norm(matrix1, axis=1, keepdims=True)
    norm2 = np.linalg.norm(matrix2, axis=1, keepdims=True)
    
    # Calculate cosine similarity|
    similarity = dot_products / (norm1 * norm2.T)
    
    # Handle division by zero
    similarity = np.nan_to_num(similarity)

    return similarity
    
def search_neighbor(args):
    try:
        from process.search.search_process import opensearch_client
    except ImportError:
        from process.search.search_process import opensearch_client
    except Exception as e:
        raise e
    import pandas as pd
    
    idx = args['idx']
    index_name = args['index_name']
    df_part = args['df_part']
    context = df_part.iloc[idx, :]['context']
    section_level = df_part.iloc[idx, :]['section_level']
    chunk_id = df_part.iloc[idx, :]['chunk_id']
    client = opensearch_client()
    for current_chunk_id in [chunk_id-1 , chunk_id+1]:
        body = {"size" : 10, "query" : {"bool" : {"must" : [{"match" : {"metadata.chunk_id" : current_chunk_id}}],"filter" : {"term" : {"metadata.section_level" : section_level}}}}}
        response = client.search(index=index_name, body=body)
        try:
            neighbor_chunk = [answer['_source']['text'] for answer in response['hits']['hits']][0]
            if current_chunk_id < chunk_id:
                context = neighbor_chunk + context.replace(section_level, '')
            else:
                context = context + neighbor_chunk.replace(section_level, '')
        # 이웃 chunk가 없는 경우, 해당 chunk의 chunk_id가 0인 경우
        except:
            pass
    #pd.DataFrame(data=[{'context' : context}]).to_csv(f'./temp/TEMP_PART_{str(idx).zfill(5)}.csv', index=None)
    return context
    
# def get_score(args):
#     '''
#     검색결과 유사도 구하기
#     '''
#     try:
#         from process.search.search_process import opensearch_client
#     except ImportError:
#         from process.search.search_process import opensearch_client
#     except Exception as e:
#         raise e
#     import pandas as pd
    
#     client = opensearch_client()
#     def cosinesimil(vec1, vec2):
#         import numpy as np
#         vec1 = np.array(vec1)
#         vec2 = np.array(vec2)
#         distance = 1 - (np.dot(vec1, vec2)/(np.linalg.norm(vec1)*np.linalg.norm(vec2)))
#         score = (2-distance)/2
#         return score
#     idx = args['idx']
#     index_name = args['index_name']
#     query_embedding = args['query_embedding']
#     df_part = args['df_part']
#     context = df_part.iloc[idx, :]['context']
#     context_embedding = df_part.iloc[idx, :]['vector'] #############################
    
#     # body = {"size" : 1, "query" : {"match" : {"text":{"query" : context, "fuzziness":"AUTO"}}}}
#     # response = client.search(index=index_name, body=body)
#     # context_embedding = response['hits']['hits'][0]['_source']['vector_field']
#     score = cosinesimil(query_embedding, context_embedding)
#     pd.DataFrame(data=[{'context' : context, 'score':score}]).to_csv(f'./temp/TEMP_PART_{str(idx).zfill(5)}.csv', index=None)
#     return score
