from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse

from models.rag import *
from services.rag_services import process_query_new

from utils import utils

# define router
router = APIRouter()

# init logger
logger = utils.createLogger(__name__)

@router.post("/process_new")
async def process_new(request: Request, formData: RequestForm):
    try:
        response = StreamingResponse(
            process_query_new(formData),
            media_type="text/event-stream",
        )
        return response
    except ValueError as ve:
        logger.info(ve)
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.info(e)
        raise HTTPException(status_code=500, detail=str(e))
