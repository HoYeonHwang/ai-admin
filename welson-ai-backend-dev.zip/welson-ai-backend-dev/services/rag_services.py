from fastapi import HTTPException
from utils import utils
from process.rag.rag_pipeline import PipelineManager
from models.rag import RequestForm
from services import chat_services, outlier_chat_log_services
from models.outlier_chat_log import OutlierChatLog
from utils.guardrail import guardrail_provider
from utils.pii_manager import pii_manager
from typing import Optional
import traceback
import uuid

# init logger
logger = utils.createLogger(__name__)

# 채팅 프로세스 진행 코드
class ProcCode:
    START = "01"
    MULTI_QUERY_DONE = "02"
    HISTORY_LOADED = "03"
    GENERATION_START = "04"
    END = "05"
    DOC_INFO = "06"
    TIMESTAMP = "07"
    ANSWER_TYPE = "08"

# 웰슨 프론트 구분 문자열
def _proc(code: str, payload: Optional[str] = None) -> str:
    body = f"{code}|{payload}" if payload is not None else code
    return f"<ansProc>{body}</ansProc>"


"""Process a user query using the RAG (Retrieval-Augmented Generation) pipeline.
Args:
    request (RequestForm): The user query and related metadata.
        [query_type 분류 체계]
            - C101: 인사 (Payroll/HR)
            - C102: 총무 (General Affairs)
            - C103: 수신 (Deposit/Savings)
            - C104: 여신 (Loan/Credit)
            - C105: 준법감시 (Compliance)
            - C106: 정보보호 (Information Security)
            - C201 : 대화 메뉴
        answerType (str): Type of answer to be generated.
            ## 문서검색
            00: 질문 부적합
            01: (프론트 제공) (03 이후) [WELSON AI로 검색] 멀티 쿼리 > 검색 > 생성
            02: 질의 필터 > 멀티 쿼리 > FAQ 탐색 > 검색 > 생성(4o-mini)
            03: 질의 필터 > 멀티 쿼리 > FAQ 탐색 > FAQ 검색결과 제공
                - Plus+를 선택해도 FAQ 검색결과를 제공했다면 03으로 부여함
            04: (프론트 제공) (02 이후) [향상된 WELSON AI로 검색] 기존 결과에서 생성만 gpt-4o 적용 시
            05: (프론트 제공) 질의 필터 > 멀티 쿼리 > FAQ 탐색 > 검색 > 생성(4o)
            
            ## 대화하기 
            10: (프론트 제공) 대화형 GPT
            11: (프론트 제공) 대화형 GPT + web search
            
Yields:
    str: Intermediate processing steps or final response.
"""

# RAG 파이프라인을 통해 사용자 질의를 처리한다.
async def process_query_new(request: RequestForm):
    """ 
    처리순서 :
        1. PII 마스킹 및 가드레일 검사
        2. answerType에 따른 전처리 (쿼리 재작성, 필터링)
        3. 전략별 컨텍스트/답변 준비 (WELSON AI / FAQ / 기본 RAG / 대화형)
        4. 답변 생성 및 스트리밍 처리
        5. 채팅 히스토리/캐시 저장
    """
    try:
        yield _proc(ProcCode.START)

        # 1. PII 마스킹 및 가드레일 검사
        blocked_response = await _apply_security_guards(request)
        if blocked_response is not None:
            yield blocked_response
            yield _proc(ProcCode.END)
            return

        # --- 기존 레거시 로직 진행 ---
        # rewrite_query는 마스킹된 상태에서도 키워드 치환을 시도함
        # bl_gen = True
        answer = None
        doc_info = None
        answerType = None
        rewritted_query = None
        #  answerType = "04" if getattr(request, "yn_regen", False) else ""
        if type(request.conversation_id) == list:
            request.conversation_id = request.conversation_id[0]
            
        # init
        logger.info(f"REQUEST INFO:: {request}")
        pipeline = PipelineManager.get_pipeline(request.query_type)

        if request.answerType is not None:
            answerType = request.answerType
        if request.sel_sequence is None:
            request.sel_sequence = request.sequence

        if answerType in ["01", "04"]:
            logger.info(f"get_selected_result START")
            total_context, doc_info, query_type = await pipeline.get_selected_result(
                request.user_id, request.conversation_id, request.sel_sequence
            )
            logger.info(f"answerType=01,04 >> query_type: {query_type}")
        # rewrite query: 검색 및 생성 성능 제고를 위한 선제적 조치

        if answerType in ["01", "04"]:
            logger.info(f"rewrite_query START1")
            rewritted_query = pipeline.rewrite_query(request.user_query, query_type)
        else:
            logger.info(f"rewrite_query START2")
            rewritted_query = pipeline.rewrite_query(
                request.user_query, request.query_type
            )
            logger.info(f"rewrite_query END2")

        if answerType in ["01", "04", "10", "11"]:
            filtered_result = "Y"
        elif answerType == "00":
            filtered_result = "N"
        else:
            logger.info("Fillter Start")
            filtered_result = await pipeline.afilter_question(
                rewritted_query, request.query_type
            )
            logger.info("Fillter End")

        # valid query
        if (filtered_result == "N") or (rewritted_query.strip() == ""):
            answerType = "00"
            answer = f"질문이 모호하거나 답변할 수 없는 질문입니다. 질문을 구체적으로 하거나 다른 질문을 시도해주세요."
        elif answerType == "01":  # WELSON AI로 검색: FAQ 검토하지 않는 경우
            # _, _, query_type = await pipeline.get_selected_result(request.user_id, request.conversation_id, request.sel_sequence)

            # 2. get multi query
            logger.info("멀티쿼리생성 시작")
            # TEST: new multi query function using previous questions with llm: e.g) 더 설명해줘, 그러면 ~할 때는 어떻게 돼? etc
            multi_querys = await pipeline.agenerate_multi_query(
                rewritted_query, query_type, request.user_id, request.conversation_id
            )
            logger.info("멀티쿼리생성 종료")
            yield f"<ansProc>02</ansProc>"
            total_context, total_meta = await pipeline.asearch_context(
                rewritted_query, query_type, multi_querys
            )
            doc_info = await pipeline.aget_meta(total_meta)
            if doc_info is not None:
                doc_info = '{"pdfInfo":' + doc_info + "}"
        elif answerType == "04":
            # user_id, conversation_id, seq를 이용하여 해당 대화의 total_context 및 docinfo 조회
            # total_context, doc_info, query_type = await pipeline.get_selected_result(request.user_id, request.conversation_id, request.sel_sequence)
            logger.info(
                f"기검색결과 건수: {len(total_context)}, query_type: {query_type}"
            )
            if len(total_context) > 0:
                logger.info(f"기검색결과 Sample:: {total_context[0][:30]}")
        elif (answerType == "10") or (answerType == "11"):
            logger.info(f"대화형 GPT: {answerType}")
            total_context = ""
        else:
            # 02, 03, 05
            logger.info("멀티쿼리생성 시작")
            multi_querys = await pipeline.agenerate_multi_query(
                rewritted_query,
                request.query_type,
                request.user_id,
                request.conversation_id,
            )
            logger.info("멀티쿼리생성 종료")
            yield f"<ansProc>02</ansProc>"

            if "C106" in request.query_type:
                threshold = 0.90
            else:
                threshold = 0.95

            logger.info("FAQ 탐색 시작")
            faq_result = await pipeline.asearch_multi_faq(
                rewritted_query.replace("*", ""),
                request.query_type,
                multi_querys,
                threshold=threshold,
            )
            logger.info("FAQ 탐색 종료")

            if faq_result.score is not None:  # FAQ검색결과
                answerType = "03"
                faq_answer = ""
                faq_meta = []

                faq_answer_arr = faq_result.answer.split("[참고 문서]")
                if len(faq_answer_arr) > 1:
                    faq_answer = "".join(faq_answer_arr[: len(faq_answer_arr) - 1])
                    # faq_meta = ",".join(faq_answer_arr[len(faq_answer_arr)-1:len(faq_answer_arr)])
                    for meta in faq_answer_arr[
                        len(faq_answer_arr) - 1 : len(faq_answer_arr)
                    ]:
                        meta = meta.replace("\n", "")
                        faq_meta.append(f'{{"file":"{meta}", "page":"1"}}')
                    doc_info = '{"pdfInfo":[' + ",".join(faq_meta) + "]}"

                else:
                    faq_answer = "".join(faq_answer_arr[0])

                answer = f"FAQ 검색 결과 입니다. 문서 검색 결과를 얻고 싶다면, 'WELSON AI'로 검색을 클릭하세요. "
                answer = (
                    answer
                    + f"\n\n**Question**: {faq_result.question}  \n\n**Answer**:\n{faq_answer}"
                )

            else:
                if answerType != "05":
                    answerType = "02"
                total_context, total_meta = await pipeline.asearch_context(
                    rewritted_query, request.query_type, multi_querys
                )
                logger.info("메타정보 가공")
                logger.info(
                    f"검색 청크 개수: {len(total_context)}\nSample: {total_context[0][:100]}"
                )
                doc_info = await pipeline.aget_meta(total_meta)
                doc_info = '{"pdfInfo":' + doc_info + "}"

        logger.info("answerType :::" + answerType)

        # 01:강제멀티쿼리 02:멀티쿼리 경우 생성 전 과거 이력 설정
        if answerType in ["01", "02", "04", "05", "10", "11"]:
            # if (answerType=='01') or (answerType=='02') or (answerType=='04') or (answerType=='05') or (answerType=='10'):
            yield f"<ansProc>03</ansProc>"
            answer = ""

            # 과거 히스토리 로드
            _store = chat_services.get_user_session_search(
                request.user_id,
                request.conversation_id,
                "",
                "",
                "",
                "",
                "",
                request.sel_sequence,
            )
            # logger.info(f"tkkim_store{_store}")
            store = chat_services.change_chat_type(
                request.user_id, request.conversation_id, _store, type="store"
            )
        if doc_info is not None:
            yield f"<ansProc>06|{doc_info}</ansProc>"

        yield f"<ansProc>04</ansProc>"

        # 01, 02, 04: 생성형 ai를 이용한 답변 생성 수행 필요
        # 00, 03: 기작성된 답변 제공
        if answerType in ["02", "05", "10", "11"]:
            for chunk in pipeline.generate_answer(
                rewritted_query,
                request.query_type,
                request.conversation_id,
                answerType,
                store,
                total_context,
            ):
                yield chunk
                answer += chunk
        elif answerType in ["01", "04"]:
            for chunk in pipeline.generate_answer(
                rewritted_query,
                query_type,
                request.conversation_id,
                answerType,
                store,
                total_context,
            ):
                yield chunk
                answer += chunk
        elif (answerType == "00") or (answerType == "03"):
            yield answer
        else:
            pass

        yield f"<ansProc>05</ansProc>"

        timestamp = utils.get_current_time_kst()
        yield f"<ansProc>07|{timestamp}</ansProc>"
        yield f"<ansProc>08|{answerType}</ansProc>"

        # db저장 시 query_type을 "_"로 연결하여 저장 필요
        if answerType in ["01", "04"]:
            final_query_type = "_".join(query_type)
        else:
            if isinstance(request.query_type, list):
                final_query_type = "_".join(request.query_type)
            else:
                final_query_type = request.query_type

        logger.info("save_chat_history START")
        await chat_services.save_chat_history(
            request.user_id,
            request.conversation_id,
            final_query_type,  # request.query_type,
            request.user_query,
            answer,
            request.sequence,
            doc_info if doc_info is not None else "",
            timestamp,
            answerType,
            request.sel_sequence,
        )

        if (answerType == "02") or (answerType == "03"):
            if "total_context" not in locals():
                total_context = list()
            await chat_services.save_chat_cache(
                request.user_id,
                request.conversation_id,
                final_query_type,  # request.query_type,
                request.user_query,
                total_context,  # str in list
                doc_info,
                request.sequence,
                timestamp,
                answerType,
            )
        logger.info("채팅내용 저장 종료")
    except ValueError as ve:
        traceback.print_exc()
        logger.error(f"QUERY: {request.user_query}\n\nSERVICE: {request.query_type}")
        logger.error(f"ValueError : {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        traceback.print_exc()
        logger.error(f"QUERY: {request.user_query}\n\nSERVICE: {request.query_type}")
        logger.error(f"ValueError : {e}")
        raise HTTPException(status_code=500, detail=str(e))

# PII 마스킹 및 가드레일 검사
async def _apply_security_guards(request: RequestForm) -> Optional[str]:
    # PII 탐지 및 마스킹
    pii_result = pii_manager.process(request.user_query)
    if pii_result["is_detected"]: # PII 탐지 로그 INSERT
        await _log_outlier(request, "PII", request.user_query, pii_result["outlier_content"])
        
        # PII 적용된 질의로 변경
        request.user_query = result["outlier_content"]
        
    # 가드레일 검사 FIXME
    input_action = "None"
    validated_query = request.user_query
    if "공격" in request.user_query:
        input_action = "GUARDRAIL_INTERVENED"
        validated_query = "가드레일에 의한 차단 발생"

    if input_action == "GUARDRAIL_INTERVENED": # 가드레일이 차단한 경우(예: 확답 요구 등) 즉시 거절 메시지 송출
        logger.info(f"Guardrail Blocked: {validated_query}") # XXX
        await _log_outlier(request, "GUARDRAIL", request.user_query, validated_query)
        # 가드레일 차단
        return validated_query

    request.user_query = validated_query
    return None


# 이상 탐지 이력 저장
async def _log_outlier(request: RequestForm, detect_system: str, request_content: str, outlier_content: str) -> None:
    await outlier_chat_log_services.insert_outlier_log(
        outlier_log = OutlierChatLog(
            outlier_id=str(uuid.uuid4()),
            trx_gid=request.trx_gid,
            request_content=request_content,
            outlier_content=outlier_content,
            detect_system=detect_system,
            timestamp=utils.get_current_time_kst(),
        )
    )