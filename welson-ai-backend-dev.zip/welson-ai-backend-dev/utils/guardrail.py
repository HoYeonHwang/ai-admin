import boto3
import os
from typing import Tuple
from dotenv import load_dotenv

class BedrockGuardrail:
    def __init__(self):
        load_dotenv()
        # 세션이나 클라이언트를 클래스 내부에서 관리
        self.client = boto3.client(
            service_name='bedrock-runtime',
            region_name=os.getenv("REGION_NAME"),
            aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
            aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY")
        )
        self.guardrail_id = os.getenv("AWS_GUARDRAIL_ID")
        self.guardrail_version = os.getenv("AWS_GUARDRAIL_VERSION")

    def apply(self, text: str, source: str = 'INPUT') -> Tuple[str, str]:
        """
        가드레일을 적용하고 (액션, 결과텍스트) 반환
        source: 'INPUT' 또는 'OUTPUT'
        """
        try:
            response = self.client.apply_guardrail(
                guardrailIdentifier=self.guardrail_id,
                guardrailVersion=self.guardrail_version,
                source=source,
                content=[{'text': {'text': text}}]
            )
            
            # print(f"DEBUG assessments: {response.get('assessments')}")
            action = response.get('action', 'NONE')
            # outputs가 없을 경우를 대비한 안전한 추출
            outputs = response.get('outputs', [])
            final_text = outputs[0].get('text', text) if outputs else text
            
            return action, final_text

        except Exception as e:
            # 로거가 있다면 logger.error 사용 권장
            print(f"Bedrock Guardrail Error: {str(e)}")
            return "ERROR", text

# 싱글톤 인스턴스 생성
guardrail_provider = BedrockGuardrail()

def get_guardrail() -> BedrockGuardrail:
    return guardrail_provider