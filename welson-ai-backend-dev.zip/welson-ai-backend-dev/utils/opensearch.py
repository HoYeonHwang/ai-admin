def opensearch_client():
    """
    opensearch 엔진 정의
    """
    from opensearchpy import OpenSearch
    opensearch = OpenSearch(
        hosts=[{'host' : 'localhost', 'port': 39200}], #text/html
        http_auth=('fastapi_client', 'welcome88!'),
        use_ssl=True,
        verify_certs=False,
	ssl_assert_hostname=False,
        ssl_show_warn=False,
        headers={"User-Agent": "Mozilla/5.0"}
    )
    return opensearch

