import re


class PIIManager:
    def __init__(self):
        # [\s.-]? 공백 . - 매칭
        self.patterns = {
            "주민등록번호": re.compile(
                r"\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])[\s.-]?[1-4]\d{6}"
            ),
            "여권번호": re.compile(r"[a-zA-Z][a-zA-Z0-9]\d{7}"),
            "운전면허번호": re.compile(r"\d{2}[\s.-]?\d{2}[\s.-]?\d{6}[\s.-]?\d{2}"),
            "외국인등록번호": re.compile(
                r"\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])[\s.-]?[5-8]\d{6}"
            ),
            "국내거소신고번호": re.compile(
                r"\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])[\s.-]?[5-8]\d{6}"
            ),
            "휴대폰번호": re.compile(r"01[016789][\s.-]?\d{3,4}[\s.-]?\d{4}"),
            "신용카드번호": re.compile(r"\d{4}[\s.-]?\d{4}[\s.-]?\d{4}[\s.-]?\d{4}"),
        }

    def process(self, text: str):
        if not text:
            return {
                "is_detected": False,
                "request_content": text,
                "outlier_content": text,
                "mappings": [],
            }

        mappings = []
        transformed_text = text

        for label, pattern in self.patterns.items():
            for match in pattern.finditer(text):
                mappings.append(
                    {
                        "tag": f"<{label}>",
                        "original_value": match.group(),
                        "start": match.start(),
                        "end": match.end(),
                        "type": label,
                    }
                )
        for label, pattern in self.patterns.items():
            transformed_text = pattern.sub(f"<{label}>", transformed_text)

        return {
            "is_detected": len(mappings) > 0,
            "request_content": text,
            "outlier_content": transformed_text,
            "mappings": mappings,
        }


pii_manager = PIIManager()
